"""Raise LangChain-ecosystem dependency lower bounds to the latest stable PyPI release.

For every in-scope requirement (see `IN_SCOPE_PREFIXES`) that declares a
concrete lower bound (`>=` or `~=`) in `[project.dependencies]`,
`[project.optional-dependencies]`, or `[dependency-groups]`, this rewrites that
lower bound in place to the newest stable PyPI release that still has at least
one non-yanked file *and* remains within the requirement's existing range.
With `--check-resolution`, uv checks the combined bumps and affected reverse
dependents before writing. If they conflict, dependency-wide bumps are tried in
name order against the accepted set; incompatible bumps retain their old floors
and appear in the summary. Tool errors and an unresolvable baseline fail closed.

Upper bounds, extras, and environment markers are preserved. Exact pins (`==`)
are left alone — raising a floor only applies to range floors. A bound already
ahead of the latest stable release (intentional prerelease coordination) is
respected and never lowered.

A dependency that `[tool.uv.sources]` maps to a local path (a sibling package in
this repository) is still raised: the path only applies to local development,
while the published floor is what PyPI users install against. The new floor is
capped at the version the local checkout declares so `uv lock` keeps resolving
the path source. A local source whose version cannot be read is skipped.

A dependency whose PyPI metadata could not be fetched, or a manifest that could
not be rewritten, is reported as a failure rather than silently omitted: an
unattended daily cron must never render "PyPI was unreachable" as "everything
is already up to date".

`--dependencies` narrows the run to an exact comma-separated name list (the
prefix scope no longer applies), so a manual dispatch can raise just
`langchain-core,langsmith` without touching the rest of the ecosystem. Names are
compared after PEP 503 normalization. A requested name that is not a raiseable
PyPI requirement of the selected package fails the run rather than passing
quietly, because a narrowed run that skipped what it was asked for must not
report success.
"""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
import tomllib
from collections.abc import Collection, Iterable, Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath

from packaging.requirements import InvalidRequirement, Requirement
from packaging.specifiers import Specifier, SpecifierSet
from packaging.utils import canonicalize_name
from packaging.version import InvalidVersion, Version

REPO_ROOT = Path(__file__).resolve().parents[3]

# Sibling helper scripts: `check_dep_freshness` and `check_release_deps` live
# under `release/`; `check_lockfiles_pre_commit` owns the package list and the
# per-package interpreter version used to resolve lockfiles. Import them rather
# than duplicating either, so a lockfile regenerated here always matches what
# `check_lockfiles.yml` will verify on the opened PR.
_SCRIPTS_DIR = Path(__file__).resolve().parents[1]
for _domain in (_SCRIPTS_DIR / "release", _SCRIPTS_DIR / "checks"):
    if str(_domain) not in sys.path:
        sys.path.insert(0, str(_domain))

from check_dep_freshness import (  # noqa: E402
    available_pypi_versions,
    extract_minimum,
    local_dependency_names,
)
from check_lockfiles_pre_commit import (  # noqa: E402
    python_version,
    stale_lock_dirs,
)
from check_release_deps import (  # noqa: E402
    PyPIRequestError,
    _write_output,
    fetch_pypi_json,
    load_release_packages,
)

MAX_FETCH_WORKERS = 8
# Only `>=` / `~=` floors are raiseable. `==` is an exact pin (the only in-scope
# one today, `deepagents==` in `libs/code`, is bumped by `bump_code_sdk_pin.yml`
# after a `deepagents` publish), and a bare upper bound has no floor to raise.
RAISEABLE_OPERATORS = frozenset({">=", "~="})
# Distribution-name prefixes whose floors are raised. Covers the LangChain
# integrations (langchain-*, the base langchain/langgraph/langsmith packages,
# and langgraph-* companion packages) plus the deepagents-* workspace packages
# that one package pulls from PyPI (e.g. deepagents-code -> deepagents-acp).
# A package's own name, URL requirements, and local sources without a readable
# version are excluded per manifest.
# Matching is a bare name prefix with no hyphen boundary, so an unrelated
# third-party distribution such as `langchainhub` is also in scope.
IN_SCOPE_PREFIXES = ("langchain", "langgraph", "langsmith", "deepagents")


def _notice(message: str) -> None:
    print(f"::notice::{message}")


def _warning(message: str) -> None:
    print(f"::warning::{message}")


def _error(message: str) -> None:
    print(f"::error::{message}")


@dataclass(frozen=True)
class RequirementEdit:
    """One lower-bound rewrite applied to a manifest requirement string.

    Attributes:
        manifest_path: Repository-relative, POSIX-separated manifest that was
            edited.
        dependency_name: Canonicalized in-scope distribution name.
        old_requirement: Original requirement string as written in the manifest.
        new_requirement: Requirement string with the raised lower bound.

    """

    manifest_path: str
    dependency_name: str
    old_requirement: str
    new_requirement: str


@dataclass(frozen=True)
class ManifestScope:
    """One manifest's text and its in-scope requirements, parsed exactly once.

    Parsing a manifest twice (once to collect names to fetch, once to rewrite)
    risks the two passes disagreeing about what is in scope, which shows up only
    as a silently missing bump. This carries the single parse between phases.

    Attributes:
        manifest_path: Repository-relative, POSIX-separated manifest path.
        text: The manifest's verbatim source text.
        requirements: `(raw_string, parsed_requirement)` pairs for every
            in-scope dependency, in manifest declaration order.
        workspace_names: Canonical names declared here but resolved from the
            workspace rather than PyPI (a URL, a local `[tool.uv.sources]` entry
            with no readable version, or the package itself). They have no PyPI
            floor to raise, which a narrowed run must report differently from a
            name that is absent.
        local_versions: Versions declared by the local checkouts that
            `[tool.uv.sources]` paths point at. A raised floor must not pass
            these, or `uv lock` could no longer resolve the path source.

    """

    manifest_path: str
    text: str
    requirements: tuple[tuple[str, Requirement], ...]
    workspace_names: frozenset[str] = frozenset()
    local_versions: Mapping[str, Version] = field(default_factory=dict)


@dataclass(frozen=True)
class ManifestPlan:
    """A pending rewrite of one manifest, not yet written to disk.

    Rewrites are planned for every manifest before any is written so a failure
    partway through cannot leave a half-updated working tree.

    Attributes:
        manifest_path: Repository-relative, POSIX-separated manifest path.
        new_text: Full manifest text with every raised bound applied.
        edits: The rewrites `new_text` embodies.

    """

    manifest_path: str
    new_text: str
    edits: tuple[RequirementEdit, ...]


def _project_requirement_strings(project: Mapping[str, object]) -> list[str]:
    """Collect requirement strings from `[project]`'s dependency tables.

    Reads `dependencies` and `optional-dependencies`. `[dependency-groups]` is a
    top-level table, not a `[project]` one — see `_group_requirement_strings`.
    """
    requirements: list[str] = []
    dependencies = project.get("dependencies", [])
    if isinstance(dependencies, list):
        requirements.extend(item for item in dependencies if isinstance(item, str))

    optional = project.get("optional-dependencies", {})
    if isinstance(optional, Mapping):
        for values in optional.values():
            if isinstance(values, list):
                requirements.extend(item for item in values if isinstance(item, str))
    return requirements


def _group_requirement_strings(manifest: Mapping[str, object]) -> list[str]:
    """Collect requirement strings from `[dependency-groups]`.

    PEP 735 include-tables (`{include-group = "..."}`) are not requirement
    strings and are skipped; the group they name is visited on its own.
    """
    groups = manifest.get("dependency-groups", {})
    if not isinstance(groups, Mapping):
        return []
    requirements: list[str] = []
    for values in groups.values():
        if isinstance(values, list):
            requirements.extend(item for item in values if isinstance(item, str))
    return requirements


def _raiseable_specifier(specifiers: SpecifierSet) -> Specifier | None:
    """Return the strongest `>=`/`~=` lower-bound clause, or `None` if there is none.

    Selected by version rather than iteration order. `SpecifierSet.__iter__`
    order is an implementation detail — older `packaging` releases stored the
    clauses in a `frozenset` — and `extract_minimum`, which gates the comparison
    at the call site, reports the *strongest* floor. Choosing by `max` keeps the
    clause that gets rewritten and the floor that was compared in agreement.
    """
    candidates = [
        specifier
        for specifier in specifiers
        if specifier.operator in RAISEABLE_OPERATORS
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda specifier: Version(specifier.version))


def _compatible_release_version(old_version: str, new_minimum: Version) -> str:
    """Render `new_minimum` for a `~=` clause without moving its ceiling.

    `~=X1...Xn` means `>=X1...Xn, ==X1...X(n-1).*`, so the implied ceiling is
    fixed by the *number* of release components, not their values. Rendering the
    raised floor with the same component count therefore leaves the ceiling
    untouched: `~=1.2` (ceiling `==1.*`) raised towards 1.9.4 becomes `~=1.9`,
    not `~=1.9.4`, which would silently narrow the ceiling to `==1.9.*`.

    `new_minimum` always satisfies the original clause (callers clamp candidates
    to the existing range), so its leading components already match and only the
    last one moves.
    """
    components = len(Version(old_version).release)
    if len(new_minimum.release) < components:
        return str(new_minimum)
    return ".".join(str(part) for part in new_minimum.release[:components])


def _raise_lower_bound(
    requirement_string: str, specifier: Specifier, new_minimum: Version
) -> str:
    """Rewrite one requirement string's lower-bound clause to `new_minimum`.

    Only the matched clause is replaced, so upper bounds, extras, and markers
    survive verbatim.

    Args:
        requirement_string: Raw requirement string as written in the manifest.
        specifier: The clause to rewrite, from `_raiseable_specifier`.
        new_minimum: The version to raise the lower bound to.

    Returns:
        The rewritten requirement string.

    Raises:
        ValueError: If the clause could not be located in `requirement_string`.

    """
    new_version = (
        _compatible_release_version(specifier.version, new_minimum)
        if specifier.operator == "~="
        else str(new_minimum)
    )
    # `packaging` discards whitespace when parsing, so a clause spelled
    # `>= 1.0` in the manifest renders as `>=1.0` once parsed. Match the
    # operator and version with optional whitespace between them instead of
    # assuming the normalized text appears verbatim — `langchain >= 1.0` is
    # legal PEP 508 and must not blow up the run.
    pattern = re.escape(specifier.operator) + r"\s*" + re.escape(specifier.version)
    replaced, count = re.subn(
        pattern, f"{specifier.operator}{new_version}", requirement_string, count=1
    )
    if count != 1:
        msg = (
            f"Could not rewrite lower bound "
            f"'{specifier.operator}{specifier.version}' in '{requirement_string}'"
        )
        raise ValueError(msg)
    return replaced


def _preserves_upper_bounds(
    old: SpecifierSet,
    new: SpecifierSet,
    new_minimum: Version,
    versions: Iterable[Version],
) -> bool:
    """Whether `new` still admits everything `old` did at or above the new floor.

    Raising a floor must never tighten a ceiling. Rather than reasoning about
    each operator's implied upper bound, check the property directly against the
    versions that actually exist on PyPI — the only ones the change can affect.
    """
    return all(
        new.contains(version, prereleases=True)
        for version in versions
        if version >= new_minimum and old.contains(version, prereleases=True)
    )


def _self_name(project: Mapping[str, object]) -> str | None:
    """Return the canonicalized name of the package the manifest publishes."""
    name = project.get("name")
    return canonicalize_name(name) if isinstance(name, str) else None


def _path_source_version(directory: Path, source: object) -> Version | None:
    """Return the static version of the package a `[tool.uv.sources]` path names.

    Returns `None` for non-path sources and for checkouts whose version is
    missing, dynamic, or unreadable.
    """
    if not isinstance(source, Mapping) or not isinstance(source.get("path"), str):
        return None
    pyproject = directory / source["path"] / "pyproject.toml"
    try:
        project = tomllib.loads(pyproject.read_text(encoding="utf-8"))["project"]
        return Version(project["version"])
    except (OSError, tomllib.TOMLDecodeError, KeyError, TypeError, InvalidVersion):
        return None


def _local_versions(
    manifest_path: str, manifest: Mapping[str, object], local_names: frozenset[str]
) -> dict[str, Version]:
    """Map each local-path dependency to the version its checkout declares."""
    tool = manifest.get("tool")
    uv = tool.get("uv") if isinstance(tool, Mapping) else None
    sources = uv.get("sources") if isinstance(uv, Mapping) else None
    if not isinstance(sources, Mapping):
        return {}
    directory = (REPO_ROOT / manifest_path).parent
    versions: dict[str, Version] = {}
    for name, source in sources.items():
        canonical_name = canonicalize_name(str(name))
        if canonical_name not in local_names:
            continue
        version = _path_source_version(directory, source)
        if version is not None:
            versions[canonical_name] = version
    return versions


def _resolved_from_pypi(
    requirement: Requirement,
    canonical_name: str,
    local_names: frozenset[str],
    self_name: str | None,
) -> bool:
    """Return whether a requirement has a published PyPI floor to raise.

    A URL requirement, the package's own name, and each name in `local_names`
    (local sources with no readable version) have no PyPI floor to raise. Kept separate from `_in_scope` so
    a caller can tell *why* a name was excluded, which is what lets a narrowed
    run say "resolved locally" instead of "not declared".
    """
    return not (
        requirement.url or canonical_name in local_names or canonical_name == self_name
    )


def _in_scope(
    requirement: Requirement,
    canonical_name: str,
    local_names: frozenset[str],
    self_name: str | None,
    narrow_to: frozenset[str] | None = None,
) -> bool:
    """Return whether a dependency is an in-scope, externally-resolved dependency.

    Whether it declares a raiseable floor is a separate question, answered by
    `extract_minimum` and `_raiseable_specifier` at the call site.

    When `narrow_to` is provided (the `--dependencies` CSV), it replaces the
    prefix scope: a name must be listed there exactly to be in scope.
    """
    if not _resolved_from_pypi(requirement, canonical_name, local_names, self_name):
        return False
    if narrow_to is not None:
        return canonical_name in narrow_to
    return canonical_name.startswith(IN_SCOPE_PREFIXES)


def _load_scope(
    manifest_path: str, narrow_to: frozenset[str] | None = None
) -> ManifestScope:
    """Read and parse one manifest, returning its in-scope requirements.

    Raises:
        TypeError: If the manifest has no `[project]` table.

    """
    text = (REPO_ROOT / manifest_path).read_text(encoding="utf-8")
    manifest = tomllib.loads(text)
    project = manifest.get("project")
    if not isinstance(project, Mapping):
        msg = f"{manifest_path} has no [project] table"
        raise TypeError(msg)

    local_names = local_dependency_names(manifest)
    local_versions = _local_versions(manifest_path, manifest, local_names)
    # A versioned local source is a published sibling package, so its floor is
    # raised like any other; only unversioned local sources stay excluded.
    local_names -= local_versions.keys()
    self_name = _self_name(project)
    requirements: list[tuple[str, Requirement]] = []
    workspace_names: set[str] = set()
    seen: set[str] = set()
    for raw in _project_requirement_strings(project) + _group_requirement_strings(
        manifest
    ):
        if raw in seen:
            continue
        seen.add(raw)
        try:
            requirement = Requirement(raw)
        except InvalidRequirement as err:
            _warning(
                f"Skipping unparseable requirement in {manifest_path}: {raw!r} ({err})"
            )
            continue
        canonical_name = canonicalize_name(requirement.name)
        if not _resolved_from_pypi(requirement, canonical_name, local_names, self_name):
            workspace_names.add(canonical_name)
            continue
        if not _in_scope(
            requirement, canonical_name, local_names, self_name, narrow_to
        ):
            continue
        requirements.append((raw, requirement))
    return ManifestScope(
        manifest_path=manifest_path,
        text=text,
        requirements=tuple(requirements),
        workspace_names=frozenset(workspace_names),
        local_versions=local_versions,
    )


def _fetch_available_versions(
    names: Collection[str],
) -> tuple[dict[str, list[Version]], list[str]]:
    """Fetch every usable stable PyPI version for each distribution name.

    Returns:
        A `(available, failures)` pair. `failures` names the distributions whose
        metadata could not be retrieved or understood, so callers can report
        them instead of mistaking an absent entry for "already up to date".

    """
    available: dict[str, list[Version]] = {}
    failures: list[str] = []
    if not names:
        return available, failures
    workers = min(MAX_FETCH_WORKERS, len(names))
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(fetch_pypi_json, name): name for name in names}
        for future in as_completed(futures):
            name = futures[future]
            try:
                # `available_pypi_versions` raises `TypeError` on a payload with
                # no `releases` mapping; keep it inside the guard so one
                # malformed response cannot abort every other lookup.
                versions = available_pypi_versions(
                    future.result(), include_prereleases=False
                )
            except (PyPIRequestError, TypeError) as err:
                _warning(f"Could not resolve {name}: PyPI query failed ({err})")
                failures.append(name)
                continue
            if not versions:
                _warning(f"Could not resolve {name}: no stable PyPI release found")
                failures.append(name)
                continue
            available[name] = versions
    return available, sorted(failures)


def _latest_compatible_version(
    requirement: Requirement, versions: Iterable[Version]
) -> Version | None:
    """Return the newest available version satisfying the requirement range."""
    return max(
        (
            version
            for version in versions
            if requirement.specifier.contains(version, prereleases=True)
        ),
        default=None,
    )


def _apply_replacements(
    text: str, replacements: Mapping[str, str], manifest_path: str
) -> str:
    """Rewrite requirement string literals in a manifest's TOML text.

    Each requirement is matched only where it fills an entire quoted TOML
    string. That anchoring is what makes the rewrite safe: a requirement that is
    a prefix of another (`langchain-core>=1.1` inside `langchain-core>=1.1.1`)
    cannot corrupt its neighbour, and a mention inside a `#` comment is left
    alone. Longest requirement first, as belt-and-braces against overlap.

    A requirement that also appears in a table this script does not parse
    (`[tool.uv] constraint-dependencies`, say) is rewritten there too, keeping
    the two spellings consistent.

    Raises:
        ValueError: If a planned replacement matched nothing, which would
            otherwise be reported as an applied edit that never happened.

    """
    for raw in sorted(replacements, key=len, reverse=True):
        new = replacements[raw]
        applied = 0
        for quote in ('"', "'"):
            literal = f"{quote}{raw}{quote}"
            occurrences = text.count(literal)
            if occurrences:
                text = text.replace(literal, f"{quote}{new}{quote}")
                applied += occurrences
        if not applied:
            msg = (
                f"{manifest_path}: requirement {raw!r} was parsed from this "
                "manifest but no matching quoted literal could be rewritten"
            )
            raise ValueError(msg)
    return text


def _plan_manifest(
    scope: ManifestScope, available: Mapping[str, list[Version]]
) -> ManifestPlan:
    """Plan the in-scope lower-bound rewrites for one manifest.

    Raises:
        ValueError: If a rewrite could not be expressed or applied.

    """
    edits: list[RequirementEdit] = []
    replacements: dict[str, str] = {}
    for raw, requirement in scope.requirements:
        canonical_name = canonicalize_name(requirement.name)
        minimum = extract_minimum(requirement.specifier)
        if minimum is None:
            continue
        specifier = _raiseable_specifier(requirement.specifier)
        if specifier is None:
            continue
        versions = available.get(canonical_name)
        if not versions:
            continue
        local_version = scope.local_versions.get(canonical_name)
        candidates = (
            versions
            if local_version is None
            else [version for version in versions if version <= local_version]
        )
        new_minimum = _latest_compatible_version(requirement, candidates)
        if new_minimum is None or new_minimum <= minimum:
            continue

        raised = _raise_lower_bound(raw, specifier, new_minimum)
        if raised == raw:
            continue
        if not _preserves_upper_bounds(
            requirement.specifier,
            Requirement(raised).specifier,
            new_minimum,
            versions,
        ):
            _warning(
                f"{scope.manifest_path}: leaving {raw!r} alone — raising it to "
                f"{new_minimum} would exclude versions the current range allows."
            )
            continue

        replacements[raw] = raised
        edits.append(
            RequirementEdit(
                manifest_path=scope.manifest_path,
                dependency_name=canonical_name,
                old_requirement=raw,
                new_requirement=raised,
            )
        )

    new_text = (
        _apply_replacements(scope.text, replacements, scope.manifest_path)
        if replacements
        else scope.text
    )
    return ManifestPlan(
        manifest_path=scope.manifest_path, new_text=new_text, edits=tuple(edits)
    )


def lock_dirs_for(
    changed_manifests: Collection[str], *, skip_dependents: bool
) -> list[str]:
    """Return lock directories, optionally excluding reverse dependents."""
    if skip_dependents:
        return sorted(
            {PurePosixPath(path).parent.as_posix() for path in changed_manifests}
        )
    return stale_lock_dirs(changed_manifests)


def _resolves(manifests: Collection[str], *, skip_dependents: bool) -> bool:
    """Check universal resolution without changing lockfiles; fail on tool errors."""
    for directory in lock_dirs_for(manifests, skip_dependents=skip_dependents):
        result = subprocess.run(
            [
                "uv",
                "lock",
                "--dry-run",
                "--directory",
                str(REPO_ROOT / directory),
                "--python",
                python_version(REPO_ROOT / directory),
                "--color",
                "never",
            ],
            capture_output=True,
            text=True,
            timeout=600,
            check=False,
        )
        if result.returncode:
            if "No solution found when resolving dependencies" in result.stderr:
                _notice(result.stderr)
                return False
            msg = f"Could not check resolution for {directory}: {result.stderr}"
            raise RuntimeError(msg)
    return True


def _compatible_plans(
    plans: Sequence[ManifestPlan], *, skip_dependents: bool
) -> tuple[list[ManifestPlan], list[RequirementEdit]]:
    """Keep jointly resolvable bumps, restoring original manifests on every exit."""
    originals = {
        plan.manifest_path: (REPO_ROOT / plan.manifest_path).read_text(encoding="utf-8")
        for plan in plans
    }
    try:
        for plan in plans:
            (REPO_ROOT / plan.manifest_path).write_text(plan.new_text, encoding="utf-8")
        if _resolves(originals, skip_dependents=skip_dependents):
            return list(plans), []
        for path, text in originals.items():
            (REPO_ROOT / path).write_text(text, encoding="utf-8")
        if not _resolves(originals, skip_dependents=skip_dependents):
            msg = (
                "Existing requirements do not resolve; "
                "cannot safely select minimum bumps."
            )
            raise RuntimeError(msg)
        return _select_resolvable_bumps(
            plans, originals, skip_dependents=skip_dependents
        )
    finally:
        for path, text in originals.items():
            (REPO_ROOT / path).write_text(text, encoding="utf-8")


def _select_resolvable_bumps(
    plans: Sequence[ManifestPlan],
    originals: Mapping[str, str],
    *,
    skip_dependents: bool,
) -> tuple[list[ManifestPlan], list[RequirementEdit]]:
    """Try each dependency across manifests against all previously accepted bumps."""
    accepted: list[RequirementEdit] = []
    skipped: list[RequirementEdit] = []
    grouped: dict[str, list[RequirementEdit]] = {}
    for plan in plans:
        for edit in plan.edits:
            grouped.setdefault(edit.dependency_name, []).append(edit)
    for name, edits in sorted(grouped.items()):
        before = {
            path: (REPO_ROOT / path).read_text(encoding="utf-8") for path in originals
        }
        for path, text in before.items():
            replacements = {
                edit.old_requirement: edit.new_requirement
                for edit in edits
                if edit.manifest_path == path
            }
            (REPO_ROOT / path).write_text(
                _apply_replacements(text, replacements, path), encoding="utf-8"
            )
        if _resolves(originals, skip_dependents=skip_dependents):
            accepted.extend(edits)
        else:
            _notice(
                f"Skipping {name}: raised minimums conflict with the dependency graph."
            )
            skipped.extend(edits)
            for path, text in before.items():
                (REPO_ROOT / path).write_text(text, encoding="utf-8")
    return [
        ManifestPlan(
            path,
            (REPO_ROOT / path).read_text(encoding="utf-8"),
            tuple(edit for edit in accepted if edit.manifest_path == path),
        )
        for path in originals
        if any(edit.manifest_path == path for edit in accepted)
    ], skipped


def _edit_markdown(edit: RequirementEdit) -> str:
    """Render the affected package and any extras or marker on its dependency."""
    project = tomllib.loads(
        (REPO_ROOT / edit.manifest_path).read_text(encoding="utf-8")
    )
    target = f"`{project['project']['name']}`"
    requirement = Requirement(edit.old_requirement)
    if requirement.extras:
        target += f" (extras: `{','.join(sorted(requirement.extras))}`)"
    if requirement.marker:
        target += f"; `{requirement.marker}`"
    return target.replace("|", r"\|")


def edits_markdown(edits: Sequence[RequirementEdit], *, heading: str) -> str:
    """Render package targets grouped by dependency and changed lower bounds."""
    grouped: dict[tuple[str, str, str], list[str]] = {}
    for edit in edits:
        old = _raiseable_specifier(Requirement(edit.old_requirement).specifier)
        new = _raiseable_specifier(Requirement(edit.new_requirement).specifier)
        key = (edit.dependency_name, str(old), str(new))
        grouped.setdefault(key, []).append(_edit_markdown(edit))
    lines = [heading, "", "| Dependency | Minimum | Targets |", "|---|---|---|"]
    for (dependency, old, new), targets in sorted(grouped.items()):
        lines.append(
            f"| `{dependency}` | `{old}` → `{new}` | {', '.join(sorted(targets))} |"
        )
    return "\n".join(lines)


def failures_markdown(dependencies: Sequence[str], manifests: Sequence[str]) -> str:
    """Render unresolved dependencies and manifests so a partial run looks partial."""
    lines: list[str] = ["### Not raised", ""]
    if dependencies:
        lines.append(
            "PyPI metadata could not be resolved for these dependencies, so their "
            "floors were left untouched: "
            + ", ".join(f"`{name}`" for name in dependencies)
            + "."
        )
        lines.append("")
    if manifests:
        lines.append(
            "These manifests could not be rewritten: "
            + ", ".join(f"`{path}`" for path in manifests)
            + "."
        )
        lines.append("")
    lines.append("Re-run the workflow once the cause is resolved.")
    return "\n".join(lines)


def _select_manifests(package: str, packages: Mapping[str, str]) -> list[str] | None:
    """Resolve a `--package` value to the manifests it selects, or `None` if unknown."""
    if package == "all":
        selected = sorted(packages)
    else:
        matched = [path for path, label in packages.items() if label == package]
        if not matched and package in packages:
            matched = [package]
        if not matched:
            labels = ", ".join(sorted(set(packages.values()))) or "none"
            _error(
                f"Unknown package '{package}'. Expected a release label "
                f"({labels}), a release path, or 'all'."
            )
            return None
        selected = sorted(matched)
    return [f"{path}/pyproject.toml" for path in selected]


def _run(
    package: str,
    narrow_to: frozenset[str] | None = None,
    *,
    skip_dependent_locks: bool = False,
    check_resolution: bool = False,
) -> int:
    """Raise in-scope lower bounds for `package`, writing manifests and outputs.

    When `narrow_to` is provided, only those distribution names are raised
    instead of every dependency matching `IN_SCOPE_PREFIXES`.
    """
    manifests = _select_manifests(package, load_release_packages())
    if manifests is None:
        return 1
    _notice(f"Raising dependency minimums for {package}: " + ", ".join(manifests))
    if narrow_to is not None:
        _notice("Restricted to dependencies: " + ", ".join(sorted(narrow_to)))

    scopes = [_load_scope(manifest_path, narrow_to) for manifest_path in manifests]
    in_scope_names = {
        canonicalize_name(requirement.name)
        for scope in scopes
        for _, requirement in scope.requirements
    }
    if narrow_to:
        # Report every requested name that resolved to nothing, not just the
        # all-miss case: narrowing to `langchain-core,langsmiht` otherwise
        # raises one bound and never mentions the typo, so the run reads as
        # having done what was asked. Fail closed, as with fetch failures below.
        missing = narrow_to - in_scope_names
        if missing:
            workspace = missing & {
                name for scope in scopes for name in scope.workspace_names
            }
            absent = missing - workspace
            reasons = []
            if absent:
                reasons.append(
                    "not declared as a PyPI requirement of "
                    f"{package}: {', '.join(sorted(absent))}"
                )
            if workspace:
                reasons.append(
                    "declared but resolved from the workspace (a URL, the "
                    "package itself, or a [tool.uv.sources] entry without a "
                    "readable local version), so there is no PyPI floor to "
                    f"raise: {', '.join(sorted(workspace))}"
                )
            _error(
                f"Requested dependencies were not raised for {package} — "
                + "; ".join(reasons)
                + ". Check the spelling, or drop --dependencies to raise every "
                "in-scope bound. Not reporting a partial run as complete."
            )
            return 1

    if not in_scope_names:
        # Every release package declares in-scope dependencies, so an empty set
        # means the manifests are shaped differently than this script expects —
        # a defect to surface, not a quiet no-op.
        _error(
            f"No in-scope requirements found for {package}. Every release "
            "package declares some, so this most likely means the manifest "
            "layout changed and this script needs updating."
        )
        return 1

    available, fetch_failures = _fetch_available_versions(in_scope_names)

    plans: list[ManifestPlan] = []
    plan_failures: list[str] = []
    for scope in scopes:
        try:
            plan = _plan_manifest(scope, available)
        except (ValueError, InvalidRequirement) as err:
            # Isolate per manifest: a defect in one package's requirements must
            # not discard the valid bumps found for the other nine.
            _error(f"Could not rewrite {scope.manifest_path}: {err}")
            plan_failures.append(scope.manifest_path)
            continue
        if plan.edits:
            plans.append(plan)

    skipped: list[RequirementEdit] = []
    if check_resolution and plans:
        plans, skipped = _compatible_plans(plans, skip_dependents=skip_dependent_locks)
    skipped_summary = (
        edits_markdown(skipped, heading="### Skipped incompatible minimum bumps")
        if skipped
        else ""
    )
    all_edits = [edit for plan in plans for edit in plan.edits]
    if not all_edits:
        if skipped:
            print(skipped_summary)
            _write_output("changed", "false")
            _write_output("summary", skipped_summary)
            return 1 if fetch_failures or plan_failures else 0
        if fetch_failures or plan_failures:
            _error(
                f"No minimums could be raised for {package} and some inputs "
                "failed to resolve; see the warnings above. Not reporting this "
                "as up to date."
            )
            return 1
        if narrow_to:
            # Every requested name is present (checked above) but none produced
            # an edit. Distinguish why: a name whose requirements only ever
            # appear as exact `==` pins or with no lower bound has no floor to
            # raise, so it can never be bumped — answering green tells the
            # operator the bump happened when it never could. A name that does
            # declare a raiseable floor and is already at the latest compatible
            # release is genuinely current, which stays a no-op success.
            raiseable_names = {
                canonicalize_name(requirement.name)
                for scope in scopes
                for _, requirement in scope.requirements
                if _raiseable_specifier(requirement.specifier) is not None
            }
            unraiseable = narrow_to - raiseable_names
            if unraiseable:
                _error(
                    f"Requested dependencies of {package} have no raiseable "
                    "floor — each is an exact `==` pin or declares no lower "
                    f"bound, so there is nothing to raise: "
                    f"{', '.join(sorted(unraiseable))}. Not reporting this as "
                    "up to date."
                )
                return 1
            _notice(
                f"All requested dependencies of {package} are already at the "
                "latest compatible stable release; nothing to do."
            )
            return 0
        _notice(
            f"All in-scope minimums for {package} are already at or above the "
            "latest compatible stable PyPI releases; nothing to do."
        )
        return 0

    for plan in plans:
        (REPO_ROOT / plan.manifest_path).write_text(plan.new_text, encoding="utf-8")

    noun = "minimum" if len(all_edits) == 1 else "minimums"
    summary = edits_markdown(
        all_edits, heading=f"Raised {len(all_edits)} dependency {noun}:"
    )
    if skipped_summary:
        summary += "\n\n" + skipped_summary
    if fetch_failures or plan_failures:
        summary += "\n\n" + failures_markdown(fetch_failures, plan_failures)
    print(summary)

    changed_files = sorted(plan.manifest_path for plan in plans)
    lock_dirs = lock_dirs_for(changed_files, skip_dependents=skip_dependent_locks)
    _write_output("changed", "true")
    _write_output("changed_files", ",".join(changed_files))
    _write_output("lock_dirs", ",".join(lock_dirs))
    # `dir=python` pairs so the workflow locks with the same interpreter
    # `check_lockfiles.yml` will verify against.
    _write_output(
        "lock_specs",
        ",".join(f"{path}={python_version(REPO_ROOT / path)}" for path in lock_dirs),
    )
    # Deliberately not `_write_step_summary`: `GITHUB_STEP_SUMMARY` is a per-step
    # file uploaded when the step ends, so the table can only appear *after* the
    # PR link if the step that learns the PR outcome emits both. The workflow
    # replays this output in that step's own summary.
    _write_output("summary", summary)
    return 0


def _parse_dependency_csv(value: str) -> frozenset[str] | None:
    """Parse a comma-separated distribution-name list, or `None` when empty.

    Canonicalizes each entry so PEP 503 spelling differences (`LangChain-Core`
    vs `langchain-core`) still match manifest names. An empty string means
    "no narrowing" and returns `None` so the prefix scope applies.
    """
    names = frozenset(
        canonicalize_name(entry.strip()) for entry in value.split(",") if entry.strip()
    )
    return names or None


def _branch_name(package: str, dependencies: Collection[str] | None) -> str:
    """Return the canonical branch identity for a package and dependency set."""
    suffix = ""
    if dependencies:
        names = sorted({canonicalize_name(name) for name in dependencies})
        suffix = "-" + "-".join(names)
    return f"chore/raise-dependency-minimums-{package}{suffix}"


def main() -> int:
    """Entry point: raise in-scope lower bounds for the selected package(s)."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--package",
        required=True,
        help=(
            "Release component label (or its release path), or 'all' for every "
            "release package."
        ),
    )
    parser.add_argument(
        "--dependencies",
        default="",
        help=(
            "Comma-separated PyPI distribution names to restrict the run to "
            "(e.g. 'langchain-core,langsmith'). When empty, every dependency "
            "matching IN_SCOPE_PREFIXES is raised."
        ),
    )
    parser.add_argument("--skip-dependent-locks", action="store_true")
    parser.add_argument(
        "--check-resolution",
        action="store_true",
        help="Skip minimum bumps that uv cannot resolve, including reverse dependents.",
    )
    args = parser.parse_args()
    try:
        dependencies = _parse_dependency_csv(args.dependencies)
        _write_output("branch", _branch_name(args.package, dependencies))
        return _run(
            args.package,
            dependencies,
            skip_dependent_locks=args.skip_dependent_locks,
            check_resolution=args.check_resolution,
        )
    except Exception as err:  # noqa: BLE001  # fail closed on script defects
        _error(f"Raising dependency minimums failed unexpectedly: {err}")
        return 2


if __name__ == "__main__":
    sys.exit(main())
