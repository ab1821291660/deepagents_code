import shard_matrix
import unified_prep as up


def test_parse_int_input_enforces_inclusive_range():
    import pytest

    assert up.parse_int_input("UNIFIED_CONCURRENCY", "1", minimum=1, maximum=40) == 1
    assert up.parse_int_input("UNIFIED_CONCURRENCY", "40", minimum=1, maximum=40) == 40
    for raw in ("0", "41", "-1", "", "1.5", "many"):
        with pytest.raises(SystemExit, match=r"UNIFIED_CONCURRENCY.*1\.\.40"):
            up.parse_int_input("UNIFIED_CONCURRENCY", raw, minimum=1, maximum=40)

def test_retry_and_timeout_inputs_are_strictly_validated():
    import pytest

    assert up.parse_nonnegative_integer_input("UNIFIED_N_RETRIES", "0") == 0
    assert up.parse_nonnegative_integer_input("UNIFIED_N_RETRIES", "2") == 2
    for raw in ("", "-1", "+1", "1.5", "many"):
        with pytest.raises(SystemExit, match=r"UNIFIED_N_RETRIES.*non-negative"):
            up.parse_nonnegative_integer_input("UNIFIED_N_RETRIES", raw)

    for raw in ("1", "1.0", "1.5", "2.0", "0.1"):
        assert (
            up.parse_positive_decimal_input("UNIFIED_AGENT_TIMEOUT_MULTIPLIER", raw)
            == raw
        )
    for raw in ("", "0", "0.0", "-1", "+1", ".5", "1e2", "many"):
        with pytest.raises(
            SystemExit, match=r"UNIFIED_AGENT_TIMEOUT_MULTIPLIER.*positive"
        ):
            up.parse_positive_decimal_input("UNIFIED_AGENT_TIMEOUT_MULTIPLIER", raw)

def test_main_rejects_invalid_retry_controls_before_building_matrix(
    tmp_path, monkeypatch
):
    import pytest

    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "context")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))

    monkeypatch.setenv("UNIFIED_AGENT_TIMEOUT_MULTIPLIER", "1.0")
    for raw in ("-1", "1.5", "many"):
        monkeypatch.setenv("UNIFIED_N_RETRIES", raw)
        with pytest.raises(SystemExit, match=r"UNIFIED_N_RETRIES"):
            up.main([])

    monkeypatch.setenv("UNIFIED_N_RETRIES", "0")
    for raw in ("0", "-1", "1e2", "many"):
        monkeypatch.setenv("UNIFIED_AGENT_TIMEOUT_MULTIPLIER", raw)
        with pytest.raises(SystemExit, match=r"UNIFIED_AGENT_TIMEOUT_MULTIPLIER"):
            up.main([])

def test_provider_of_uses_prefix_and_falls_back_to_other():
    known = {"anthropic", "openai"}
    assert up.provider_of("anthropic:claude-opus-4-7", known) == "anthropic"
    assert up.provider_of("weirdvendor:x", known) == "other"

def test_resolve_branch_sha_uses_ls_remote_argument_list(monkeypatch):
    import subprocess

    calls = []

    def fake_run(args, *, check, capture_output, text):
        calls.append((args, check, capture_output, text))
        return subprocess.CompletedProcess(
            args, 0, stdout="a" * 40 + "\trefs/heads/feature/x\n", stderr=""
        )

    monkeypatch.setattr(subprocess, "run", fake_run)

    assert up._resolve_branch_sha("feature/x") == "a" * 40
    assert calls == [
        (
            ["git", "ls-remote", "--exit-code", "origin", "refs/heads/feature/x"],
            True,
            True,
            True,
        )
    ]

def test_resolve_branch_sha_rejects_unsafe_refs():
    import pytest

    for branch in ("../bad", "-main", "feature*"):
        with pytest.raises(SystemExit, match=r"Invalid branch ref"):
            up._resolve_branch_sha(branch)

def test_derive_pool_from_concurrency_and_rollouts():
    # Packed shards use full concurrency: conc 4 -> 40//4=10 ; 80//10=8 capped to n_groups
    assert up.derive_pool(concurrency=4, rollouts=3, n_shards=34, n_groups=1) == (10, 1)
    # concurrency 1 -> 40//1=40 ; 80//40=2
    assert up.derive_pool(concurrency=1, rollouts=3, n_shards=100, n_groups=5) == (40, 2)
    # Lower rollouts do not reduce a packed shard's peak concurrency.
    assert up.derive_pool(concurrency=4, rollouts=2, n_shards=100, n_groups=1)[0] == 10
    # clamp inner to n_shards when few tasks; outer clamps to n_groups
    assert up.derive_pool(concurrency=1, rollouts=3, n_shards=8, n_groups=1) == (8, 1)

def test_main_rejects_invalid_agent_impl(tmp_path, monkeypatch):
    import pytest

    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))
    monkeypatch.setenv("UNIFIED_AGENT_IMPLS", "nonexistent-graph")
    with pytest.raises(SystemExit, match=r"UNIFIED_AGENT_IMPLS entries must be in"):
        up.main()

def test_category_map_guard_rejects_entry_missing_fan_out():
    import pytest

    malformed = {
        "autonomous": {"agent_impl": "bare", "fan_out": True},
        "broken": {"agent_impl": "bare"},  # missing "fan_out"
    }
    with pytest.raises(RuntimeError, match=r"'broken'.*agent_impl.*fan_out"):
        up._validate_category_map_keys(malformed)

def test_derive_impl_sets_new_graph_is_selectable():
    cats = {
        "autonomous": {"agent_impl": "bare", "fan_out": True},
        "conversation": {"agent_impl": "tau3", "fan_out": False},
        "context": {"agent_impl": "bare", "fan_out": True},
    }
    known, code = up.derive_impl_sets({"bare", "dcode", "tau3", "foo"}, cats)
    assert known == {"bare", "dcode", "tau3", "foo"}
    assert "foo" in code
    assert "tau3" not in code

def test_native_harbor_impls_accept_all_categories_and_match_provider(tmp_path, monkeypatch):
    import pytest

    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "out"))
    for impl, model in (("codex", "openai:gpt-5.6-sol"), ("claude-code", "anthropic:claude-sonnet-5"), ("pi", "anthropic:claude-sonnet-5")):
        monkeypatch.setenv("UNIFIED_AGENT_IMPLS", impl)
        monkeypatch.setenv("UNIFIED_MODELS", model)
        assert up.main() == 0
        monkeypatch.setenv("UNIFIED_MODELS", "google_genai:gemini-2.5-pro")
        with pytest.raises(SystemExit, match="requires an .* model"):
            up.main()
        monkeypatch.setenv("UNIFIED_MODELS", model)
        monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous,conversation,context,research")
        assert up.main() == 0
        monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
        monkeypatch.setenv("UNIFIED_BRANCHES", "feature/branch")
        with pytest.raises(SystemExit, match="no branches_to_compare"):
            up.main()
        monkeypatch.delenv("UNIFIED_BRANCHES")


def test_claude_code_rejects_minimal_reasoning_effort(tmp_path, monkeypatch):
    import pytest

    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "out"))
    monkeypatch.setenv("UNIFIED_AGENT_IMPLS", "claude-code")
    monkeypatch.setenv("UNIFIED_MODELS", "anthropic:claude-sonnet-5")
    monkeypatch.setenv("UNIFIED_REASONING_EFFORT", "minimal")
    with pytest.raises(SystemExit, match="reasoning_effort=minimal"):
        up.main()
    monkeypatch.setenv("UNIFIED_REASONING_EFFORT", "high")
    assert up.main() == 0


def test_module_impl_sets_match_registry():
    assert up.KNOWN_AGENT_IMPLS == {"bare", "dcode", "tau3", "codex", "claude-code", "pi"}
    assert up.CODE_AGENT_IMPLS == {"bare", "dcode", "codex", "claude-code", "pi"}

def test_main_rejects_invalid_profile(tmp_path, monkeypatch):
    import pytest

    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))
    monkeypatch.setenv("UNIFIED_PROFILE", "medium")
    with pytest.raises(SystemExit, match=r"UNIFIED_PROFILE must be one of"):
        up.main()

def test_main_dedupes_repeated_categories(tmp_path, monkeypatch):
    import lite_tasks

    monkeypatch.setenv("UNIFIED_MODELS", "anthropic:opus")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "context,context,context")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))
    assert up.main([]) == 0
    import json as _j

    lines = dict(line.split("=", 1) for line in (tmp_path / "o").read_text().splitlines())
    assert _j.loads(lines["categories"]) == ["context"]  # one entry, not three
    # the flat matrix isn't tripled either: one shard per context task
    eval_matrix = _j.loads(lines["eval_matrix"])["include"]
    matrix = _j.loads(eval_matrix[0]["flat_matrix"])["include"]
    assert len(matrix) == len(lite_tasks.LITE_TASKS["context"])

def test_context_lite_tasks_pin_the_recalibrated_candidate():
    import lite_tasks

    assert lite_tasks.LITE_TASKS["context"] == [
        "cb-cloud-48",
        "cb-cloud-1",
        "cb-cloud-21",
        "cb-cloud-49",
        "cb-cloud-65",
        "cb-cloud-69",
        "cb-cloud-57",
        "cb-cloud-9",
        "cb-cloud-7",
        "cb-cloud-4",
    ]

def test_research_category_points_at_the_drbench_dataset():
    assert up.CATEGORY_MAP["research"] == {
        "dataset": "",
        "dataset_path": "datasets/drbench-evals",
        "agent_impl": "bare",
        "fan_out": True,
        # Pinned, not inherited: upstream's task images are arm64-only and served by the
        # local docker sandbox, and one runner cannot hold two concurrent app stacks.
        "runner": "ubuntu-24.04-arm",
        "sandbox_env": "docker",
        "concurrency": 1,
    }


def test_only_research_pins_its_runtime():
    # Every other category must inherit the dispatch inputs, or a mixed run would silently
    # move autonomous/conversation onto a runner they have never been validated on.
    for category, entry in up.CATEGORY_MAP.items():
        pinned = {key for key in up._CATEGORY_OVERRIDES if key in entry}
        assert pinned == (set(up._CATEGORY_OVERRIDES) if category == "research" else set()), (
            f"{category} pins {sorted(pinned)}"
        )


def test_flat_matrix_entries_always_carry_the_override_keys():
    # The workflow reads `matrix.<key> || inputs.<key>`. A missing key makes that expression
    # evaluate against an undefined matrix value, so every entry carries all three.
    entries = up.build_flat_matrix(
        model="anthropic:claude-opus-5",
        categories=["autonomous", "research"],
        tasks_by_cat={"autonomous": ["a1"], "research": ["DR0001"]},
    )
    by_cat = {e["category"]: e for e in entries}
    for key in up._CATEGORY_OVERRIDES:
        assert key in by_cat["autonomous"] and key in by_cat["research"]
    assert by_cat["autonomous"]["runner"] == ""
    assert by_cat["autonomous"]["sandbox_env"] == ""
    assert by_cat["autonomous"]["concurrency"] == ""
    assert by_cat["research"]["runner"] == "ubuntu-24.04-arm"
    assert by_cat["research"]["sandbox_env"] == "docker"
    assert by_cat["research"]["concurrency"] == 1

def test_local_dataset_categories_exist_on_disk():
    # A CATEGORY_MAP dataset_path that does not exist would fail only mid-run, after the
    # matrix has already fanned out, so pin it here.
    from pathlib import Path

    repo_root = Path(up.__file__).resolve().parents[3]
    for category, entry in up.CATEGORY_MAP.items():
        path = entry["dataset_path"]
        if not path:
            continue
        dataset_dir = repo_root / "libs" / "evals" / path
        assert (dataset_dir / "dataset.toml").is_file(), f"{category}: {dataset_dir}"

def test_lite_task_ids_exist_in_their_local_dataset():
    # Lite runs pass these as `--include-task-name`; a stale id silently narrows the run
    # (or empties a shard) instead of failing, so check them against the real task list.
    import json
    from pathlib import Path

    import lite_tasks

    # Datasets whose task directories are generated from an upstream pin rather than
    # committed declare their authoritative id list here: their directory holds no task
    # until it is built, so there is nothing on disk for this job to look at.
    generated_task_lists = {
        "datasets/drbench-evals": "harbor_adapters/drbench/vendor/subsets/val.jsonl",
    }

    repo_root = Path(up.__file__).resolve().parents[3]
    for category, entry in up.CATEGORY_MAP.items():
        path = entry["dataset_path"]
        if not path:
            continue
        expected = lite_tasks.LITE_TASKS.get(category, [])
        subset = generated_task_lists.get(path)
        if subset:
            known = {
                json.loads(line)["task_id"]
                for line in (repo_root / "libs" / "evals" / subset)
                .read_text(encoding="utf-8")
                .splitlines()
                if line.strip()
            }
            for task_id in expected:
                assert task_id in known, f"{category}: {task_id}"
            continue
        dataset_dir = repo_root / "libs" / "evals" / path
        for task_id in expected:
            assert (dataset_dir / task_id / "task.toml").is_file(), f"{category}: {task_id}"

def test_every_category_has_a_lite_subset():
    # `include_tasks` returns '' for an unlisted category, which makes a lite run
    # silently execute the FULL dataset rather than the low-cost slice.
    import lite_tasks

    missing = [c for c in up.CATEGORY_MAP if not lite_tasks.LITE_TASKS.get(c)]
    assert missing == []

def test_main_rejects_invalid_concurrency(tmp_path, monkeypatch):
    monkeypatch.setenv("UNIFIED_MODELS", "anthropic:opus")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "context")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))
    import pytest

    for raw in ("not-an-integer", "", "1.5", "-1", "0", "41"):
        monkeypatch.setenv("UNIFIED_CONCURRENCY", raw)
        with pytest.raises(SystemExit, match=r"UNIFIED_CONCURRENCY.*1\.\.40"):
            up.main([])

def test_main_rejects_bad_spec(tmp_path, monkeypatch):
    monkeypatch.setenv("UNIFIED_MODELS", "no-colon-here")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "context")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))
    import pytest

    with pytest.raises(SystemExit):
        up.main([])

def test_main_rejects_empty_categories(tmp_path, monkeypatch):
    # whitespace/comma-only resolves to an empty category list; must not silently
    # skip every job and emit a "successful" empty artifact.
    monkeypatch.setenv("UNIFIED_MODELS", "anthropic:opus")
    monkeypatch.setenv("UNIFIED_CATEGORIES", " , ")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))
    import pytest

    with pytest.raises(SystemExit):
        up.main([])

def test_main_rejects_empty_requested_category(tmp_path, monkeypatch):
    import json
    import pytest

    tasks = tmp_path / "tasks.json"
    tasks.write_text(json.dumps({"autonomous": ["task-1"]}))
    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous,context")
    monkeypatch.setenv("UNIFIED_PROFILE", "full")
    monkeypatch.setenv("UNIFIED_TASKS_JSON", str(tasks))
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))

    with pytest.raises(SystemExit, match=r"No tasks resolved.*context"):
        up.main([])

def test_main_include_tasks_narrows_categories(tmp_path, monkeypatch):
    # An explicit task selection drops categories that hold none of the requested
    # tasks instead of failing the empty-category guard against the original
    # selection. Requesting a single context task from the default category set
    # must run only that task, not abort on the untouched autonomous/conversation
    # categories.
    import json as _j

    tasks = tmp_path / "tasks.json"
    tasks.write_text(
        _j.dumps(
            {
                "autonomous": ["auto-1"],
                "conversation": ["conv-1"],
                "context": ["cb-cloud-5", "cb-cloud-26"],
            }
        )
    )
    monkeypatch.setenv("UNIFIED_MODELS", "anthropic:opus")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous,conversation,context")
    monkeypatch.setenv("UNIFIED_PROFILE", "full")
    monkeypatch.setenv("UNIFIED_TASKS_JSON", str(tasks))
    monkeypatch.setenv("UNIFIED_INCLUDE_TASKS", "cb-cloud-5")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))

    assert up.main([]) == 0

    lines = dict(line.split("=", 1) for line in (tmp_path / "o").read_text().splitlines())
    assert _j.loads(lines["categories"]) == ["context"]
    leaf_categories = {leaf["category"] for leaf in _j.loads(lines["expected_leaves"])}
    assert leaf_categories == {"context"}

def test_main_emits_expected_models_and_categories(tmp_path, monkeypatch):
    monkeypatch.setenv("UNIFIED_MODELS", "anthropic:opus, openai:gpt")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous,context")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))
    assert up.main([]) == 0
    import json as _j

    lines = dict(line.split("=", 1) for line in (tmp_path / "o").read_text().splitlines())
    assert _j.loads(lines["models"]) == ["anthropic:opus", "openai:gpt"]
    assert _j.loads(lines["categories"]) == ["autonomous", "context"]

def test_total_job_guard_allows_within_budget():
    up.total_job_guard(total_jobs=360)  # <= 400, no raise

def test_total_job_guard_allows_at_budget():
    # Boundary is `> TOTAL_JOB_BUDGET`, so exactly at the budget must not raise.
    up.total_job_guard(total_jobs=up.TOTAL_JOB_BUDGET)

def test_total_job_guard_rejects_over_budget():
    import pytest

    with pytest.raises(SystemExit, match=r"TOTAL_JOB_BUDGET"):
        up.total_job_guard(total_jobs=up.TOTAL_JOB_BUDGET + 1)

def test_total_job_guard_rejects_zero_jobs():
    import pytest

    with pytest.raises(SystemExit, match=r"no jobs"):
        up.total_job_guard(total_jobs=0)

def test_build_flat_matrix_expands_code_categories_over_configs():
    tasks = {"autonomous": ["a1", "a2"], "context": ["c1"]}
    entries = up.build_flat_matrix(
        "openai:gpt", ["autonomous", "context"], tasks, code_impls=["bare", "dcode"]
    )
    autos = [e for e in entries if e["category"] == "autonomous"]
    impls = sorted({e["agent_impl"] for e in autos})
    assert impls == ["bare", "dcode"]
    # Each config gets the full task set for the category.
    assert sum(len(e["include_tasks"].split()) for e in autos if e["agent_impl"] == "bare") == 2
    # The rest of the entry schema is untouched: existing keys keep the
    # category's CATEGORY_MAP values and the fixed 1-task/shard fields.
    cm = up.CATEGORY_MAP["autonomous"]
    entry = autos[0]
    assert entry["dataset"] == cm["dataset"]
    assert entry["dataset_path"] == cm["dataset_path"]
    assert entry["langsmith_dataset"] == ""
    assert entry["n_shards"] == 1
    assert entry["shard"] == 0

def test_build_flat_matrix_conversation_not_multiplied_by_configs():
    tasks = {"autonomous": ["a1"], "conversation": ["t1", "t2"]}
    entries = up.build_flat_matrix(
        "openai:gpt", ["autonomous", "conversation"], tasks, code_impls=["bare", "dcode"]
    )
    conv = [e for e in entries if e["category"] == "conversation"]
    assert {e["agent_impl"] for e in conv} == {"tau3"}
    assert len(conv) == 2  # two tasks, one config, one task per shard

def test_build_flat_matrix_conversation_includes_native_harbor_agents():
    tasks = {"conversation": ["t1", "t2"]}
    entries = up.build_flat_matrix("openai:gpt", ["conversation"], tasks, code_impls=["bare", "codex"])
    assert {e["agent_impl"] for e in entries} == {"tau3", "codex"}
    assert len(entries) == 4


def test_build_flat_matrix_defaults_to_bare_single_config():
    tasks = {"autonomous": ["a1"], "conversation": ["t1"]}
    entries = up.build_flat_matrix("openai:gpt", ["autonomous", "conversation"], tasks)
    auto = next(e for e in entries if e["category"] == "autonomous")
    conv = next(e for e in entries if e["category"] == "conversation")
    assert auto["agent_impl"] == "bare"
    assert conv["agent_impl"] == "tau3"

def test_build_flat_matrix_caps_entries_at_max_shards():
    # Two code categories x two configs x 60 tasks = 240 groups pre-pack, over
    # MAX_SHARDS; packing must keep the emitted entry count within the cap while
    # preserving every task exactly once per (category, config) group.
    tasks = {
        "autonomous": [f"a{i}" for i in range(60)],
        "context": [f"c{i}" for i in range(60)],
    }
    entries = up.build_flat_matrix(
        "openai:gpt",
        ["autonomous", "context"],
        tasks,
        code_impls=["bare", "dcode"],
    )
    assert len(entries) <= shard_matrix.MAX_SHARDS
    # Task fidelity: for each (category, config), the union of the group's
    # packed include_tasks equals the original task list exactly (order
    # preserved, every task present once, no drops or duplication).
    for cat in ("autonomous", "context"):
        for impl in ("bare", "dcode"):
            seen = [
                t
                for e in entries
                if e["category"] == cat and e["agent_impl"] == impl
                for t in e["include_tasks"].split()
            ]
            assert seen == tasks[cat]

def test_build_flat_matrix_dedupes_duplicate_configs():
    # A repeated config collapses to a single config: ["bare", "bare"] yields
    # the same entries as ["bare"] (guards the cap invariant, see Fix 1).
    tasks = {"autonomous": ["a1", "a2"], "context": ["c1"]}
    once = up.build_flat_matrix("openai:gpt", ["autonomous", "context"], tasks, code_impls=["bare"])
    twice = up.build_flat_matrix(
        "openai:gpt", ["autonomous", "context"], tasks, code_impls=["bare", "bare"]
    )
    assert twice == once

def test_main_emits_per_model_flat_matrix_lite(tmp_path, monkeypatch):
    import json as _j

    out = tmp_path / "o"
    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt, anthropic:opus")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous,conversation,context")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("UNIFIED_CONCURRENCY", "4")
    monkeypatch.setenv("UNIFIED_ROLLOUTS", "3")
    monkeypatch.setenv("GITHUB_OUTPUT", str(out))
    assert up.main([]) == 0
    lines = dict(line.split("=", 1) for line in out.read_text().splitlines())
    assert lines["max_parallel"] == "10"  # conc4 -> 40//4 (packed shard = full conc)
    assert lines["model_parallel"] == "2"  # 80//10=8 -> min(8, 2 groups)
    eval_matrix = _j.loads(lines["eval_matrix"])["include"]
    assert len(eval_matrix) == 2  # one entry per (model, branch); default branch=current
    assert {e["model"] for e in eval_matrix} == {"openai:gpt", "anthropic:opus"}
    assert {e["branch"] for e in eval_matrix} == {"current"}
    for entry in eval_matrix:
        assert set(entry) == {"model", "branch", "branch_sha", "flat_matrix"}
        flat = _j.loads(entry["flat_matrix"])["include"]
        # lite totals 15+11+10 = 36 single-task shards per model
        assert len(flat) == 36
        assert {e["category"] for e in flat} == {
            "autonomous",
            "conversation",
            "context",
        }
    # No other output carries per-model or per-provider data; eval_matrix is
    # the single source for both.
    assert "model_slugs" not in lines
    assert "model_0_matrix" not in lines
    assert "openai_matrix" not in lines

def test_main_filters_lite_profile_to_exact_tasks(tmp_path, monkeypatch):
    import json as _j

    import lite_tasks

    # Derive the selection from the live frontier (in a non-sorted order) so the
    # test survives context-frontier recalibrations while still proving the filter
    # restricts to the requested tasks and preserves request order.
    context_tasks = lite_tasks.LITE_TASKS["context"]
    selection = [context_tasks[2], context_tasks[0], context_tasks[5]]

    monkeypatch.setattr(up, "_resolve_branch_sha", lambda branch: "a" * 40)
    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt-5.6-luna")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "context")
    monkeypatch.setenv("UNIFIED_AGENT_IMPLS", "bare")
    monkeypatch.setenv("UNIFIED_BRANCHES", "main,feature")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("UNIFIED_INCLUDE_TASKS", ",".join(selection))
    out = tmp_path / "out"
    monkeypatch.setenv("GITHUB_OUTPUT", str(out))

    assert up.main([]) == 0

    matrix = _j.loads(
        next(
            line for line in out.read_text().splitlines() if line.startswith("eval_matrix=")
        ).split("=", 1)[1]
    )["include"]
    assert {entry["branch"] for entry in matrix} == {"main", "feature"}
    for entry in matrix:
        flat = _j.loads(entry["flat_matrix"])["include"]
        assert [item["include_tasks"] for item in flat] == selection

def test_main_rejects_unknown_included_task(tmp_path, monkeypatch):
    import pytest

    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt-5.6-luna")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "context")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("UNIFIED_INCLUDE_TASKS", "cb-cloud-does-not-exist")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "out"))

    with pytest.raises(SystemExit, match="UNIFIED_INCLUDE_TASKS"):
        up.main([])

def test_main_rejects_unknown_agent_impl(tmp_path, monkeypatch):
    import pytest

    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt-5.6-luna")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
    monkeypatch.setenv("UNIFIED_AGENT_IMPLS", "bare,bogus")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "out.txt"))
    with pytest.raises(SystemExit):
        up.main()

def test_derive_pool_divides_inner_by_branches():
    # conc 4 -> per_model=40//4=10; two branches -> inner=10//2=5; outer bounded by groups.
    inner, outer = up.derive_pool(concurrency=4, rollouts=3, n_shards=100, n_groups=2, n_branches=2)
    assert inner == 5
    assert outer == 2

def test_derive_pool_single_branch_matches_legacy():
    inner, outer = up.derive_pool(concurrency=4, rollouts=3, n_shards=100, n_groups=5, n_branches=1)
    assert (inner, outer) == (10, 5)

def test_main_rejects_more_branches_than_budget(tmp_path, monkeypatch):
    import pytest

    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt-5.6-luna")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("UNIFIED_CONCURRENCY", "40")  # budget_shards=40//40=1
    monkeypatch.setenv("UNIFIED_BRANCHES", ",".join(f"b{i}" for i in range(14)))
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "out.txt"))
    with pytest.raises(SystemExit):
        up.main()

def test_main_emits_model_branch_matrix(tmp_path, monkeypatch):
    import json as _j

    monkeypatch.setattr(up, "_resolve_branch_sha", lambda branch: "a" * 40)
    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt-5.6-luna")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
    monkeypatch.setenv("UNIFIED_AGENT_IMPLS", "bare,dcode")
    monkeypatch.setenv("UNIFIED_BRANCHES", "main,feature")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    out = tmp_path / "out.txt"
    monkeypatch.setenv("GITHUB_OUTPUT", str(out))
    up.main()
    text = out.read_text()
    matrix = _j.loads(
        next(line for line in text.splitlines() if line.startswith("eval_matrix=")).split("=", 1)[1]
    )
    pairs = {(e["model"], e["branch"]) for e in matrix["include"]}
    assert pairs == {("openai:gpt-5.6-luna", "main"), ("openai:gpt-5.6-luna", "feature")}
    assert all(
        set(e) == {"model", "branch", "branch_sha", "flat_matrix"} for e in matrix["include"]
    )
    assert {e["branch_sha"] for e in matrix["include"]} == {"a" * 40}
    leaves = _j.loads(
        next(
            line for line in text.splitlines() if line.startswith("expected_leaves=")
        ).split("=", 1)[1]
    )
    assert {leaf["branch"] for leaf in leaves} == {"main", "feature"}
    assert all(
        {"model", "branch", "source_sha", "config", "category"} <= set(leaf)
        for leaf in leaves
    )
    outputs = dict(line.split("=", 1) for line in text.splitlines())
    assert _j.loads(outputs["sources"]) == [
        {"branch": "main", "sha": "a" * 40},
        {"branch": "feature", "sha": "a" * 40},
    ]

def test_main_total_job_guard_counts_branches(tmp_path, monkeypatch):
    import json
    import pytest

    tasks = tmp_path / "tasks.json"
    tasks.write_text(json.dumps({"autonomous": [f"task-{i}" for i in range(401)]}))
    monkeypatch.setattr(up, "_resolve_branch_sha", lambda branch: "a" * 40)
    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
    monkeypatch.setenv("UNIFIED_PROFILE", "full")
    monkeypatch.setenv("UNIFIED_TASKS_JSON", str(tasks))
    monkeypatch.setenv("UNIFIED_BRANCHES", "main,feature,release")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))

    with pytest.raises(SystemExit, match=r"TOTAL_JOB_BUDGET"):
        up.main([])

def test_main_rejects_over_256_outer_matrix(tmp_path, monkeypatch):
    # n_models * n_branches is the OUTER eval_matrix; GitHub caps a matrix at
    # shard_matrix.GITHUB_MATRIX_MAX (256) entries. 129 models x 2 branches = 258
    # must fail fast on that cap (not silently emit an over-cap matrix).
    import pytest

    assert up.shard_matrix.GITHUB_MATRIX_MAX == 256
    specs = ", ".join(f"openai:m{i}" for i in range(129))
    monkeypatch.setenv("UNIFIED_MODELS", specs)
    monkeypatch.setenv("UNIFIED_CATEGORIES", "context")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("UNIFIED_BRANCHES", "main,feature")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))
    with pytest.raises(SystemExit, match=r"256-entry matrix cap"):
        up.main([])

def test_main_default_branch_is_current(tmp_path, monkeypatch):
    import json as _j

    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt-5.6-luna")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    out = tmp_path / "out.txt"
    monkeypatch.setenv("GITHUB_OUTPUT", str(out))
    up.main()
    text = out.read_text()
    matrix = _j.loads(
        next(line for line in text.splitlines() if line.startswith("eval_matrix=")).split("=", 1)[1]
    )
    assert {e["branch"] for e in matrix["include"]} == {"current"}

def test_main_emits_expected_leaves_per_config(tmp_path, monkeypatch):
    import json as _j
    from collections import Counter

    import lite_tasks

    # `autonomous` has >1 lite task, so build_flat_matrix emits one entry per
    # task (many entries sharing the same (model, config, category) triple).
    # main's `seen_leaves` set must collapse each config's many entries to a
    # single leaf; this test fails if that dedup is removed.
    assert len(lite_tasks.LITE_TASKS["autonomous"]) > 1
    monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt-5.6-luna")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
    monkeypatch.setenv("UNIFIED_AGENT_IMPLS", "bare,dcode")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    out = tmp_path / "out.txt"
    monkeypatch.setenv("GITHUB_OUTPUT", str(out))
    up.main()
    text = out.read_text()
    line = next(ln for ln in text.splitlines() if ln.startswith("expected_leaves="))
    leaves = _j.loads(line.split("=", 1)[1])
    configs = {leaf["config"] for leaf in leaves if leaf["category"] == "autonomous"}
    assert configs == {"bare", "dcode"}
    # No duplicate (model, config, category) triples: dedup collapses the many
    # per-task shard entries to exactly one leaf each.
    triples = [(leaf["model"], leaf["config"], leaf["category"]) for leaf in leaves]
    assert len(triples) == len(set(triples))
    # Each config for the multi-task `autonomous` category appears exactly once
    # (would be len(LITE_TASKS["autonomous"]) per config if dedup were removed).
    autonomous_config_counts = Counter(
        leaf["config"] for leaf in leaves if leaf["category"] == "autonomous"
    )
    assert autonomous_config_counts == Counter({"bare": 1, "dcode": 1})

def test_derive_pool_budgets_packed_shards_at_full_concurrency():
    # A packed shard runs multiple tasks at full concurrency, so the per-model
    # budget divides MAX_TASKS_PER_MODEL by concurrency (not min(conc, rollouts)).
    tasks = {"autonomous": [f"harbor-index/a{i}" for i in range(260)]}
    entries = up.build_flat_matrix("openai:gpt", ["autonomous"], tasks)
    assert any(len(entry["include_tasks"].split()) > 1 for entry in entries)

    inner, _ = up.derive_pool(concurrency=4, rollouts=3, n_shards=len(entries), n_groups=1)
    assert inner == 10
    assert inner * 4 == up.MAX_TASKS_PER_MODEL

def test_build_flat_matrix_packs_above_cap():
    tasks = {"autonomous": [f"harbor-index/t{i}" for i in range(shard_matrix.MAX_SHARDS + 5)]}
    entries = up.build_flat_matrix("openai:gpt", ["autonomous"], tasks, code_impls=["dcode"])
    assert len(entries) <= shard_matrix.MAX_SHARDS
    # Every task still present, split across include_tasks strings.
    seen = " ".join(e["include_tasks"] for e in entries).split()
    assert seen == tasks["autonomous"]

def test_build_flat_matrix_below_cap_stays_one_task_per_shard():
    # Lite-like: total is well under MAX_SHARDS, so behavior is unchanged --
    # one task per matrix entry, no packing.
    tasks = {
        "autonomous": [f"harbor-index/a{i}" for i in range(15)],
        "conversation": [f"sierra-research/tau3-bench__c{i}" for i in range(11)],
        "context": [f"cb-cloud-{i}" for i in range(10)],
    }
    entries = up.build_flat_matrix(
        "openai:gpt",
        ["autonomous", "conversation", "context"],
        tasks,
        code_impls=["dcode"],
    )
    assert len(entries) == 15 + 11 + 10
    assert all(len(e["include_tasks"].split()) == 1 for e in entries)

def test_main_rejects_invalid_full_task_json_shape(tmp_path, monkeypatch):
    import json as _j

    import pytest

    # _load_tasks_json guards the enumerated task file against malformed
    # shapes: a non-dict top level, a non-list category value, or a list with
    # non-string tasks all fail fast with a clear message.
    for tasks in ({"autonomous": "taskname"}, ["taskname"], {"autonomous": ["task", 1]}):
        tasks_json = tmp_path / "tasks.json"
        tasks_json.write_text(_j.dumps(tasks))
        monkeypatch.setenv("UNIFIED_MODELS", "openai:gpt")
        monkeypatch.setenv("UNIFIED_CATEGORIES", "autonomous")
        monkeypatch.setenv("UNIFIED_PROFILE", "full")
        monkeypatch.setenv("UNIFIED_TASKS_JSON", str(tasks_json))
        monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))

        with pytest.raises(SystemExit, match=r"UNIFIED_TASKS_JSON must be a JSON object"):
            up.main([])


def test_main_emits_experiments_map(tmp_path, monkeypatch):
    """prep emits {experiment_name: expected_trials} for the usage collector."""
    import json as _j

    import experiment_name as en
    import lite_tasks

    monkeypatch.setenv("UNIFIED_MODELS", "anthropic:opus")
    monkeypatch.setenv("UNIFIED_CATEGORIES", "context")
    monkeypatch.setenv("UNIFIED_AGENT_IMPLS", "bare")
    monkeypatch.setenv("UNIFIED_PROFILE", "lite")
    monkeypatch.setenv("UNIFIED_ROLLOUTS", "2")
    monkeypatch.setenv("GITHUB_RUN_ID", "99")
    monkeypatch.setenv("GITHUB_RUN_ATTEMPT", "1")
    monkeypatch.setenv("GITHUB_OUTPUT", str(tmp_path / "o"))

    assert up.main([]) == 0
    lines = dict(line.split("=", 1) for line in (tmp_path / "o").read_text().splitlines())
    experiments = _j.loads(lines["experiments"])

    name = en.experiment_name(
        model="anthropic:opus",
        branch="current",
        config="bare",
        category="context",
        run_id="99",
        run_attempt="1",
    )
    assert name in experiments
    # expected = tasks-in-category * rollouts (the count the collector waits for).
    assert experiments[name] == len(lite_tasks.LITE_TASKS["context"]) * 2

def test_research_lite_is_exactly_upstreams_minival_subset():
    # The `research` lite profile claims to be DRBench's own MinEval set. The paper names
    # that subset but never lists its ids, so upstream's `minival.jsonl` (vendored) is the
    # only authoritative source. Without this the claim is just a comment.
    import json
    from pathlib import Path

    import lite_tasks

    repo_root = Path(up.__file__).resolve().parents[3]
    minival = (
        repo_root
        / "libs/evals/harbor_adapters/drbench/vendor/subsets/minival.jsonl"
    )
    upstream = [
        json.loads(line)["task_id"]
        for line in minival.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert len(upstream) == 15
    assert lite_tasks.LITE_TASKS["research"] == upstream

def test_research_full_extends_lite_and_matches_the_benchmark_split():
    # `full` for research is a 30-task proportional sample, not the whole 100. Two
    # properties make it defensible, and both must survive a dataset regeneration:
    #   - lite is a strict subset, so lite and full runs share comparable data points
    #   - its difficulty ratio equals the full corpus's (20:23:57 -> 6:7:17 at n=30)
    import collections
    import json
    from pathlib import Path

    import lite_tasks

    full = lite_tasks.FULL_TASKS["research"]
    lite = lite_tasks.LITE_TASKS["research"]
    assert len(full) == 30
    assert len(set(full)) == 30, "duplicate ids"
    assert set(lite) <= set(full)

    # Read the committed label record rather than a task config: no task directory is
    # committed any more (they are generated from a pinned upstream commit), and this
    # suite must stay offline.
    labels_path = (
        Path(up.__file__).resolve().parents[3]
        / "libs/evals/harbor_adapters/drbench/vendor/task_labels.json"
    )
    labels = json.loads(labels_path.read_text(encoding="utf-8"))["labels"]

    def info(task_id: str) -> dict:
        return labels[task_id]

    def industry(raw: object) -> str:
        text = str(raw).lower()
        if "retail" in text:
            return "retail"
        return "healthcare" if "health" in text else "automotive"

    difficulty = collections.Counter(info(t).get("difficulty") for t in full)
    assert dict(difficulty) == {"easy": 6, "medium": 7, "hard": 17}
    # Same ratio as the whole corpus, which is what makes 30 tasks a fair estimate of it.
    whole = collections.Counter(entry.get("difficulty") for entry in labels.values())
    assert dict(whole) == {"easy": 20, "medium": 23, "hard": 57}
    for level in ("easy", "medium", "hard"):
        assert difficulty[level] == round(whole[level] / 100 * 30)

    assert dict(collections.Counter(industry(info(t).get("industry")) for t in full)) == {
        "retail": 10,
        "healthcare": 10,
        "automotive": 10,
    }

def test_research_full_task_ids_all_exist():
    # Checked against upstream's own task list rather than the dataset directory: no task
    # directory is committed (they are generated from a pinned upstream commit), so the
    # directory is empty in any job that has not built it.
    import json
    from pathlib import Path

    import lite_tasks

    val = (
        Path(up.__file__).resolve().parents[3]
        / "libs/evals/harbor_adapters/drbench/vendor/subsets/val.jsonl"
    )
    known = {
        json.loads(line)["task_id"]
        for line in val.read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    assert len(known) == 100
    for task_id in lite_tasks.FULL_TASKS["research"]:
        assert task_id in known, task_id

def test_cap_full_profile_only_narrows_declared_categories():
    enumerated = {
        "research": ["DR0001", "DR0002", "DR0003"],
        "context": ["cb-cloud-1", "cb-cloud-2"],
    }
    capped = up.cap_full_profile(enumerated, {"research": ["DR0003", "DR0001"]})

    # Declared order wins, so the run order is reviewable from the registry.
    assert capped["research"] == ["DR0003", "DR0001"]
    # A category with no entry keeps the whole enumerated dataset.
    assert capped["context"] == ["cb-cloud-1", "cb-cloud-2"]

def test_cap_full_profile_rejects_a_stale_registry_id():
    # Silently dropping a renamed task would change the denominator of a published score
    # without anyone noticing, so a stale id has to fail the run.
    import pytest

    with pytest.raises(SystemExit, match=r"FULL_TASKS\['research'\].*DR9999"):
        up.cap_full_profile(
            {"research": ["DR0001"]}, {"research": ["DR0001", "DR9999"]}
        )

def test_cap_full_profile_defaults_to_the_real_registry():
    import lite_tasks

    declared = lite_tasks.FULL_TASKS["research"]
    # Feed it more than the registry declares; the cap must reduce to exactly the registry.
    enumerated = {"research": [f"DR{n:04d}" for n in range(1, 101)]}
    assert up.cap_full_profile(enumerated)["research"] == declared
