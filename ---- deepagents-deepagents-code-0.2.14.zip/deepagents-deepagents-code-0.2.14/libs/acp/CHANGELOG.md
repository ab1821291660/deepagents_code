<!-- markdownlint-disable MD024 -->

# Changelog

## [0.1.0](https://github.com/langchain-ai/deepagents/compare/deepagents-acp==0.0.13...deepagents-acp==0.1.0) (2026-11-20)

### ⚠ BREAKING CHANGES

- Requires `agent-client-protocol>=1.0.0,<2.0.0`. ([#7781](https://github.com/langchain-ai/deepagents/pull/7781))

### Bug Fixes

- Fixed a crash when running `dcode --acp` with agent-client-protocol 1.0. ([#7779](https://github.com/langchain-ai/deepagents/pull/7779))

## [0.0.13](https://github.com/langchain-ai/deepagents/compare/deepagents-acp==0.0.12...deepagents-acp==0.0.13) (2026-10-12)

### Bug Fixes

- Shell permissions now apply only to the exact commands authorized. ([#6881](https://github.com/langchain-ai/deepagents/pull/6881))
- Local context prompts are preserved across compaction. ([#6840](https://github.com/langchain-ai/deepagents/pull/6840))
- The demo now uses valid Claude 5.5 model IDs. ([#6684](https://github.com/langchain-ai/deepagents/pull/6684))

## [0.0.12](https://github.com/langchain-ai/deepagents/compare/deepagents-acp==0.0.11...deepagents-acp==0.0.12) (2026-09-18)

### Bug Fixes

- Scoped `cancel()` requests to the requested session. ([#5107](https://github.com/langchain-ai/deepagents/pull/5107))

## [0.0.11](https://github.com/langchain-ai/deepagents/compare/deepagents-acp==0.0.10...deepagents-acp==0.0.11) (2026-08-27)

### Features

- Stream visible reasoning as thought chunks. ([#5880](https://github.com/langchain-ai/deepagents/issues/5880))

## [0.0.10](https://github.com/langchain-ai/deepagents/compare/deepagents-acp==0.0.9...deepagents-acp==0.0.10) (2026-08-12)

### Features

- Added support for loading persistent ACP sessions ([#5365](https://github.com/langchain-ai/deepagents/issues/5365)).

## [0.0.9](https://github.com/langchain-ai/deepagents/compare/deepagents-acp==0.0.8...deepagents-acp==0.0.9) (2026-07-07)


### Bug Fixes

* **acp:** defer interrupt state reads until stream closes ([#4542](https://github.com/langchain-ai/deepagents/issues/4542)) ([35199ab](https://github.com/langchain-ai/deepagents/commit/35199ab22b2111474d1f46b3ad7cc677d82ed46b))

## [0.0.8](https://github.com/langchain-ai/deepagents/compare/deepagents-acp==0.0.7...deepagents-acp==0.0.8) (2026-06-03)

### Bug Fixes

* Require `agent-client-protocol>=0.9.0` ([#3733](https://github.com/langchain-ai/deepagents/issues/3733)) ([376d981](https://github.com/langchain-ai/deepagents/commit/376d9816833ef02a00fd4f1c4ccdf625629c36a4))

## [0.0.7](https://github.com/langchain-ai/deepagents/compare/deepagents-acp==0.0.6...deepagents-acp==0.0.7) (2026-06-03)

* Bumping dependencies

## [0.0.6](https://github.com/langchain-ai/deepagents/compare/deepagents-acp==0.0.5...deepagents-acp==0.0.6) (2026-04-18)

### Features

* Add Opus 4.7 and Baseten to demo agent ([#2787](https://github.com/langchain-ai/deepagents/issues/2787)) ([bfb16a6](https://github.com/langchain-ai/deepagents/commit/bfb16a645178f8134611d90b4aca4ddd43e2fdb9))

### Bug Fixes

* Restore passing tests after acp v0.9 schema bump ([#2813](https://github.com/langchain-ai/deepagents/issues/2813)) ([29a351a](https://github.com/langchain-ai/deepagents/commit/29a351a8f5de8c460a3eeaadd76a3c2ace0072e0))

---

## Prior Releases

Versions prior to 0.0.6 were released without release-please and do not have changelog entries. Refer to the [releases page](https://github.com/langchain-ai/deepagents/releases?q=deepagents-acp) for details on previous versions.
