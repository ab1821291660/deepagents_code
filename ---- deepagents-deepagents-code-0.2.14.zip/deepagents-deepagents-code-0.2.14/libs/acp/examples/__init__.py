"""Initialize the examples module."""
