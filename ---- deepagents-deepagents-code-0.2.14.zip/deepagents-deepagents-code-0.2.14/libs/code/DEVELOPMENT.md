# Deep Agents Code Development Guide

New to the package? Start with [`ARCHITECTURE.md`](./ARCHITECTURE.md) for a high-level map of how the TUI, the `langgraph dev` server subprocess, and the agent graph fit together.

## Contents

- [Quickstart](#quickstart) — get a local checkout running and run the checks CI enforces
- [LangSmith tracing projects](#langsmith-tracing-projects) — route dev traces away from the shared GA project
- [Local dev installs](#local-dev-installs) — keep an editable `dcode-dev` separate from a released install
- [Debugging](#debugging) — diagnose startup crashes and client-side issues
- [Live CSS development with Textual devtools](#live-css-development-with-textual-devtools) — UI/CSS hot-reload

## Quickstart

This package uses [`uv`](https://docs.astral.sh/uv/) for environment and dependency management. Install it first if you haven't:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Clone the monorepo and bootstrap the `code` package. This creates the virtualenv, installs test dependencies, and installs local git hooks (`pre-commit` + `commit-msg`) so the same checks can run before you push:

```bash
git clone https://github.com/langchain-ai/deepagents.git
cd deepagents/libs/code
make bootstrap
```

If you only want to sync dependencies without installing hooks, run `uv sync --group test` instead.

Run the TUI from `libs/code` in your local checkout:

```bash
uv run deepagents-code
```

`uv run` uses the project environment with the package installed editable, so source changes take effect on the next launch. If you want a persistent `dcode-dev` command that stays separate from a released install, use the local dev install setup below.

### Running the tests and linters

All commands run from `libs/code`. Before opening a PR, run the full local check suite:

```bash
make check
```

This runs linting, import checks, unit tests, and lockfile/version/extras checks.

For targeted checks while iterating:

```bash
# Unit tests (no network)
make test

# A single test file
make test TEST_FILE=tests/unit_tests/test_specific.py

# Integration tests (network permitted)
make integration_test
```

```bash
# Auto-format (ruff format + autofix)
make format

# Lint + type-check (ruff, ty, commands-catalog check)
make lint
```

Run `make help` to see every available target.

## Custom Slack MCP app identity

Slack's hosted MCP server attributes sent messages to the OAuth app used to connect. To use your own registered Slack app instead of Deep Agents Code, add an `oauth` object to its `.mcp.json` server entry:

```json
{
  "mcpServers": {
    "slack": {
      "type": "http",
      "url": "https://mcp.slack.com/mcp",
      "auth": "oauth",
      "oauth": {
        "client_id": "${SLACK_CLIENT_ID}",
        "client_secret": "${SLACK_CLIENT_SECRET}"
      }
    }
  }
}
```

Enable MCP access for your Slack app and register `http://localhost:3118/callback` as its redirect URL. Set the environment variables and run `dcode mcp login slack` to authorize it. Confidential apps use `client_secret_post`; omit `client_secret` only for an app registered as a public client. Keep secrets in environment variables, not committed config. The registration, including any secret, is saved in the existing restricted local token store.

Credentials are isolated by server name, URL, and configured client ID, so changing apps requires a separate login and never reuses the default app's grant. Re-run login after rotating a client secret. Omitting `oauth` preserves the existing app and credentials. This selects the authenticated app; it does not let a message supply arbitrary attribution or suppress Slack's footer. These settings apply to dcode; Talon's separate OAuth implementation is unchanged.

## LangSmith tracing projects

When LangSmith tracing is enabled and a `LANGSMITH_API_KEY` is available, `deepagents-code` traces its own agent runs to LangSmith. A key alone is not enough for environment-supplied keys — set `LANGSMITH_TRACING=true`. Keys stored via `/auth` auto- enable tracing unless you explicitly opt out (for example `DEEPAGENTS_CODE_LANGSMITH_TRACING=false`).

By default those runs land in the `deepagents-code` project, but the team routes shared runs to a GA project (`shared-deepagents-code`) that is monitored by LangSmith Engine, which raises high-priority Slack alerts on suspected issues.

**Do not point local development at the GA project.** Active development produces failures, half-finished branches, and experiments that Engine flags as issues — noise that buries the alerts that matter for the production project and costs the team triage time. Keep dev and prod runs in separate projects so Engine alerting on the GA project stays high-signal (this also mirrors LangSmith best practice of splitting dev and prod environments into distinct projects).

Route your local runs to a dev-scoped project via `DEEPAGENTS_CODE_LANGSMITH_PROJECT` (this overrides only the agent's own traces, leaving your shell's `LANGSMITH_PROJECT` for user code untouched):

```bash
# A shared dev bucket, or your own personal project — anything but the GA project
export DEEPAGENTS_CODE_LANGSMITH_PROJECT=shared-deepagents-code-dev
uv run deepagents-code
```

Set the same override for [local dev installs](#local-dev-installs) (`dcode-dev`), not only ad-hoc `uv run` sessions. You can also set it persistently under `[tracing]` in the config file (`tracing.langsmith_project`) or from the `/auth` screen. The startup splash and `/trace` show the project a run is writing to — confirm it is not the GA project before doing noisy work.

When onboarding a new tracing project to Engine, capture the nature of that project first: a production/GA app warrants high-priority alerts, while a staging or active-dev project should use looser thresholds (or stay off Engine) so it does not generate false positives.

A server keeps the first workspace's tracing configuration for its lifetime. Workspaces sharing that server must use matching tracing credentials, projects, endpoints, profile selectors, tracing flags, and redaction policy. A conflicting workspace is refused before its settings can affect cached or concurrent runs; start a separate server for that workspace. Restart the server to change its tracing configuration.

## Idle context compaction

Idle compaction is disabled by default. When enabled, the interactive client
automatically uses the existing `/offload` operation for contexts at or above
the configured token threshold during the final 20% of a known prompt-cache
retention window, capped at 120 seconds (60 seconds for a 5-minute window). This keeps the same thread and archives older
messages; it does not create a handoff thread. The configured offload model is
used, so summarization can incur costs and cache reuse is not guaranteed.

Opt in with a token threshold through the normal layered config:

```toml
[history]
idle_compaction_tokens = 100000
```

Alternatively, set `DEEPAGENTS_CODE_IDLE_COMPACTION_TOKENS=100000` before
launching dcode.

Set `idle_compaction_tokens = 0` to disable it again. File edits take effect after
`/reload`. This setting is independent of cold-cache warning preferences.
Compaction skips busy sessions, queued input, active typing, modals, lifecycle
transitions, and approximate token counts. It attempts at most once per thread
and cache window, announces the operation, and supports Escape cancellation.
Input arriving before the worker starts skips compaction; input arriving after
it starts uses the normal offload queue and runs once compaction finishes.

## Debugging

Deep Agents Code runs as two processes: the **Textual TUI** you interact with, and a **`langgraph dev` subprocess** that hosts the agent graph. Each writes its own log, and a single switch turns both on:

```bash
cd libs/code
export DEEPAGENTS_CODE_DEBUG=1
uv run deepagents-code
```

| Variable | Effect |
| --- | --- |
| `DEEPAGENTS_CODE_DEBUG` | Master switch. Preserves the server subprocess log on exit (printing its path to stderr) and attaches the client `DEBUG` file handler. Truthy: `1`/`true`/`yes`/`on` (case-insensitive). Falsy: `0`/`false`/`no`/`off`/empty/unset. |
| `DEEPAGENTS_CODE_DEBUG_DIRECTORY=<path>` | Overrides the client log directory (default `/tmp/deepagents_debug`). Each thread writes to `<thread-id>.log`. **Only takes effect when `DEEPAGENTS_CODE_DEBUG` is truthy**; does **not** affect the server subprocess log. |
| `DEEPAGENTS_CODE_DEBUG_FILE=<path>` | Deprecated compatibility override. When `DEEPAGENTS_CODE_DEBUG_DIRECTORY` and `[debug].directory` are unset, per-thread logs use this path's parent directory. Existing `[debug].file` config works the same way. |

Then pick the log you need by symptom:

| Symptom | Log you want | Default location |
| --- | --- | --- |
| App crashes on launch (one-line failure banner) | **Server subprocess log** — the real traceback | `$TMPDIR/deepagents_server_log_*.txt` |
| App starts, then misbehaves (UI, model calls, slash commands) | **Client app log** — `deepagents_code` at `DEBUG` | `/tmp/deepagents_debug/<thread-id>.log` |

### Startup crash -> server subprocess log

The TUI only surfaces a one-line banner; the actual exception lives in the subprocess's combined stdout/stderr. To get it:

1. **Re-run with debugging on** (see above). After the app exits and the terminal is restored, the log is preserved and its path is printed to stderr as `Server log preserved at: ...`.
2. **Open the newest log.** On macOS, `tempfile` resolves to `$TMPDIR` (a path under `/var/folders/.../T/`):

   ```bash
   # Newest first
   ls -lt ${TMPDIR:-/tmp}/deepagents_server_log_*.txt | head -5

   # Or tail the latest live while you reproduce the crash
   tail -F "$(ls -t ${TMPDIR:-/tmp}/deepagents_server_log_*.txt | head -1)"
   ```

3. **Search for `Failed to initialize server graph`.** The traceback beneath it names the concrete failure — MCP config validation, sandbox init, model resolution, subagent load, and so on. Everything above that line is uvicorn/lifespan unwinding and can be ignored.

### Client-side issue -> app log

For problems that appear after the app is up, tail the client log in another terminal while reproducing:

```bash
tail -f /tmp/deepagents_debug/<thread-id>.log
```

To send logs elsewhere, also `export DEEPAGENTS_CODE_DEBUG_DIRECTORY=<path>`. Each thread gets its own append-only file, and changing threads in the app switches the active log file.

The directory is created or tightened to owner-only access, and each file is created or tightened to user-only access. Symlinks are refused. If either cannot be secured, no file handler is attached and a warning goes to stderr. Use the in-app Debug Console in that case.

Raw stdio MCP server stderr is discarded to protect the TUI and prevent unbounded disk growth, including in debug mode. Structured MCP log notifications still reach the application logger with the server name and severity.

### In-app Debug Console (`Ctrl+\`)

Press `Ctrl+\` (or run the hidden `/debug` command) inside a session to toggle a read-only Debug Console overlay. It shows a point-in-time session/runtime snapshot (version, model, thread, cwd, auto-approve, sandbox, MCP servers, token usage, debug-log path) plus a live tail of recent `deepagents_code.*` log records.

The tail is fed by an always-on in-memory ring buffer (`_debug_buffer.install_log_buffer`, installed on the package logger in `__init__.py`), so it works **without** `DEEPAGENTS_CODE_DEBUG` — though enabling that switch raises the captured level to `DEBUG` and adds the file handler above. In the console, `Ctrl+X` clears the on-screen view (the buffer keeps accruing) and `c` copies the visible lines. `Ctrl+L` remains an alias for clearing the view.

In `/btw`, `Esc` hides the modal and cancels any unfinished answer. Completed side exchanges remain available when you reopen `/btw` or switch away from the main thread and return. Each main thread has its own side history, kept only while the app runs and separate from the main conversation. `Ctrl+X` cancels the side answer and clears that thread's side transcript, follow-up context, and draft while keeping the modal open.

## Local dev installs

A *local dev install* gives you a persistent `dcode-dev` command that launches your checkout directly. It lives in a dedicated editable venv under `~/.local/share/dcode-dev`, symlinked into `~/.local/bin/dcode-dev`. It can sit alongside a released `dcode` without interfering:

- `dcode` / `deepagents-code` — the released tool, installed via `curl -LsSf https://langch.in/dcode | bash` (the install script).
- `dcode-dev` — your local checkout.

That lets you compare released behavior against local, and fall back to a known-good build if your checkout breaks. Either way, the dedicated venv keeps the dev binary's dependency experiments out of the repo's locked `uv sync` environment.

### Setup

`~/.local/bin` must be on your `PATH` for the symlink to resolve (`uv tool install` adds its own shim directory automatically, but a hand-rolled symlink does not). Replace `<repo>` with your local checkout path:

```bash
# 1. Create an isolated venv for the dev binary
uv venv ~/.local/share/dcode-dev --python 3.14

# 2. Install your checkout into it, editable
uv pip install --python ~/.local/share/dcode-dev/bin/python -e <repo>/libs/code

# 3. Expose it as `dcode-dev` on your PATH
ln -sf ~/.local/share/dcode-dev/bin/dcode ~/.local/bin/dcode-dev
```

The `--python 3.14` is illustrative — any interpreter satisfying the package's `requires-python` (currently `>=3.14,<3.15`) works; omit the flag to let `uv` pick.

> **Why `uv venv` + `uv pip install -e` rather than `uv sync` or `uv tool install --editable`?** This builds an isolated venv *outside* the workspace's locked environment, so the dev binary can be re-resolved on demand without disturbing the released tool or the repo's `uv.lock`. (`uv pip` and `uv venv` are first-class `uv` subcommands here, not bare `pip`.)

### Updating

When dependency constraints change in `libs/code/pyproject.toml`, refresh the dev venv:

```bash
uv pip install --python ~/.local/share/dcode-dev/bin/python -e <repo>/libs/code --upgrade
```

### Verifying

Confirm command resolution and editable imports (the `dcode` checks assume the released tool is installed separately, per above):

```bash
which dcode
which dcode-dev
dcode --version
dcode-dev --version
~/.local/share/dcode-dev/bin/python -c 'import deepagents_code; print(deepagents_code.__file__)'
```

## Live CSS development with Textual devtools

After completing the [Quickstart](#quickstart), use Textual's devtools console for CSS hot-reload and live `self.log()` output during development.

Create the dev wrapper script once:

```bash
cat > /tmp/dev_deepagents.py << 'PYEOF'
"""Dev wrapper to run Deep Agents Code with textual devtools."""
import sys
sys.argv = ["deepagents"] + sys.argv[1:]

from deepagents_code.main import cli_main
cli_main()
PYEOF
```

Run both commands from `libs/code`:

**Terminal 1** — devtools console:

```bash
uv run --group test textual console
```

**Terminal 2** — TUI with live reload:

```bash
uv run --group test textual run --dev /tmp/dev_deepagents.py
```

Edit any `.tcss` file and save — changes appear immediately. Any `self.log()` calls in widget code show in the console.

### Console options

- `textual console -v` — verbose mode, shows all events (key presses, mouse, etc.)
- `textual console -x EVENT` — exclude noisy event groups
- `textual console --port 7342` — custom port (pass matching `--port` to `textual run`)

### Why the wrapper script?

`textual run --dev` handles the devtools connection, but it needs to run inside the project's virtualenv to import `deepagents_code`. The wrapper script bridges the gap — `uv run --group test textual run --dev` ensures both `textual-dev` (from the `test` group) and `deepagents_code` are available in the same environment.
