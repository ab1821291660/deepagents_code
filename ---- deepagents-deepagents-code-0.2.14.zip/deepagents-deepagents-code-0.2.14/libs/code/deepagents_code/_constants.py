"""Lightweight shared constants for the app.

This module is intentionally dependency-free (no third-party imports, no
sibling-module imports) so any other module — including the startup-critical
`main.py` and the heavy `agent.py` — can import from it without triggering a
chain of expensive imports.
"""

from __future__ import annotations

from typing import Final

DEFAULT_AGENT_NAME: Final[str] = "agent"
"""Default agent / assistant identifier when no `-a` flag is given."""

DEFAULT_THREAD_LIMIT: Final[int] = 100
"""Fallback for `get_thread_limit()`, the thread switcher batch size."""

FS_TOOL_NAMES: Final[frozenset[str]] = frozenset(
    {"ls", "read_file", "write_file", "edit_file", "delete", "glob", "grep", "execute"}
)
"""Mirror of the SDK's `FsToolName` literal members.

Hardcoded here rather than derived from `deepagents.FsToolName` because
`deepagents` must not be imported on the arg-parsing hot path (see AGENTS.md
"Startup performance"); this module is dependency-free and safe for `main.py` to
import. Consumers (`main._parse_allow_fs_tools_flag`,
`tool_catalog.collect_built_in_tools`) alias this set, and `get_args(FsToolName)`
drift guards in `test_main_args` and `test_tool_catalog` pin it so a new or
renamed SDK filesystem tool fails a test instead of silently diverging.
"""

SESSION_END_DRAIN_TIMEOUT_SECONDS: Final[float] = 2.0
"""Maximum time to drain Hooks v2 `SessionEnd` during session teardown."""

SDK_DEFAULT_RUBRIC_MAX_ITERATIONS: Final[int] = 3
"""Default `RubricMiddleware.max_iterations`, shown without importing the SDK.

Hardcoded rather than read from `deepagents.middleware.rubric.RubricMiddleware`
because this module is dependency-free and importing the SDK for a display
string would violate the startup-performance rule (see AGENTS.md). This is a
hand-maintained duplicate that can rot if the SDK bumps its default, so
`test_reliable_rubric.py::TestRubricMiddlewareIntegration::test_displayed_max_iterations_default_matches_sdk`
is the drift guard that fails when the two diverge.
"""

FIREWORKS_PROVIDER_ID_PREFIX: Final[str] = "accounts/fireworks/"
"""Prefix used to infer Fireworks from fully-qualified IDs."""

LANGSMITH_API_KEY_ENV: Final[str] = "LANGSMITH_API_KEY"
"""Primary env var the LangSmith SDK reads for its API key."""

LANGSMITH_API_KEY_FALLBACK_ENV_VARS: Final[tuple[str, ...]] = ("LANGCHAIN_API_KEY",)
"""Legacy env vars the LangSmith SDK accepts after `LANGSMITH_API_KEY_ENV`."""

LANGSMITH_API_KEY_ENV_VARS: Final[tuple[str, ...]] = (
    LANGSMITH_API_KEY_ENV,
    *LANGSMITH_API_KEY_FALLBACK_ENV_VARS,
)
"""Env vars LangSmith reads for its API key, in precedence order.

Mirrors the SDK's own `LANGSMITH_`-then-`LANGCHAIN_` lookup.
"""

FIREWORKS_MODEL_ID_PREFIXES: Final[tuple[str, ...]] = (
    "accounts/fireworks/models/",
    "accounts/fireworks/routers/",
)
"""Model and router ID prefixes used for stripping and classification."""

MCP_REENABLED_PENDING_ERROR: Final[str] = "Re-enabled — press Ctrl+R to load."
"""User-facing reconnect guidance shown for an MCP server that was optimistically
re-enabled but whose agent has not yet reconnected.

Set as `MCPServerInfo.error` by `app._apply_optimistic_disabled_state` (alongside
`pending_reconnect=True`, which is what `/tools` actually keys off). Named here
so the producer and the tests asserting the message share one literal.
"""

FILE_NOT_FOUND: Final[str] = "file_not_found"
"""Mirror of the SDK's `deepagents.backends.protocol.FILE_NOT_FOUND` sentinel.

Hardcoded here rather than imported because `file_ops` is on the TUI import
path and importing `deepagents` at module scope violates the
startup-performance rule (see AGENTS.md); this module is dependency-free.
`test_file_ops.py::test_file_not_found_matches_sdk` is the drift guard that
fails if the SDK renames the sentinel.
"""

SYSTEM_MESSAGE_PREFIX: Final[str] = "[SYSTEM]"
"""Prefix for synthetic human messages (e.g. interrupt cancellation notices).

Such messages are written to the `messages` channel for the agent's benefit on
resume but are not user-authored, so they are filtered out of both the rendered
transcript and a thread's initial prompt. Shared here so the single producer
(`textual_adapter`) and its consumers (`app`, `sessions`) agree on one literal.
"""

LOCAL_CONTEXT_MESSAGE_SOURCE: Final[str] = "local_context"
"""Source for model-only local-context refresh messages."""

TASK_INTERRUPTED_MESSAGE_SOURCE: Final[str] = "task_interrupted"
"""Source for the cancellation notice saved when the user interrupts a turn.

Lets readers outside the CLI tell it apart from user input without matching
`SYSTEM_MESSAGE_PREFIX` text.
"""

DEFAULT_PLUGIN_DIRNAME: Final[str] = "plugins"
"""Directory name for plugin storage under the profile root.

Not an agent profile. The `/agent` picker reserves this name in addition to
requiring an `AGENTS.md` marker, so it is never listed as a selectable agent.

Defined here rather than in `plugins.store` because `_reserved_names` reads it
on the CLI startup path, and importing `plugins.store` pulls in the `plugins`
package `__init__`, which loads pydantic through `plugins.models` (see AGENTS.md
"Startup performance"). `plugins.store` re-exports it for its own callers.
"""
