"""Plugin manager view models."""

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from deepagents_code.plugins.models import UnsupportedComponent

PluginTab = Literal["discover", "installed", "marketplaces", "errors", "settings"]
PluginManagerView = Literal[
    "list",
    "add_marketplace",
    "plugin_details",
    "installed_details",
    "marketplace_details",
    "confirm_remove_marketplace",
]
PluginManagerAction = Literal["reload", "later", "check_failed"]
"""Action the manager asks the app to take once it closes."""

PluginManagerResult = PluginManagerAction | None
"""Value the plugin manager dismisses with.

`None` means no action is needed: the close check found no pending changes, or
no checker was wired. Textual also produces `None` for a bare `dismiss()`, so
handling of `None` has to stay a safe no-op.
"""

PluginClosePhase = Literal["browsing", "checking", "reload_prompt"]
"""Where the manager is in its close sequence.

`checking` runs the close check with the manager still painted; `reload_prompt`
shows the inline reload confirmation in place of the browsing chrome.
"""
PluginLoadState = Literal[
    "disabled", "pending_reload", "enabled", "error", "needs_repair"
]


@dataclass(frozen=True, slots=True, kw_only=True)
class _PluginRow:
    plugin_id: str
    description: str
    enabled: bool
    version: str | None
    author: str | None
    display_name: str = ""
    skill_count: int | None = None
    skill_names: tuple[str, ...] = ()
    mcp_connected: bool | None = None
    mcp_server_names: tuple[str, ...] = ()
    mcp_login_servers: tuple[str, ...] = ()
    hook_events: tuple[str, ...] = ()
    unsupported_components: tuple[UnsupportedComponent, ...] = ()
    session_loaded: bool = False
    load_error: str | None = None
    needs_repair: bool = False
    """Whether the plugin is registered but its installed files are missing."""
    available_version: str | None = None

    @property
    def load_state(self) -> PluginLoadState:
        """Session-aware plugin status for list and detail copy."""
        if self.needs_repair:
            return "needs_repair"
        if self.load_error:
            return "error"
        if self.enabled != self.session_loaded:
            return "pending_reload"
        if self.enabled:
            return "enabled"
        return "disabled"

    @property
    def has_supported_components(self) -> bool:
        """Whether the plugin declares any component this client loads."""
        return bool(self.skill_names or self.mcp_server_names or self.hook_events)

    @property
    def label(self) -> str:
        """Human-readable plugin name for UI copy."""
        if self.display_name:
            return self.display_name
        return self.plugin_id.partition("@")[0]


@dataclass(frozen=True, slots=True)
class _MarketplaceRow:
    name: str
    source: str
    plugin_count: int | None
    installed_count: int
    error: str | None = None

    @property
    def has_error(self) -> bool:
        """Whether the configured marketplace could not be loaded.

        Marketplace loading failures set `error` and produce an error status. Warnings
        from a marketplace that loaded successfully appear on the Errors tab without
        marking the marketplace itself as errored.
        """
        return self.error is not None


@dataclass(frozen=True, slots=True)
class _ManagerState:
    available_plugins: tuple[_PluginRow, ...]
    installed_plugins: tuple[_PluginRow, ...]
    marketplaces: tuple[_MarketplaceRow, ...]
    errors: tuple[str, ...]
