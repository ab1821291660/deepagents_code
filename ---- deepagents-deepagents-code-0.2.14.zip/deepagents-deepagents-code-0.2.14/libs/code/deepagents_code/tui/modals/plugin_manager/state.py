"""Plugin manager state loading."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence, Set as AbstractSet

    from deepagents_code.mcp_tools import MCPServerInfo
    from deepagents_code.plugins.models import (
        MarketplacePluginEntry,
        PluginInstance,
        PluginMarketplace,
    )

from deepagents_code.plugins import discover_plugins
from deepagents_code.plugins.discovery import load_record_marketplace
from deepagents_code.plugins.marketplace import (
    MarketplaceError,
    materialize_plugin_source,
    redact_marketplace_source,
    redact_urls_in_text,
    unresolved_source_message,
)
from deepagents_code.plugins.models import LocalPluginSource, split_plugin_id
from deepagents_code.plugins.store import (
    get_primary_install_entry,
    load_available_plugin_updates,
    load_enabled_plugin_ids,
    load_installed_plugins,
    load_marketplace_records,
    plugin_mutation_lock,
)
from deepagents_code.tui.modals.plugin_manager.models import (
    _ManagerState,
    _MarketplaceRow,
    _PluginRow,
)

logger = logging.getLogger(__name__)


def _extract_name(value: object) -> str | None:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        name = value.get("name")
        if isinstance(name, str):
            return name
    return None


def _list_plugin_skill_names(instance: PluginInstance) -> tuple[str, ...]:
    from deepagents.backends.filesystem import FilesystemBackend

    from deepagents_code.plugins.adapters.skills import plugin_skill_sources
    from deepagents_code.plugins.adapters.skills_middleware import (
        load_namespaced_skills,
    )

    names: list[str] = []
    for path, _label, namespace in plugin_skill_sources((instance,)):
        try:
            source = Path(path).resolve()
            backend = FilesystemBackend(root_dir=str(source), virtual_mode=False)
            names.extend(
                skill["name"]
                for skill in load_namespaced_skills(backend, str(source), namespace)
            )
        except OSError, RuntimeError:
            logger.warning(
                "Could not list skills for plugin %s", instance.plugin_id, exc_info=True
            )
    return tuple(dict.fromkeys(names))


def _plugin_mcp_server_names(instance: PluginInstance) -> tuple[str, ...]:
    from deepagents_code.plugins.adapters.mcp import plugin_mcp_server_entries

    return tuple(
        label for label, _scoped, _needs_login in plugin_mcp_server_entries(instance)
    )


def _plugin_mcp_login_servers(instance: PluginInstance) -> tuple[str, ...]:
    from deepagents_code.plugins.adapters.mcp import plugin_mcp_server_entries

    return tuple(
        scoped
        for _label, scoped, needs_login in plugin_mcp_server_entries(instance)
        if needs_login
    )


def _plugin_mcp_connected(
    instance: PluginInstance, mcp_server_info: Sequence[MCPServerInfo]
) -> bool | None:
    from deepagents_code.plugins.adapters.mcp import plugin_mcp_server_entries

    expected = frozenset(
        scoped for _label, scoped, _needs_login in plugin_mcp_server_entries(instance)
    )
    if not expected:
        return None
    connected = {info.name for info in mcp_server_info if info.status == "ok"}
    return expected <= connected


def _plugin_display_name(
    *,
    marketplace_display_name: str | None,
    instance: PluginInstance | None,
    plugin_name: str,
) -> str:
    if marketplace_display_name:
        return marketplace_display_name
    if instance is not None and instance.manifest is not None:
        manifest_name = instance.manifest.display_name
        if manifest_name:
            return manifest_name
    return plugin_name


def _repair_error(plugin_id: str) -> str:
    return f"{plugin_id}: installed files are missing; reinstall or disable it."


def _instance_for_manager_row(
    plugin_id: str,
    *,
    discovered: dict[str, PluginInstance],
    is_installed: bool,
    errors: list[str],
    broken: set[str],
) -> PluginInstance | None:
    instance = discovered.get(plugin_id)
    if instance is not None:
        return instance
    if not is_installed:
        return None
    entry = get_primary_install_entry(plugin_id)
    if entry is None:
        errors.append(f"{plugin_id}: no install entry found; re-run install")
        return None
    root = Path(entry.install_path)
    try:
        installed = root.is_dir()
    except (OSError, RuntimeError) as exc:
        errors.append(f"{plugin_id}: could not inspect install path: {exc}")
        return None
    if not installed:
        logger.debug("Plugin %s install path %s is not a directory", plugin_id, root)
        errors.append(_repair_error(plugin_id))
        broken.add(plugin_id)
        return None
    from deepagents_code.plugins.discovery import _plugin_from_install_path

    # plugin_id is built as `{name}@{marketplace}`, so split_plugin_id cannot fail.
    plugin_name, marketplace_name = split_plugin_id(plugin_id)
    try:
        loaded, warnings = _plugin_from_install_path(
            plugin_id=plugin_id,
            root=root,
            marketplace_name=marketplace_name,
            fallback_name=plugin_name,
        )
    except (OSError, RuntimeError) as exc:
        errors.append(f"{plugin_id}: {exc}")
        return None
    errors.extend(warnings)
    return loaded


def _preview_local_plugin_instance(
    marketplace: PluginMarketplace,
    plugin: MarketplacePluginEntry,
    *,
    plugin_id: str,
    errors: list[str],
) -> PluginInstance | None:
    """Build a preview instance from a local marketplace source (no network).

    Returns:
        A plugin instance when the local source resolves, otherwise `None`.
    """
    if not isinstance(plugin.source, LocalPluginSource):
        return None
    root = materialize_plugin_source(marketplace, plugin)
    if root is None:
        return None
    try:
        exists = root.is_dir()
    except (OSError, RuntimeError) as exc:
        errors.append(f"{plugin_id}: could not inspect source path: {exc}")
        return None
    if not exists:
        return None
    from deepagents_code.plugins.discovery import _plugin_from_install_path

    # plugin_id is built as `{name}@{marketplace}`, so split_plugin_id cannot fail.
    plugin_name, marketplace_name = split_plugin_id(plugin_id)
    try:
        loaded, warnings = _plugin_from_install_path(
            plugin_id=plugin_id,
            root=root,
            marketplace_name=marketplace_name,
            fallback_name=plugin_name,
        )
    except (OSError, RuntimeError) as exc:
        errors.append(f"{plugin_id}: {exc}")
        return None
    # Preview is best-effort: inventory warnings are intentionally not surfaced
    # for un-installed plugins (they reach Errors once the plugin is installed).
    _ = warnings
    return loaded


@plugin_mutation_lock()
def _inspect_plugin(row: _PluginRow) -> _PluginRow:
    """Download and inventory one plugin without installing or executing it.

    Returns:
        A row with the inspected component names.

    Raises:
        MarketplaceError: If the source or its inventory cannot be inspected.
    """
    from deepagents_code.plugins.discovery import (
        _plugin_from_install_path,
        _resolve_marketplace_and_entry,
    )

    marketplace, entry = _resolve_marketplace_and_entry(row.plugin_id)
    rejections: list[str] = []
    root = materialize_plugin_source(marketplace, entry, rejections=rejections)
    if root is None:
        raise MarketplaceError(
            unresolved_source_message(row.plugin_id, entry, rejections)
        )
    instance, warnings = _plugin_from_install_path(
        plugin_id=row.plugin_id,
        root=root,
        marketplace_name=marketplace.name,
        fallback_name=entry.name,
    )
    if instance is None or warnings:
        msg = "; ".join(warnings) or "Could not inspect plugin contents."
        raise MarketplaceError(msg)
    for path in (*instance.inventory.mcp_files, *instance.inventory.hook_files):
        if path.suffix in {".mcpb", ".dxt"}:
            msg = f"Cannot inspect unsupported MCP bundle: {path.name}"
            raise MarketplaceError(msg)
        document = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(document, dict):
            msg = f"Cannot inspect {path.name}: expected a JSON object."
            raise MarketplaceError(msg)
    return _row_from_instance(
        plugin_id=row.plugin_id,
        description=row.description,
        author=row.author,
        is_enabled=row.enabled,
        instance=instance,
        mcp_server_info=(),
        mcp_connecting=False,
        loaded_plugin_ids=frozenset(),
        display_name=row.display_name,
    )


def _row_from_instance(
    *,
    plugin_id: str,
    description: str,
    author: str | None,
    is_enabled: bool,
    instance: PluginInstance | None,
    mcp_server_info: Sequence[MCPServerInfo],
    mcp_connecting: bool,
    loaded_plugin_ids: AbstractSet[str],
    load_error: str | None = None,
    display_name: str = "",
    needs_repair: bool = False,
    available_version: str | None = None,
) -> _PluginRow:
    from deepagents_code.plugins.adapters.hooks import plugin_hook_event_names

    skill_names = _list_plugin_skill_names(instance) if instance else ()
    mcp_names = _plugin_mcp_server_names(instance) if instance else ()
    login_servers = _plugin_mcp_login_servers(instance) if instance else ()
    hook_events = plugin_hook_event_names(instance) if instance else ()
    unsupported = instance.inventory.unsupported if instance else ()
    session_loaded = plugin_id in loaded_plugin_ids
    return _PluginRow(
        plugin_id=plugin_id,
        description=description,
        enabled=is_enabled,
        version=instance.version if instance else None,
        author=author,
        display_name=display_name,
        skill_count=len(skill_names) if instance else None,
        skill_names=skill_names,
        # Tri-state: `None` means "unknown, render nothing". While the
        # session is still connecting, `mcp_server_info` is not yet
        # trustworthy, so report unknown rather than a false "not connected"
        # that would show a bogus "run /reload to connect" hint.
        mcp_connected=_plugin_mcp_connected(instance, mcp_server_info)
        if instance and session_loaded and not mcp_connecting
        else None,
        mcp_server_names=mcp_names,
        mcp_login_servers=login_servers,
        hook_events=hook_events,
        unsupported_components=unsupported,
        session_loaded=session_loaded,
        load_error=load_error,
        needs_repair=needs_repair,
        available_version=(
            available_version
            if instance and available_version != instance.version
            else None
        ),
    )


def _load_manager_state(
    mcp_server_info: Sequence[MCPServerInfo] = (),
    *,
    mcp_connecting: bool = False,
    loaded_plugin_ids: AbstractSet[str] = frozenset(),
) -> _ManagerState:
    records = load_marketplace_records()
    enabled = load_enabled_plugin_ids()
    installed = load_installed_plugins()
    available_updates = load_available_plugin_updates()
    errors: list[str] = []
    plugin_result = discover_plugins()
    errors.extend(plugin_result.warnings)
    errors.extend(_repair_error(item.plugin_id) for item in plugin_result.broken)
    broken: set[str] = set()
    discovered = {instance.plugin_id: instance for instance in plugin_result.plugins}
    available_plugins: list[_PluginRow] = []
    installed_plugins: list[_PluginRow] = []
    marketplaces: list[_MarketplaceRow] = []
    for name, record in sorted(records.items()):
        try:
            marketplace = load_record_marketplace(record)
        except MarketplaceError as exc:
            detail = redact_urls_in_text(str(exc))
            if record.source_type not in {"directory", "file"}:
                detail = detail.replace(record.install_location, "<managed cache>")
            errors.append(f"{name}: {detail}")
            marketplaces.append(
                _MarketplaceRow(
                    name,
                    redact_marketplace_source(record.source),
                    None,
                    sum(plugin_id.endswith(f"@{name}") for plugin_id in installed),
                    detail,
                )
            )
            continue
        marketplaces.append(
            _MarketplaceRow(
                marketplace.name,
                redact_marketplace_source(record.source),
                len(marketplace.plugins),
                sum(
                    plugin_id.endswith(f"@{marketplace.name}")
                    for plugin_id in installed
                ),
            )
        )
        errors.extend(
            f"{marketplace.name}: {warning}" for warning in marketplace.warnings
        )
        for plugin in marketplace.plugins:
            plugin_id = f"{plugin.name}@{marketplace.name}"
            is_enabled = plugin_id in enabled
            is_installed = plugin_id in installed
            row_errors: list[str] = []
            instance = _instance_for_manager_row(
                plugin_id,
                discovered=discovered,
                is_installed=is_installed,
                errors=row_errors,
                broken=broken,
            )
            if instance is None and not is_installed:
                instance = _preview_local_plugin_instance(
                    marketplace,
                    plugin,
                    plugin_id=plugin_id,
                    errors=row_errors,
                )
            errors.extend(row_errors)
            load_error: str | None = None
            needs_repair = plugin_id in broken
            if is_installed and instance is None and not needs_repair:
                load_error = (
                    row_errors[0]
                    if row_errors
                    else "installed plugin could not be loaded"
                )
            row = _row_from_instance(
                plugin_id=plugin_id,
                description=plugin.description or "",
                author=_extract_name(plugin.author),
                is_enabled=is_enabled,
                instance=instance,
                mcp_server_info=mcp_server_info,
                mcp_connecting=mcp_connecting,
                loaded_plugin_ids=loaded_plugin_ids,
                load_error=load_error,
                needs_repair=needs_repair,
                display_name=_plugin_display_name(
                    marketplace_display_name=plugin.display_name,
                    instance=instance,
                    plugin_name=plugin.name,
                ),
                available_version=available_updates.get(plugin_id),
            )
            (installed_plugins if is_installed else available_plugins).append(row)
    return _ManagerState(
        tuple(available_plugins),
        tuple(installed_plugins),
        tuple(marketplaces),
        tuple(dict.fromkeys(errors)),
    )
