"""Sandbox lifecycle management with provider abstraction."""

from __future__ import annotations

import contextlib
import importlib
import importlib.util
import logging
import os
import shlex
import string
import time
from contextlib import asynccontextmanager, contextmanager
from datetime import timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Literal, Protocol

from rich.markup import escape as escape_markup

from deepagents_code.config import (
    AWS_CREDENTIAL_ENV_SOURCES,
    AWS_REGION_ENV_SOURCES,
    active_environment,
    console,
    get_glyphs,
    resolve_env_kwargs,
)
from deepagents_code.integrations.sandbox_provider import (
    SandboxNotFoundError,
    SandboxProvider,
)

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, Generator, Mapping
    from types import ModuleType

    from deepagents.backends.protocol import SandboxBackendProtocol

    from deepagents_code.integrations.sandbox_registry import SandboxRegistry


def _run_sandbox_setup(backend: SandboxBackendProtocol, setup_script_path: str) -> None:
    """Run users setup script in sandbox with env var expansion.

    Args:
        backend: Sandbox backend instance
        setup_script_path: Path to setup script file

    Raises:
        FileNotFoundError: If the setup script does not exist.
        RuntimeError: If the setup script fails to execute.
    """
    script_path = Path(setup_script_path)
    if not script_path.exists():
        msg = f"Setup script not found: {setup_script_path}"
        raise FileNotFoundError(msg)

    console.print(
        f"[dim]Running setup script: {escape_markup(setup_script_path)}...[/dim]"
    )

    # Read script content
    script_content = script_path.read_text(encoding="utf-8")

    # Expand ${VAR} syntax using the workspace environment. `create_sandbox`
    # runs inside `use_environment`, so this must read the bound snapshot:
    # `os.environ` here would expand the server process's values into the
    # sandbox and hide the workspace's own `.env`.
    template = string.Template(script_content)
    expanded_script = template.safe_substitute(active_environment())

    # Execute expanded script in sandbox
    result = backend.execute(f"bash -c {shlex.quote(expanded_script)}")

    if result.exit_code != 0:
        console.print(f"[red]Setup script failed (exit {result.exit_code}):[/red]")
        console.print(f"[dim]{escape_markup(result.output)}[/dim]")
        msg = "Setup failed - aborting"
        raise RuntimeError(msg)

    console.print(f"[green]{get_glyphs().checkmark} Setup complete[/green]")


@contextmanager
def create_sandbox(
    provider: str,
    *,
    sandbox_id: str | None = None,
    snapshot_name: str | None = None,
    setup_script_path: str | None = None,
    params: dict[str, Any] | None = None,
) -> Generator[SandboxBackendProtocol]:
    """Create or connect to a sandbox of the specified provider.

    This is the unified interface for sandbox creation using the
    provider abstraction.

    Args:
        provider: Sandbox provider name. Built-ins (`'agentcore'`, `'daytona'`,
            `'langsmith'`, `'modal'`, `'openshell'`, `'runloop'`, `'vercel'`),
            entry-point providers, and config-declared providers are all
            resolved through the registry.
        sandbox_id: Optional existing sandbox ID to reuse
        snapshot_name: Optional sandbox snapshot name to use or create.
            Honored by providers whose metadata sets `supports_snapshot_name`
            (built-ins: `'langsmith'` and `'daytona'` snapshot, `'runloop'`
            blueprint); must be `None` for other providers.
        setup_script_path: Optional path to setup script to run after sandbox starts
        params: Extra keyword arguments forwarded to `provider.get_or_create()`
            (e.g. config-declared `[sandboxes.providers.<name>.params]`).

    Yields:
        `SandboxBackendProtocol` instance

    Raises:
        ValueError: If `snapshot_name` is provided for an unsupported provider,
            or combined with `sandbox_id` (snapshots only apply to fresh sandboxes).
    """
    registry = _get_registry()
    metadata = registry.get_metadata(provider)
    if snapshot_name is not None and (
        metadata is None or not metadata.supports_snapshot_name
    ):
        msg = (
            f"snapshot_name is not supported by provider {provider!r} "
            f"(got snapshot_name={snapshot_name!r})"
        )
        raise ValueError(msg)
    if snapshot_name is not None and sandbox_id is not None:
        msg = (
            "snapshot_name cannot be combined with sandbox_id; "
            "snapshots only apply when creating a fresh sandbox"
        )
        raise ValueError(msg)

    # Get provider instance (reuse the registry already built above so we
    # don't re-read the config file and re-scan entry points).
    provider_obj = _get_provider(provider, registry=registry)

    # Determine if we should cleanup (only cleanup if we created it)
    should_cleanup = sandbox_id is None
    provider_kwargs: dict[str, Any] = dict(registry.get_params(provider))
    if params:
        provider_kwargs.update(params)
    if snapshot_name is not None:
        provider_kwargs["snapshot"] = snapshot_name

    # Create or connect to sandbox
    console.print(f"[yellow]Starting {provider} sandbox...[/yellow]")
    backend = provider_obj.get_or_create(sandbox_id=sandbox_id, **provider_kwargs)

    # Once acquired, an owned sandbox must also be cleaned up if setup fails.
    try:
        glyphs = get_glyphs()
        console.print(
            f"[green]{glyphs.checkmark} {provider.capitalize()} sandbox ready: "
            f"{backend.id}[/green]"
        )
        if setup_script_path:
            _run_sandbox_setup(backend, setup_script_path)

        yield backend
    finally:
        if should_cleanup:
            try:
                console.print(
                    f"[dim]Terminating {provider} sandbox {backend.id}...[/dim]"
                )
                provider_obj.delete(sandbox_id=backend.id)
                glyphs = get_glyphs()
                console.print(
                    f"[dim]{glyphs.checkmark} {provider.capitalize()} sandbox "
                    f"{backend.id} terminated[/dim]"
                )
            except Exception as e:  # noqa: BLE001  # Cleanup errors should not mask the original sandbox failure
                warning = get_glyphs().warning
                console.print(
                    f"[yellow]{warning} Cleanup failed for {provider} sandbox "
                    f"{backend.id}: {e}[/yellow]"
                )


def _get_registry() -> SandboxRegistry:
    """Build a `SandboxRegistry` from the current user config.

    Not cached: each call re-reads the config file and re-scans entry points so
    the registry reflects the latest state. Reuse a single instance within one
    operation (see `create_sandbox`) rather than calling this repeatedly.

    Returns:
        A fresh `SandboxRegistry`.
    """
    from deepagents_code.integrations.sandbox_registry import SandboxRegistry

    return SandboxRegistry.load()


def get_default_working_dir(provider: str) -> str:
    """Get the default working directory for a given sandbox provider.

    Args:
        provider: Sandbox provider name. Resolved through the registry so
            built-in, entry-point, and config providers are all supported.

    Returns:
        Default working directory path as string

    Raises:
        ValueError: If provider is unknown
    """
    metadata = _get_registry().get_metadata(provider)
    if metadata is None:
        msg = f"Unknown sandbox provider: {provider}"
        raise ValueError(msg)
    return metadata.working_dir


# ---------------------------------------------------------------------------
# Provider implementations
# ---------------------------------------------------------------------------


def _import_provider_module(
    module_name: str,
    *,
    provider: str,
    package: str,
) -> ModuleType:
    """Import an optional provider module with a provider-specific error message.

    Args:
        module_name: Python module name to import.
        provider: Sandbox provider name (e.g. `'daytona'`).
        package: PyPI package name exposed by the package extra.

    Returns:
        The imported module object.

    Raises:
        ImportError: If the optional dependency is not installed.
    """
    try:
        return importlib.import_module(module_name)
    except ImportError as exc:
        msg = (
            f"The '{provider}' sandbox provider requires the '{package}' package. "
            f"Install it with: /install {provider} (in-app) or "
            f"dcode install {provider} (CLI)"
        )
        raise ImportError(msg) from exc


_LANGSMITH_DEFAULT_SNAPSHOT = "deepagents-code"
"""Default LangSmith sandbox snapshot name used when none is specified."""

_LANGSMITH_DEFAULT_IMAGE = "python:3"
"""Default Docker image for LangSmith sandbox snapshots when none is provided."""

_LANGSMITH_DEFAULT_FS_CAPACITY_BYTES = 16 * 1024**3
"""Default filesystem capacity (16 GiB) for LangSmith sandbox snapshots."""

_DAYTONA_DEFAULT_IMAGE = "python:3"
"""Default Docker image for Daytona sandbox snapshots when none is provided."""

_DAYTONA_SNAPSHOT_READY_STATE = "active"
"""Daytona snapshot state that is bootable; others are in-flight or failed."""


class _LangSmithProvider(SandboxProvider):
    """LangSmith sandbox provider implementation.

    Manages LangSmith sandbox lifecycle using the LangSmith SDK, booting
    sandboxes from snapshots built from a Docker image.
    """

    def __init__(self, api_key: str | None = None) -> None:
        """Initialize LangSmith provider.

        Args:
            api_key: LangSmith API key (defaults to `LANGSMITH_SANDBOX_API_KEY`,
                then `LANGSMITH_API_KEY` env var).

        Raises:
            ValueError: If no LangSmith API key is found.
        """
        from langsmith.sandbox import SandboxClient

        from deepagents_code.model_config import resolve_env_var

        sandbox_key = resolve_env_var("LANGSMITH_SANDBOX_API_KEY")
        if sandbox_key:
            logger.debug("Using LangSmith API key from LANGSMITH_SANDBOX_API_KEY")
        self._api_key: str | None = (
            api_key
            or sandbox_key
            or resolve_env_var("LANGSMITH_API_KEY")
            or resolve_env_var("LANGCHAIN_API_KEY")
        )
        if not self._api_key:
            msg = (
                "No LangSmith sandbox API key found. Set "
                "LANGSMITH_API_KEY, LANGCHAIN_API_KEY, or LANGSMITH_SANDBOX_API_KEY "
                "(or the DEEPAGENTS_CODE_-prefixed equivalents)."
            )
            raise ValueError(msg)
        self._client: SandboxClient = SandboxClient(api_key=self._api_key)

    def get_or_create(
        self,
        *,
        sandbox_id: str | None = None,
        timeout: int = 180,
        snapshot: str | None = None,
        snapshot_image: str | None = None,
        fs_capacity_bytes: int | None = None,
        **kwargs: Any,
    ) -> SandboxBackendProtocol:
        """Get existing or create new LangSmith sandbox.

        Args:
            sandbox_id: Optional existing sandbox name to reuse.
            timeout: Timeout in seconds for sandbox startup.
            snapshot: Snapshot name to boot from.

                Resolved to a snapshot ID, creating the snapshot from
                `snapshot_image` if missing. Overrides
                `LANGSMITH_SANDBOX_SNAPSHOT_NAME`; overridden by
                `LANGSMITH_SANDBOX_SNAPSHOT_ID` (ID, wins over everything).
            snapshot_image: Docker image used when building the snapshot.
            fs_capacity_bytes: Filesystem capacity when building the snapshot.
            **kwargs: Additional LangSmith-specific parameters.

        Returns:
            `LangSmithSandbox` instance.

        Raises:
            RuntimeError: If sandbox connection or startup fails.
            TypeError: If unsupported keyword arguments are provided.
        """
        from deepagents.backends.langsmith import LangSmithSandbox

        from deepagents_code.model_config import resolve_env_var

        if kwargs:
            msg = f"Received unsupported arguments: {list(kwargs.keys())}"
            raise TypeError(msg)
        if sandbox_id:
            # Connect to existing sandbox by name
            try:
                sandbox = self._client.get_sandbox(name=sandbox_id)
            except Exception as e:
                msg = f"Failed to connect to existing sandbox '{sandbox_id}': {e}"
                raise RuntimeError(msg) from e
            return LangSmithSandbox(sandbox)

        # Explicit snapshot ID wins — skip name lookup and auto-build.
        env_snapshot_id = resolve_env_var("LANGSMITH_SANDBOX_SNAPSHOT_ID")
        if env_snapshot_id:
            snapshot_id = env_snapshot_id
            snapshot_name = env_snapshot_id
        else:
            env_snapshot_name = resolve_env_var("LANGSMITH_SANDBOX_SNAPSHOT_NAME")
            snapshot_name = snapshot or env_snapshot_name or _LANGSMITH_DEFAULT_SNAPSHOT
            image = snapshot_image or _LANGSMITH_DEFAULT_IMAGE
            capacity = fs_capacity_bytes or _LANGSMITH_DEFAULT_FS_CAPACITY_BYTES
            snapshot_id = self._ensure_snapshot(snapshot_name, image, capacity)

        try:
            sandbox = self._client.create_sandbox(
                snapshot_id=snapshot_id, timeout=timeout
            )
        except Exception as e:
            msg = f"Failed to create sandbox from snapshot '{snapshot_name}': {e}"
            raise RuntimeError(msg) from e

        # Verify sandbox is ready by polling
        for _ in range(timeout // 2):
            try:
                result = sandbox.run("echo ready", timeout=5)
                if result.exit_code == 0:
                    break
            except Exception:  # noqa: S110, BLE001  # Sandbox not ready yet, continue polling
                pass
            time.sleep(2)
        else:
            # Cleanup on failure
            with contextlib.suppress(Exception):
                self._client.delete_sandbox(sandbox.name)
            msg = f"LangSmith sandbox failed to start within {timeout} seconds"
            raise RuntimeError(msg)

        return LangSmithSandbox(sandbox)

    def delete(self, *, sandbox_id: str, **kwargs: Any) -> None:  # noqa: ARG002  # Required by SandboxFactory interface
        """Delete a LangSmith sandbox.

        Args:
            sandbox_id: Sandbox name to delete
            **kwargs: Additional parameters
        """
        self._client.delete_sandbox(sandbox_id)

    def _ensure_snapshot(
        self,
        snapshot_name: str,
        image: str,
        fs_capacity_bytes: int,
    ) -> str:
        """Resolve a snapshot by name, building it from `image` if missing.

        The LangSmith API exposes snapshots by ID, so we list and filter by
        name. Only snapshots with `status == "ready"` are returned; a
        matching-name snapshot in a non-ready state (`"building"`,
        `"failed"`, etc.) raises rather than triggering a duplicate build,
        which would mask the in-flight/failed snapshot.

        When no matching snapshot exists at all, we build one with
        `create_snapshot`, which blocks until the snapshot is ready.

        Returns:
            The snapshot ID ready to be passed to `create_sandbox`.

        Raises:
            RuntimeError: If listing or building the snapshot fails, or if
                a matching-name snapshot exists but is not ready.
        """
        try:
            snapshots = self._client.list_snapshots()
        except Exception as e:
            msg = f"Failed to list snapshots: {e}"
            raise RuntimeError(msg) from e

        non_ready_status: str | None = None
        for snap in snapshots:
            if snap.name != snapshot_name:
                continue
            if snap.status == "ready":
                return snap.id
            non_ready_status = snap.status

        if non_ready_status is not None:
            msg = (
                f"Snapshot '{snapshot_name}' exists but is in state "
                f"'{non_ready_status}'. Wait for it to finish building, or "
                f"delete it to rebuild."
            )
            raise RuntimeError(msg)

        try:
            snapshot = self._client.create_snapshot(
                name=snapshot_name,
                docker_image=image,
                fs_capacity_bytes=fs_capacity_bytes,
            )
        except Exception as create_err:
            msg = f"Failed to build snapshot '{snapshot_name}': {create_err}"
            raise RuntimeError(msg) from create_err
        return snapshot.id


class _DaytonaProvider(SandboxProvider):
    """Daytona sandbox provider — lifecycle management for Daytona sandboxes."""

    def __init__(self) -> None:
        daytona_module = _import_provider_module(
            "daytona",
            provider="daytona",
            package="langchain-daytona",
        )

        from deepagents_code.model_config import resolve_env_var

        api_key = resolve_env_var("DAYTONA_API_KEY")
        if not api_key:
            msg = (
                "No Daytona API key found. Set DAYTONA_API_KEY "
                "or DEEPAGENTS_CODE_DAYTONA_API_KEY."
            )
            raise ValueError(msg)
        self._daytona = daytona_module
        self._client = daytona_module.Daytona(
            daytona_module.DaytonaConfig(
                api_key=api_key,
                api_url=resolve_env_var("DAYTONA_API_URL"),
            )
        )

    def get_or_create(
        self,
        *,
        sandbox_id: str | None = None,
        timeout: int = 180,
        snapshot: str | None = None,
        snapshot_image: str | None = None,
        **kwargs: Any,
    ) -> SandboxBackendProtocol:
        """Get or create a Daytona sandbox.

        Args:
            sandbox_id: Not supported yet — must be None.
            timeout: Seconds to wait for startup.
            snapshot: Snapshot name to boot from.

                Resolved to a Daytona snapshot, creating it from
                `snapshot_image` if missing. Overrides
                `DAYTONA_SANDBOX_SNAPSHOT_NAME`; overridden by
                `DAYTONA_SANDBOX_SNAPSHOT_ID` (a pre-baked snapshot reference
                used as-is, which wins over everything). When none is set,
                uses Daytona's managed default sandbox.
            snapshot_image: Docker image used when building the snapshot.
            **kwargs: Rejected; passing any other keyword argument raises
                `TypeError`.

        Returns:
            `DaytonaSandbox` instance.

        Raises:
            NotImplementedError: If `sandbox_id` is provided.
            RuntimeError: If the sandbox fails to start.
            TypeError: If unsupported keyword arguments are provided.
        """
        from deepagents_code.model_config import resolve_env_var

        daytona_backend = _import_provider_module(
            "langchain_daytona",
            provider="daytona",
            package="langchain-daytona",
        )

        if kwargs:
            msg = f"Received unsupported arguments: {list(kwargs.keys())}"
            raise TypeError(msg)
        if sandbox_id:
            msg = (
                "Connecting to existing Daytona sandbox by ID not yet supported. "
                "Create a new sandbox by omitting sandbox_id parameter."
            )
            raise NotImplementedError(msg)

        # Explicit snapshot ID wins — skip name lookup and auto-build.
        env_snapshot_id = resolve_env_var("DAYTONA_SANDBOX_SNAPSHOT_ID")
        if env_snapshot_id:
            snapshot_ref = env_snapshot_id
        else:
            env_snapshot_name = resolve_env_var("DAYTONA_SANDBOX_SNAPSHOT_NAME")
            snapshot_name = snapshot or env_snapshot_name
            image = snapshot_image or _DAYTONA_DEFAULT_IMAGE
            snapshot_ref = (
                self._ensure_snapshot(snapshot_name, image) if snapshot_name else None
            )

        try:
            sandbox = (
                self._client.create(
                    self._daytona.CreateSandboxFromSnapshotParams(snapshot=snapshot_ref)
                )
                if snapshot_ref
                else self._client.create()
            )
        except Exception as e:
            msg = f"Failed to create sandbox from snapshot '{snapshot_ref}': {e}"
            raise RuntimeError(msg) from e

        last_exc: Exception | None = None
        for _ in range(timeout // 2):
            try:
                result = sandbox.process.exec("echo ready", timeout=5)
                if result.exit_code == 0:
                    break
            except Exception as exc:  # noqa: BLE001  # Transient failures expected during readiness polling
                last_exc = exc
            time.sleep(2)
        else:
            with contextlib.suppress(Exception):  # Best-effort cleanup
                sandbox.delete()
            detail = f" Last error: {last_exc}" if last_exc else ""
            msg = f"Daytona sandbox failed to start within {timeout} seconds.{detail}"
            raise RuntimeError(msg)

        return daytona_backend.DaytonaSandbox(sandbox=sandbox)

    def delete(self, *, sandbox_id: str, **kwargs: Any) -> None:  # noqa: ARG002
        """Delete a Daytona sandbox by id."""
        sandbox = self._client.get(sandbox_id)
        self._client.delete(sandbox)

    def _ensure_snapshot(self, snapshot_name: str, image: str) -> str:
        """Resolve a snapshot by name, building it from `image` if missing.

        Daytona references snapshots by name, so `snapshot.get` resolves the
        name directly. Only a snapshot in the `active` state is bootable; a
        matching-name snapshot that is still building or has failed raises
        rather than triggering a duplicate build, which would mask the
        in-flight/failed snapshot.

        When no matching snapshot exists, `snapshot.create` builds one and
        blocks until it reaches a terminal state.

        Args:
            snapshot_name: Name of the snapshot to resolve or build.
            image: Docker image used when building a missing snapshot.

        Returns:
            The snapshot name ready to pass to `create`.

        Raises:
            RuntimeError: If looking up or building the snapshot fails, or if a
                matching-name snapshot exists but is not ready.
        """
        try:
            existing = self._client.snapshot.get(snapshot_name)
        except self._daytona.DaytonaNotFoundError:
            existing = None
        except Exception as e:
            msg = f"Failed to look up snapshot '{snapshot_name}': {e}"
            raise RuntimeError(msg) from e

        if existing is not None:
            if existing.state == _DAYTONA_SNAPSHOT_READY_STATE:
                return existing.name
            if existing.state == "inactive":
                msg = (
                    f"Snapshot '{snapshot_name}' is inactive. Activate it with "
                    "Daytona's snapshot.activate API before retrying."
                )
                raise RuntimeError(msg)
            msg = (
                f"Snapshot '{snapshot_name}' exists but is in state "
                f"'{existing.state}'. Wait for it to finish building, or "
                f"delete it to rebuild."
            )
            raise RuntimeError(msg)

        try:
            built = self._client.snapshot.create(
                self._daytona.CreateSnapshotParams(name=snapshot_name, image=image)
            )
        except Exception as e:
            msg = f"Failed to build snapshot '{snapshot_name}': {e}"
            raise RuntimeError(msg) from e

        if built.state != _DAYTONA_SNAPSHOT_READY_STATE:
            msg = (
                f"Snapshot '{snapshot_name}' finished building in state "
                f"'{built.state}' rather than '{_DAYTONA_SNAPSHOT_READY_STATE}'."
            )
            raise RuntimeError(msg)
        return built.name


class _ModalProvider(SandboxProvider):
    """Modal sandbox provider — lifecycle management for Modal sandboxes."""

    def __init__(self) -> None:
        """Initialize the Modal provider.

        Raises:
            ValueError: If the resolved Modal credentials are invalid, or if
                only one half of the `MODAL_TOKEN_ID` / `MODAL_TOKEN_SECRET`
                pair resolves. Delegating to default Modal authentication
                there would be a silent privilege substitution.
        """
        self._modal = _import_provider_module(
            "modal",
            provider="modal",
            package="langchain-modal",
        )

        from deepagents_code.model_config import resolve_env_var

        token_id = resolve_env_var("MODAL_TOKEN_ID")
        token_secret = resolve_env_var("MODAL_TOKEN_SECRET")
        if token_id and token_secret:
            try:
                self._client = self._modal.Client.from_credentials(
                    token_id, token_secret
                )
            except Exception as exc:
                msg = (
                    "Failed to authenticate with Modal using "
                    "MODAL_TOKEN_ID / MODAL_TOKEN_SECRET "
                    "(or the DEEPAGENTS_CODE_-prefixed equivalents). "
                    "Verify your credentials are valid."
                )
                raise ValueError(msg) from exc
        elif token_id or token_secret:
            # Fail closed rather than warn and delegate: a `None` client makes
            # `App.lookup` resolve credentials from the server process, so a
            # workspace that pinned a restricted token would silently run its
            # sandbox under the server's broader Modal identity.
            missing = "MODAL_TOKEN_SECRET" if token_id else "MODAL_TOKEN_ID"
            msg = (
                "The workspace Modal configuration is incomplete: "
                f"{missing} is not set. Set MODAL_TOKEN_ID and "
                "MODAL_TOKEN_SECRET together, or unset both to fall back to "
                "default Modal authentication."
            )
            raise ValueError(msg)
        else:
            self._client = None

        lookup_kwargs: dict[str, Any] = {
            "name": "deepagents-sandbox",
            "create_if_missing": True,
        }
        if self._client is not None:
            lookup_kwargs["client"] = self._client
        self._app = self._modal.App.lookup(**lookup_kwargs)

    def get_or_create(
        self,
        *,
        sandbox_id: str | None = None,
        timeout: int = 180,
        **kwargs: Any,  # noqa: ARG002
    ) -> SandboxBackendProtocol:
        """Get or create a Modal sandbox.

        Args:
            sandbox_id: Existing sandbox ID, or None to create.
            timeout: Seconds to wait for startup.
            **kwargs: Unused.

        Returns:
            `ModalSandbox` instance.

        Raises:
            RuntimeError: If the sandbox fails to start.
        """
        modal_backend = _import_provider_module(
            "langchain_modal",
            provider="modal",
            package="langchain-modal",
        )

        client_kwargs: dict[str, Any] = {}
        if self._client is not None:
            client_kwargs["client"] = self._client

        if sandbox_id:
            sandbox = self._modal.Sandbox.from_id(
                sandbox_id=sandbox_id,
                app=self._app,
                **client_kwargs,
            )
        else:
            sandbox = self._modal.Sandbox.create(
                app=self._app, workdir="/workspace", **client_kwargs
            )
            last_exc: Exception | None = None
            for _ in range(timeout // 2):
                if sandbox.poll() is not None:
                    msg = "Modal sandbox terminated unexpectedly during startup"
                    raise RuntimeError(msg)
                try:
                    process = sandbox.exec("echo", "ready", timeout=5)
                    process.wait()
                    if process.returncode == 0:
                        break
                except Exception as exc:  # noqa: BLE001  # Transient failures expected during readiness polling
                    last_exc = exc
                time.sleep(2)
            else:
                sandbox.terminate()
                detail = f" Last error: {last_exc}" if last_exc else ""
                msg = f"Modal sandbox failed to start within {timeout} seconds.{detail}"
                raise RuntimeError(msg)

        return modal_backend.ModalSandbox(sandbox=sandbox)

    def delete(self, *, sandbox_id: str, **kwargs: Any) -> None:  # noqa: ARG002
        """Terminate a Modal sandbox by id."""
        del_kwargs: dict[str, Any] = {"sandbox_id": sandbox_id, "app": self._app}
        if self._client is not None:
            del_kwargs["client"] = self._client
        sandbox = self._modal.Sandbox.from_id(**del_kwargs)
        sandbox.terminate()


class _RunloopProvider(SandboxProvider):
    """Runloop sandbox provider — delegates to `langchain_runloop.RunloopProvider`."""

    def __init__(self) -> None:
        runloop_module = _import_provider_module(
            "langchain_runloop",
            provider="runloop",
            package="langchain-runloop",
        )

        from deepagents_code.model_config import resolve_env_var

        api_key = resolve_env_var("RUNLOOP_API_KEY")
        if not api_key:
            msg = (
                "No Runloop API key found. Set RUNLOOP_API_KEY "
                "or DEEPAGENTS_CODE_RUNLOOP_API_KEY."
            )
            raise ValueError(msg)
        self._provider = runloop_module.RunloopProvider(
            api_key=api_key,
            resolve_env_var=resolve_env_var,
        )

    def get_or_create(
        self,
        *,
        sandbox_id: str | None = None,
        timeout: int = 180,
        **kwargs: Any,
    ) -> SandboxBackendProtocol:
        """Get or create a Runloop devbox.

        Args:
            sandbox_id: Existing devbox ID, or None to create.
            timeout: Accepted for parity with other providers; currently
                forwarded but unused by the Runloop backend (the SDK manages
                its own startup wait).
            **kwargs: Runloop-specific options (`snapshot` blueprint name,
                `blueprint_dockerfile`).

        Returns:
            `RunloopSandbox` instance.

        Raises:
            SandboxNotFoundError: If `sandbox_id` does not exist. `RunloopProvider`
                translates the SDK's not-found error into a `KeyError`, which is
                mapped here.
            KeyError: If a `KeyError` is raised while no `sandbox_id` was supplied
                (re-raised unchanged rather than mislabeled as not-found).
        """
        try:
            return self._provider.get_or_create(
                sandbox_id=sandbox_id,
                timeout=timeout,
                **kwargs,
            )
        except KeyError as e:
            if sandbox_id is None:
                raise
            raise SandboxNotFoundError(sandbox_id) from e

    def delete(self, *, sandbox_id: str, **kwargs: Any) -> None:  # noqa: ARG002
        """Shut down a Runloop devbox by id."""
        self._provider.delete(sandbox_id=sandbox_id)


def _server_env_kwargs(table: Mapping[str, tuple[str, ...]]) -> dict[str, str]:
    """Resolve a credential table against the server's own environment.

    Workspace resolution reads `active_environment()`, which falls back to
    `os.environ`, so a plain `AWS_PROFILE` or `VERCEL_TOKEN` exported in the
    server's shell is indistinguishable from one a workspace pinned. Resolving
    the same table against `os.environ` explicitly gives the caller a baseline
    to compare against: an equal result means the workspace pinned nothing of
    its own, so there is no workspace identity to protect.

    Args:
        table: Constructor argument name mapped to candidate env var names.

    Returns:
        The arguments the server would resolve on its own.
    """
    from deepagents_code.config import _resolve_env_var_from

    return resolve_env_kwargs(
        table, lambda name: _resolve_env_var_from(os.environ, name)
    )


def _aws_session_kwargs() -> dict[str, str]:
    """Translate the bound workspace environment into boto3 session arguments.

    Resolves through `resolve_env_var` so a `DEEPAGENTS_CODE_`-prefixed
    override is honored here exactly as it is on the model path. Both paths
    share `AWS_CREDENTIAL_ENV_SOURCES`; sharing the table alone left the
    *lookup* free to drift, so a prefixed value applied to the model and was
    dropped for the sandbox.

    Validates the resolved set as a whole. A pair check alone let a session
    token with neither key half through, and botocore then declines the
    explicit credential provider and falls through to the server's own
    credentials -- so the workspace's token is silently ignored.

    Returns:
        Populated boto3 session keyword arguments.

    Raises:
        ValueError: If the resolved credentials are incomplete. Checked before
            boto3 is touched so the error names the variable at fault; boto3's
            own `PartialCredentialsError` names neither.
    """
    from deepagents_code.model_config import resolve_env_var

    resolved = resolve_env_kwargs(AWS_CREDENTIAL_ENV_SOURCES, resolve_env_var)
    key_id = resolved.get("aws_access_key_id")
    secret = resolved.get("aws_secret_access_key")
    if bool(key_id) != bool(secret):
        missing = "AWS_SECRET_ACCESS_KEY" if key_id else "AWS_ACCESS_KEY_ID"
        msg = (
            f"The workspace AWS configuration is incomplete: {missing} is not "
            f"set. Set both AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY in "
            f"this workspace's .env, or unset both to use AWS_PROFILE or the "
            f"server's default credentials."
        )
        raise ValueError(msg)
    if resolved.get("aws_session_token") and not key_id:
        msg = (
            "The workspace AWS configuration is incomplete: AWS_SESSION_TOKEN "
            "is set without AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY. Set "
            "all three together, or unset AWS_SESSION_TOKEN to use AWS_PROFILE "
            "or the server's default credentials."
        )
        raise ValueError(msg)
    # `AWS_PROFILE` alongside explicit keys is left alone deliberately. boto3's
    # precedence is documented and deterministic, and because
    # `active_environment()` layers the workspace over the server's own
    # environment, an exported profile plus workspace keys is an ordinary
    # combination rather than a mistake. Rejecting it would turn a working
    # setup into a startup failure.
    return resolved


class _AgentCoreProvider(SandboxProvider):
    """AgentCore Code Interpreter sandbox provider.

    Manages AgentCore session lifecycle. Sessions cannot be reconnected after
    the app exits — the `sandbox_id` parameter is not supported.
    """

    def __init__(self, region: str | None = None) -> None:
        """Initialize AgentCore provider.

        Args:
            region: AWS region (defaults to `AWS_REGION` /
                `AWS_DEFAULT_REGION` / `us-west-2`).

        Raises:
            ValueError: If boto3 is installed and AWS credentials cannot be
                resolved, or if the workspace scoped the sandbox to specific
                AWS credentials that turn out to be invalid or incomplete.
                Falling back to the server's own credentials there would be a
                silent privilege substitution.
        """
        environment = active_environment()
        # Region resolves through the same table-driven helper as the
        # credentials, so both follow the model path's source order.
        aws_kwargs = resolve_env_kwargs(
            {**AWS_CREDENTIAL_ENV_SOURCES, "region_name": AWS_REGION_ENV_SOURCES},
            environment.get,
        )
        self._region = region or aws_kwargs.get("region_name") or "us-west-2"
        self._session: Any = None

        # Validate AWS credentials early for a clear error message.
        credential_kwargs: dict[str, str] = {}
        try:
            import boto3  # ty: ignore[unresolved-import]

            credential_kwargs = _aws_session_kwargs()
            self._session = boto3.Session(region_name=self._region, **credential_kwargs)
            credentials = self._session.get_credentials()
            if credentials is None:
                msg = (
                    "AWS credentials not found. Configure via "
                    "AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY/AWS_SESSION_TOKEN, "
                    "~/.aws/credentials, or an IAM role."
                )
                raise ValueError(msg)  # noqa: TRY301  # intentional raise for early credential validation
        except ImportError:
            logger.debug("boto3 not installed; skipping credential pre-check")
        except ValueError:
            raise
        except Exception as exc:
            # Without a session the interpreter resolves credentials itself,
            # from the server process rather than this workspace. That is the
            # right default when the workspace scoped nothing, and a privilege
            # substitution when it did -- a workspace pinned to a restricted
            # profile would silently run under the server's broader identity.
            #
            # Compare against what the server resolves on its own: a plain
            # `AWS_PROFILE` exported in the server's shell reaches
            # `active_environment()` too, and treating that as workspace-pinned
            # turned a stale server-level profile into a startup failure whose
            # message blamed a workspace `.env` that never set it.
            server_kwargs = _server_env_kwargs(AWS_CREDENTIAL_ENV_SOURCES)
            if credential_kwargs and credential_kwargs != server_kwargs:
                msg = (
                    f"The workspace AWS configuration is invalid: {exc}. This "
                    f"workspace scoped its sandbox to specific AWS credentials "
                    f"({', '.join(sorted(credential_kwargs))}), so the server's own "
                    f"credentials are not substituted. Fix AWS_PROFILE / "
                    f"AWS_ACCESS_KEY_ID in this workspace's .env, or unset "
                    f"them to use the server's default credentials."
                )
                raise ValueError(msg) from exc
            logger.warning(
                "Could not build an AWS session from the workspace environment "
                "(region=%s). The sandbox will NOT use workspace AWS "
                "credentials and may fail to start. Check your AWS "
                "configuration.",
                self._region,
                exc_info=True,
            )
            self._session = None

        self._active_interpreters: dict[str, Any] = {}

    def get_or_create(
        self,
        *,
        sandbox_id: str | None = None,
        **kwargs: Any,  # noqa: ARG002  # required by SandboxProvider interface
    ) -> SandboxBackendProtocol:
        """Create a new AgentCore Code Interpreter session.

        Args:
            sandbox_id: Not supported — raises `NotImplementedError`
                if provided.
            **kwargs: Additional parameters (unused).

        Returns:
            `AgentCoreSandbox` instance wrapping the started interpreter.

        Raises:
            NotImplementedError: If `sandbox_id` is provided.
        """
        if sandbox_id:
            msg = (
                "AgentCore does not support reconnecting to existing sessions. "
                "Remove the --sandbox-id option."
            )
            raise NotImplementedError(msg)

        agentcore_module = _import_provider_module(
            "bedrock_agentcore.tools.code_interpreter_client",
            provider="agentcore",
            package="langchain-agentcore-codeinterpreter",
        )
        agentcore_backend = _import_provider_module(
            "langchain_agentcore_codeinterpreter",
            provider="agentcore",
            package="langchain-agentcore-codeinterpreter",
        )

        # Pass `session` only when one was built. Handing over `None` would let
        # "no workspace session" masquerade as "workspace session applied",
        # since the SDK then falls back to its own credential resolution.
        interpreter_kwargs: dict[str, Any] = {
            "region": self._region,
            "integration_source": "deepagents-code",
        }
        if self._session is not None:
            interpreter_kwargs["session"] = self._session
        interpreter = agentcore_module.CodeInterpreter(**interpreter_kwargs)
        try:
            interpreter.start()
        except Exception:
            with contextlib.suppress(Exception):
                interpreter.stop()
            raise

        backend = agentcore_backend.AgentCoreSandbox(interpreter=interpreter)
        self._active_interpreters[backend.id] = interpreter
        return backend

    def delete(self, *, sandbox_id: str, **kwargs: Any) -> None:  # noqa: ARG002  # required by SandboxProvider interface
        """Stop an AgentCore session.

        Args:
            sandbox_id: Session ID to stop.
            **kwargs: Additional parameters (unused).
        """
        interpreter = self._active_interpreters.pop(sandbox_id, None)
        if interpreter:
            try:
                interpreter.stop()
                logger.info("AgentCore session %s stopped", sandbox_id)
            except Exception:
                logger.warning(
                    "Failed to stop AgentCore session %s — the session may "
                    "still be running and incurring costs. Check the AWS "
                    "console to verify.",
                    sandbox_id,
                    exc_info=True,
                )
        else:
            logger.info(
                "AgentCore session %s not tracked (may have already expired)",
                sandbox_id,
            )


_VercelStatus = Literal[
    "pending",
    "running",
    "stopping",
    "stopped",
    "failed",
    "aborted",
    "snapshotting",
]
"""Vercel sandbox lifecycle statuses (mirrors the SDK's `SandboxStatus` enum)."""

_VERCEL_TERMINAL_STATUSES: frozenset[_VercelStatus] = frozenset(
    {"aborted", "failed", "stopped"}
)
"""Vercel sandbox statuses that cannot become ready without a new sandbox.

Typing the members as `_VercelStatus` turns a typo into a type error rather than
a silently-never-matching string.
"""

_VERCEL_DEFAULT_RUNTIME = "python3.13"
"""Runtime used when creating a fresh Vercel sandbox."""

_VERCEL_SANDBOX_TIMEOUT = timedelta(minutes=30)
"""Lifetime used for freshly created Vercel sandboxes."""


class _VercelSandboxHandle(Protocol):
    """Minimal Vercel SDK sandbox surface used by the built-in provider."""

    sandbox_id: str
    status: str

    def wait_for_status(self, status: str, *, timeout: int) -> None:
        """Wait for the sandbox to reach the requested status."""

    def stop(self) -> None:
        """Stop the sandbox."""


class _VercelProvider(SandboxProvider):
    """Vercel Sandbox provider implementation."""

    _CREDENTIAL_ENV_NAMES: ClassVar[dict[str, str]] = {
        "token": "VERCEL_TOKEN",
        "project_id": "VERCEL_PROJECT_ID",
        "team_id": "VERCEL_TEAM_ID",
    }
    """SDK credential argument mapped to the env var that supplies it.

    One table drives the lookup, the server-environment baseline, and the
    incomplete-set error, so a renamed argument cannot desynchronize the error
    message from what was actually read.
    """

    def __init__(self) -> None:
        """Initialize the provider, resolving workspace Vercel credentials."""
        self._sdk_kwargs = self._resolve_sdk_kwargs()

    @classmethod
    def _resolve_sdk_kwargs(cls) -> dict[str, str]:
        """Resolve explicit Vercel credentials configured for this workspace.

        Each value resolves prefixed-first then canonical via `resolve_env_var`,
        against the bound workspace environment. Credentials stay SDK-managed
        when every resolved value matches the server environment the SDK reads
        for itself. Explicit credentials must come entirely from the workspace
        or entirely from the server, never a mixture of the two.

        Returns:
            Explicit SDK credential arguments, or an empty mapping to delegate
            credential resolution to the Vercel SDK.

        Raises:
            ValueError: If the workspace overrides part of the `VERCEL_TOKEN` /
                `VERCEL_PROJECT_ID` / `VERCEL_TEAM_ID` set but not all of it.
                Delegating there would use the server's identity instead of
                the credentials the workspace pinned.
        """
        from deepagents_code.model_config import resolve_env_var

        values = {
            key: resolve_env_var(name)
            for key, name in cls._CREDENTIAL_ENV_NAMES.items()
        }
        # Nothing here came from the workspace: `resolve_env_var` reads
        # `active_environment()`, which falls back to `os.environ`, so the
        # server's own `VERCEL_*` resolve identically. There is no workspace
        # identity to protect and the SDK resolves exactly these values, so
        # delegate instead of demanding the full set. That covers inherited
        # token-free OIDC, and a personal-scope token, where `VERCEL_TEAM_ID`
        # is optional and demanding it turned a working setup into a startup
        # failure. A workspace override differs from the server, so it still
        # takes the fail-closed path below.
        if all(
            value == (os.environ.get(cls._CREDENTIAL_ENV_NAMES[key]) or None)
            for key, value in values.items()
        ):
            return {}
        missing = sorted(
            name for key, name in cls._CREDENTIAL_ENV_NAMES.items() if not values[key]
        )
        if missing:
            # Fail closed rather than warn and delegate: an empty mapping hands
            # auth back to the Vercel SDK, which resolves credentials from the
            # server process (`VERCEL_*` in its own environment, or its OIDC
            # identity). A workspace that pinned a restricted token would then
            # silently run its sandbox under the server's broader identity.
            names = list(cls._CREDENTIAL_ENV_NAMES.values())
            required = f"{', '.join(names[:-1])}, and {names[-1]}"
            msg = (
                "The workspace Vercel configuration is incomplete: "
                f"{', '.join(missing)} not set. Set {required} together, or "
                "unset all three to fall back to default Vercel authentication."
            )
            raise ValueError(msg)
        cls._validate_credential_sources(values)
        # `missing` is empty, so every value is a non-empty string here; the
        # comprehension re-states that for the type checker.
        return {key: value for key, value in values.items() if value}

    @classmethod
    def _validate_credential_sources(cls, values: Mapping[str, str | None]) -> None:
        """Reject a workspace credential set completed by inherited fields.

        Compare the selected variable names as well as their values: an
        explicit prefixed workspace ID may equal the server's canonical ID.

        Raises:
            ValueError: If only part of the credential set is inherited.
        """
        from deepagents_code.model_config import resolved_env_var_name

        inherited = [
            name
            for key, name in cls._CREDENTIAL_ENV_NAMES.items()
            if values[key] == os.environ.get(resolved_env_var_name(name))
        ]
        if inherited and len(inherited) != len(values):
            msg = (
                "The Vercel configuration mixes workspace and server credentials: "
                f"{', '.join(inherited)} inherited from the server. "
                "Set VERCEL_TOKEN, VERCEL_PROJECT_ID, and VERCEL_TEAM_ID together "
                "using workspace overrides, or remove the workspace overrides "
                "to use default Vercel authentication."
            )
            raise ValueError(msg)

    def get_or_create(
        self,
        *,
        sandbox_id: str | None = None,
        timeout: int = 180,
        **kwargs: Any,
    ) -> SandboxBackendProtocol:
        """Get or create a Vercel sandbox.

        Args:
            sandbox_id: Existing sandbox ID, or None to create.
            timeout: Seconds to wait for startup.
            **kwargs: Rejected; passing any keyword argument raises `TypeError`.

        Returns:
            `VercelSandbox` instance.

        Raises:
            RuntimeError: If the sandbox fails to start.
            TypeError: If unsupported keyword arguments are provided.
        """
        if kwargs:
            msg = f"Received unsupported arguments: {list(kwargs.keys())}"
            raise TypeError(msg)

        vercel_backend = _import_provider_module(
            "langchain_vercel_sandbox",
            provider="vercel",
            package="langchain-vercel-sandbox",
        )
        vercel_sandbox = _import_provider_module(
            "vercel.sandbox",
            provider="vercel",
            package="vercel",
        )

        # The SDK is imported dynamically, so `Sandbox.get`/`create` are typed
        # `Any`. Annotating pins the result to the Protocol so the type checker
        # verifies the `.status`/`.wait_for_status`/`.stop` calls below.
        sandbox: _VercelSandboxHandle
        try:
            if sandbox_id:
                sandbox = vercel_sandbox.Sandbox.get(
                    sandbox_id=sandbox_id,
                    **self._sdk_kwargs,
                )
            else:
                sandbox = vercel_sandbox.Sandbox.create(
                    runtime=_VERCEL_DEFAULT_RUNTIME,
                    timeout=_VERCEL_SANDBOX_TIMEOUT,
                    **self._sdk_kwargs,
                )
        except Exception as exc:  # Vercel SDK exception types vary by version
            # Keep the message generic so SDK errors cannot leak credentials,
            # but chain the original exception so tracebacks retain root cause.
            action = "connect to existing" if sandbox_id else "create"
            msg = f"Failed to {action} Vercel sandbox."
            raise RuntimeError(msg) from exc

        try:
            self._wait_until_running(sandbox, timeout=timeout)
        except Exception:
            if sandbox_id is None:
                with contextlib.suppress(Exception):
                    sandbox.stop()
            raise

        return vercel_backend.VercelSandbox(sandbox=sandbox)

    def delete(self, *, sandbox_id: str, **kwargs: Any) -> None:  # noqa: ARG002  # **kwargs required by SandboxProvider interface
        """Stop a Vercel sandbox by id.

        Raises:
            RuntimeError: If the Vercel SDK cannot find or stop the sandbox.
        """
        vercel_sandbox = _import_provider_module(
            "vercel.sandbox",
            provider="vercel",
            package="vercel",
        )
        try:
            sandbox = vercel_sandbox.Sandbox.get(
                sandbox_id=sandbox_id,
                **self._sdk_kwargs,
            )
            sandbox.stop()
        except Exception as exc:  # Vercel SDK exception types vary by version
            # Generic message avoids leaking credentials; chain preserves cause.
            msg = "Failed to stop Vercel sandbox."
            raise RuntimeError(msg) from exc

    @staticmethod
    def _wait_until_running(
        sandbox: _VercelSandboxHandle,
        *,
        timeout: int,
    ) -> None:
        """Wait for a Vercel sandbox to become ready.

        Raises:
            RuntimeError: If the sandbox reaches a terminal state or does not
                become ready before the timeout.
        """
        status = str(sandbox.status)
        if status == "running":
            return
        if status in _VERCEL_TERMINAL_STATUSES:
            msg = f"Vercel sandbox {sandbox.sandbox_id} is in terminal state {status!r}"
            raise RuntimeError(msg)

        try:
            sandbox.wait_for_status("running", timeout=timeout)
        except TimeoutError as exc:
            status = str(sandbox.status)
            msg = (
                f"Vercel sandbox {sandbox.sandbox_id} failed to start within "
                f"{timeout} seconds; current status is {status!r}"
            )
            raise RuntimeError(msg) from exc
        except Exception as exc:  # Vercel SDK exception types vary by version
            # Generic message avoids leaking credentials; chain preserves cause.
            msg = "Failed while waiting for Vercel sandbox startup."
            raise RuntimeError(msg) from exc


_OPENSHELL_DEFAULT_WORKSPACE = "default"
"""Workspace the OpenShell CLI uses when `OPENSHELL_WORKSPACE` is unset."""


class _OpenShellProvider(SandboxProvider):
    """NVIDIA OpenShell sandbox provider, bound to the active gateway.

    Credentials come from the OpenShell CLI's on-disk gateway state, so no
    token is read here. `OPENSHELL_GATEWAY` and `OPENSHELL_WORKSPACE` select
    the gateway and workspace, as they do for the CLI.
    """

    def __init__(self) -> None:
        """Connect to the active OpenShell gateway.

        Raises:
            RuntimeError: If no gateway is configured or it cannot be reached.
        """
        openshell = _import_provider_module(
            "openshell",
            provider="openshell",
            package="langchain-nvidia-openshell",
        )

        from deepagents_code.model_config import resolve_env_var

        try:
            self._client = openshell.SandboxClient.from_active_cluster(
                cluster=resolve_env_var("OPENSHELL_GATEWAY")
            )
        except Exception as exc:  # OpenShell SDK exception types vary by version
            # Generic message avoids leaking gateway auth state; chain keeps cause.
            msg = (
                "Failed to connect to the active OpenShell gateway. Run "
                "`openshell gateway select` or set OPENSHELL_GATEWAY."
            )
            raise RuntimeError(msg) from exc
        self._workspace = (
            resolve_env_var("OPENSHELL_WORKSPACE") or _OPENSHELL_DEFAULT_WORKSPACE
        )
        self._names: dict[str, str] = {}
        """Sandbox name by id; the SDK deletes by name, callers delete by id."""

    def get_or_create(
        self,
        *,
        sandbox_id: str | None = None,
        timeout: int = 180,
        **kwargs: Any,  # noqa: ARG002
    ) -> SandboxBackendProtocol:
        """Attach to an OpenShell sandbox by name, or create one.

        Args:
            sandbox_id: Existing sandbox name, as the OpenShell CLI shows it.
            timeout: Seconds to wait for a new sandbox to become ready.
            **kwargs: Unused.

        Returns:
            `OpenShellSandbox` instance.
        """
        backend = _import_provider_module(
            "langchain_nvidia_openshell",
            provider="openshell",
            package="langchain-nvidia-openshell",
        )
        session = self._attach(sandbox_id) if sandbox_id else self._create(timeout)
        self._names[session.id] = session.sandbox.name
        return backend.OpenShellSandbox(sandbox=session)

    def delete(self, *, sandbox_id: str, **kwargs: Any) -> None:  # noqa: ARG002
        """Delete an OpenShell sandbox by id, or by name if it was not created here."""
        name = self._names.pop(sandbox_id, sandbox_id)
        self._client.delete(name, workspace=self._workspace, allow_missing=True)

    def _attach(self, name: str) -> Any:  # noqa: ANN401  # `openshell.SandboxSession`; SDK is optional
        try:
            return self._client.get_session(name, workspace=self._workspace)
        except Exception as exc:
            code = getattr(exc, "code", None)
            if callable(code) and getattr(code(), "name", None) == "NOT_FOUND":
                raise SandboxNotFoundError(name) from exc
            raise

    def _create(self, timeout: int) -> Any:  # noqa: ANN401  # `openshell.SandboxSession`; SDK is optional
        session = self._client.create_session(workspace=self._workspace)
        name = session.sandbox.name
        try:
            self._client.wait_ready(
                name, workspace=self._workspace, timeout_seconds=timeout
            )
        except Exception as exc:
            self._discard(name)
            msg = (
                f"OpenShell sandbox {name} did not become ready within "
                f"{timeout} seconds."
            )
            raise RuntimeError(msg) from exc
        return session

    def _discard(self, name: str) -> None:
        """Delete a sandbox that failed to start; `create_sandbox` never saw it."""
        try:
            self._client.delete(name, workspace=self._workspace, allow_missing=True)
        except Exception:  # Cleanup must not mask the startup failure
            logger.warning("Could not delete OpenShell sandbox %s", name, exc_info=True)


def _get_provider(
    provider_name: str,
    registry: SandboxRegistry | None = None,
) -> SandboxProvider:
    """Get a `SandboxProvider` instance for the specified provider (internal).

    Args:
        provider_name: Name of the provider. Resolved through the registry so
            built-in, entry-point, and config providers are all supported.
        registry: An already-built registry to reuse. A fresh one is loaded
            when omitted.

    Returns:
        `SandboxProvider` instance. Propagates `ValueError` from the registry
            if `provider_name` is unknown.
    """
    reg = registry if registry is not None else _get_registry()
    return reg.create_provider(provider_name)


def verify_sandbox_deps(provider: str) -> None:
    """Check that the required packages for a sandbox provider are installed.

    Uses `importlib.util.find_spec` for a lightweight check with no actual
    imports. Call this in the app's process *before* spawning the server
    subprocess so users get a clear, actionable error instead of an opaque
    server crash. The backend module to probe and the install hint both come
    from provider metadata.

    Args:
        provider: Sandbox provider name (e.g. `'daytona'`).

    Raises:
        ImportError: If the provider's backend package is not installed.
    """
    if not provider or provider == "none":
        return

    metadata = _get_registry().get_metadata(provider)
    if metadata is None or metadata.backend_module is None:
        logger.debug(
            "No backend module to probe for provider %r; skipping pre-flight check",
            provider,
        )
        return

    try:
        found = importlib.util.find_spec(metadata.backend_module) is not None
    except ImportError, ValueError:
        found = False

    if not found:
        if metadata.install is not None:
            install_hint = (
                f"Install with: {metadata.install.command(in_app=True)} (in-app) "
                f"or {metadata.install.command(in_app=False)} (CLI)"
            )
        else:
            install_hint = "Install the provider's package."
        msg = f"Missing dependencies for '{provider}' sandbox. {install_hint}"
        raise ImportError(msg)


__all__ = [
    "create_sandbox",
    "get_default_working_dir",
    "verify_sandbox_deps",
]


@asynccontextmanager
async def owned_sandbox(
    provider: str,
    *,
    sandbox_id: str | None = None,
    snapshot_name: str | None = None,
    quiet: bool = False,
) -> AsyncGenerator[str | None]:
    """Own a sandbox's lifetime from the client process.

    Yields the sandbox ID to hand to the server. When no ID was supplied and
    the provider supports reuse by ID, the sandbox is created here and deleted
    on exit -- regardless of how the server process later terminates. In every
    other case the given ID (or None) is yielded unchanged and the server keeps
    ownership through `create_sandbox`, exactly as before.

    Why this exists: `create_sandbox` runs inside the langgraph server and
    releases the sandbox from an `atexit` handler. The client stops that
    server with SIGTERM, which bypasses `atexit`, so the sandbox leaked until
    the provider's own timeout reclaimed it. Deleting from the client's control
    flow removes the dependence on how the server process dies.

    Yields:
        The sandbox ID for the server to reuse, or `None`.
    """
    if provider == "none" or sandbox_id is not None:
        yield sandbox_id
        return

    registry = _get_registry()
    metadata = registry.get_metadata(provider)
    if metadata is None or not metadata.supports_sandbox_id:
        yield None
        return
    if snapshot_name is not None and not metadata.supports_snapshot_name:
        yield None  # let create_sandbox raise its usual error server-side
        return

    provider_obj = _get_provider(provider, registry=registry)
    provider_kwargs: dict[str, Any] = dict(registry.get_params(provider))
    if snapshot_name is not None:
        provider_kwargs["snapshot"] = snapshot_name

    if not quiet:
        console.print(f"[yellow]Starting {provider} sandbox...[/yellow]")
    backend = await provider_obj.aget_or_create(**provider_kwargs)
    if not quiet:
        console.print(
            f"[green]{get_glyphs().checkmark} {provider.capitalize()} sandbox "
            f"ready: {backend.id}[/green]"
        )
    try:
        yield backend.id
    finally:
        try:
            await provider_obj.adelete(sandbox_id=backend.id)
            if not quiet:
                console.print(
                    f"[dim]{get_glyphs().checkmark} {provider.capitalize()} "
                    f"sandbox {backend.id} terminated[/dim]"
                )
        except Exception:
            logger.warning(
                "Failed to delete %s sandbox %s", provider, backend.id, exc_info=True
            )
