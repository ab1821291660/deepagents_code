"""Shell completion scripts for the `dcode` command line.

`dcode completion <shell>` prints a completion script for bash, zsh, or fish.
The candidates are read from the same argparse parser that handles real
invocations, so a new flag or subcommand appears after regenerating the script
instead of needing a second list kept in sync by hand.

Generated scripts are static: write one to a file and source it from the
shell's startup file. `dcode completion -h` prints the per-shell setup.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator, Sequence

SHELLS: tuple[str, ...] = ("bash", "zsh", "fish")
"""Shell dialects accepted by `dcode completion`."""

DEFAULT_PROGRAMS: tuple[str, ...] = ("dcode", "deepagents-code")
"""Console scripts registered in `pyproject.toml` (`[project.scripts]`)."""

_PROGRAM_RE = re.compile(r"\A[A-Za-z0-9][A-Za-z0-9._+-]*\Z")
"""Command names allowed in generated shell code."""

_WORD_RE = re.compile(r"\A[A-Za-z0-9_.:/@+=,-]+\Z")
"""Words safe to emit unquoted in bash, zsh, and fish completion code.

An allowlist, so a future choice containing `|`, `;`, `*`, `$`, or `(` is
dropped instead of running as shell code when the user presses TAB.
"""

_INDENT = "    "


@dataclass(frozen=True)
class OptionSpec:
    """One optional argument exposed to shell completion."""

    flags: tuple[str, ...]
    help: str
    takes_value: bool
    optional_value: bool
    choices: tuple[str, ...]


@dataclass(frozen=True)
class PositionalSpec:
    """One positional argument exposed to shell completion."""

    name: str
    help: str
    choices: tuple[str, ...]


@dataclass(frozen=True)
class CommandSpec:
    """One command level: the root, a command group, or a leaf command."""

    names: tuple[str, ...]
    """Canonical name followed by any aliases."""

    path: str
    """Space-joined canonical names leading here; empty for the root."""

    help: str = ""
    options: tuple[OptionSpec, ...] = ()
    positionals: tuple[PositionalSpec, ...] = ()
    subcommands: tuple[CommandSpec, ...] = ()


def build_spec(
    parser: argparse.ArgumentParser,
    programs: Sequence[str] = DEFAULT_PROGRAMS,
) -> CommandSpec:
    """Extract the completion tree from an argparse parser.

    Args:
        parser: Fully built CLI parser.
        programs: Names stored on the root spec. Scripts register the
            names passed to `render_script`, not these.

    Returns:
        The root command spec.
    """
    return _command_spec(parser, names=tuple(programs), path="")


def render_script(
    shell: str,
    root: CommandSpec,
    programs: Sequence[str],
) -> str:
    """Render a completion script.

    Args:
        shell: One of `SHELLS`.
        root: Root command spec from `build_spec`.
        programs: Command names to register.

    Returns:
        The script text.

    Raises:
        ValueError: If `shell` is not supported or a program name is unsafe.
    """
    try:
        renderer = _RENDERERS[shell]
    except KeyError:
        msg = f"unsupported shell: {shell!r}"
        raise ValueError(msg) from None
    checked = tuple(_checked_program(name) for name in programs)
    return renderer(root, checked)


def program_arg(value: str) -> str:
    """Validate a `--prog` value for argparse.

    Args:
        value: Raw command name.

    Returns:
        The validated name.

    Raises:
        argparse.ArgumentTypeError: If the name is not a safe command name.
    """
    if not _PROGRAM_RE.match(value):
        msg = f"invalid command name: {value!r}"
        raise argparse.ArgumentTypeError(msg)
    return value


def run_completion_command(args: argparse.Namespace) -> int:
    """Print a completion script, or the help screen when no shell is given.

    Args:
        args: Parsed CLI namespace with `shell` and optional `prog`.

    Returns:
        Process exit code: `2` when no shell is given and stdout is not a
            terminal, so `dcode completion > file` fails instead of saving the
            help screen as a script.
    """
    if getattr(args, "shell", None) is None:
        if not sys.stdout.isatty():
            sys.stderr.write(
                "dcode completion: missing shell (bash, zsh, or fish); "
                "run `dcode completion -h` for setup\n"
            )
            return 2
        from deepagents_code import ui

        ui.show_completion_help()
        return 0

    from deepagents_code.main import build_parser

    programs = tuple(args.prog) if getattr(args, "prog", None) else DEFAULT_PROGRAMS
    root = build_spec(build_parser(), programs)
    _write_stdout(render_script(args.shell, root, programs))
    return 0


def _write_stdout(text: str) -> None:
    """Write to stdout, staying quiet when the reader closes the pipe early.

    Args:
        text: Text to write.
    """
    try:
        # Scripts are UTF-8 regardless of the locale; help text can contain
        # characters such as an em dash that an ASCII stdout cannot encode.
        buffer = getattr(sys.stdout, "buffer", None)
        if buffer is None:
            sys.stdout.write(text)
        else:
            sys.stdout.flush()
            buffer.write(text.encode())
        sys.stdout.flush()
    except BrokenPipeError:
        # A reader such as `head` exited. Point stdout at devnull so the
        # interpreter's exit-time flush does not raise again.
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        os.close(devnull)


def _command_spec(
    parser: argparse.ArgumentParser,
    *,
    names: tuple[str, ...],
    path: str,
    help_text: str = "",
) -> CommandSpec:
    """Convert one argparse parser into a `CommandSpec`.

    Args:
        parser: Parser for this command level.
        names: Canonical name and aliases that reach this level.
        path: Space-joined canonical names leading here.
        help_text: Help text inherited from the parent subparser action.

    Returns:
        The converted command level.
    """
    options: list[OptionSpec] = []
    positionals: list[PositionalSpec] = []
    subparsers: argparse._SubParsersAction | None = None
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            subparsers = action
        elif action.option_strings:
            option = _option_spec(action, _help_text(parser, action))
            if option is not None:
                options.append(option)
        else:
            positional = _positional_spec(action, _help_text(parser, action))
            if positional is not None:
                positionals.append(positional)
    subcommands = _subcommand_specs(subparsers, path) if subparsers is not None else ()
    return CommandSpec(
        names=names,
        path=path,
        help=help_text,
        options=tuple(options),
        positionals=tuple(positionals),
        subcommands=subcommands,
    )


def _help_text(parser: argparse.ArgumentParser, action: argparse.Action) -> str:
    """Return an action's help as `-h` shows it, on one line.

    Expands placeholders such as `%(default)s` the same way argparse does.

    Args:
        parser: Parser that owns the action.
        action: Argument action to describe.

    Returns:
        The expanded help text, or an empty string when there is none.
    """
    if not action.help or action.help is argparse.SUPPRESS:
        return ""
    return _one_line(parser._get_formatter()._expand_help(action))


def _option_spec(action: argparse.Action, help_text: str) -> OptionSpec | None:
    """Convert an optional action.

    Args:
        action: Option action from an argparse parser.
        help_text: Expanded one-line help for the action.

    Returns:
        The option spec, or `None` when the action is hidden.
    """
    if action.help is argparse.SUPPRESS:
        return None
    return OptionSpec(
        flags=tuple(action.option_strings),
        help=help_text,
        takes_value=action.nargs != 0,
        optional_value=action.nargs == argparse.OPTIONAL,
        choices=_choices(action),
    )


def _positional_spec(action: argparse.Action, help_text: str) -> PositionalSpec | None:
    """Convert a positional action.

    Args:
        action: Positional action from an argparse parser.
        help_text: Expanded one-line help for the action.

    Returns:
        The positional spec, or `None` when the action is hidden.
    """
    if action.help is argparse.SUPPRESS:
        return None
    return PositionalSpec(
        name=action.dest,
        help=help_text,
        choices=_choices(action),
    )


def _subcommand_specs(
    action: argparse._SubParsersAction,
    parent_path: str,
) -> tuple[CommandSpec, ...]:
    """Convert a subparser action into child specs, grouping aliases.

    Args:
        action: Subparsers action holding the child parsers.
        parent_path: Space-joined canonical names leading to this level.

    Returns:
        One spec per distinct child parser, with aliases grouped.
    """
    help_by_name = {
        pseudo.dest: _one_line(pseudo.help)
        for pseudo in getattr(action, "_choices_actions", ())
    }
    grouped: dict[int, list[str]] = {}
    parsers: dict[int, argparse.ArgumentParser] = {}
    for name, parser in action.choices.items():
        key = id(parser)
        grouped.setdefault(key, []).append(name)
        parsers[key] = parser
    specs = []
    for key, names in grouped.items():
        canonical = names[0]
        specs.append(
            _command_spec(
                parsers[key],
                names=tuple(names),
                path=f"{parent_path} {canonical}".strip(),
                help_text=help_by_name.get(canonical, ""),
            )
        )
    return tuple(specs)


def _one_line(text: str | None) -> str:
    """Collapse argparse help text to one line.

    Args:
        text: Raw argparse help text, possibly `None`.

    Returns:
        The help text with whitespace collapsed.
    """
    return "" if text is None else " ".join(text.split())


def _choices(action: argparse.Action) -> tuple[str, ...]:
    """Return an action's fixed choices as strings.

    Args:
        action: Argument action to read.

    Returns:
        The action's choices, or an empty tuple when it has none.
    """
    choices = action.choices
    if not choices:
        return ()
    if isinstance(choices, dict):
        return tuple(str(name) for name in choices)
    return tuple(str(choice) for choice in choices)


def _checked_program(name: str) -> str:
    """Validate a program name used in generated shell code.

    Args:
        name: Command name to validate.

    Returns:
        The validated name.

    Raises:
        ValueError: If the name contains characters unsafe for shell code.
    """
    if not _PROGRAM_RE.match(name):
        msg = f"invalid program name for completion: {name!r}"
        raise ValueError(msg)
    return name


def _pattern(names: Sequence[str]) -> str:
    """Join names into a shell `case` pattern.

    Args:
        names: Case alternatives.

    Returns:
        The alternatives joined with `|`.
    """
    return "|".join(names)


def _iter_levels(root: CommandSpec) -> Iterator[CommandSpec]:
    """Yield the root and every nested command level.

    Args:
        root: Root command spec.

    Yields:
        Every level in pre-order.
    """
    yield root
    for child in root.subcommands:
        yield from _iter_levels(child)


def _candidates(level: CommandSpec) -> tuple[str, ...]:
    """Return the flag, subcommand, and positional words for one level.

    Words that fail `_WORD_RE` are skipped.

    Args:
        level: Command level to describe.

    Returns:
        Flags, then subcommand names, then positional choices, each in
            declaration order, without duplicates.
    """
    words = [flag for option in level.options for flag in option.flags]
    words.extend(name for child in level.subcommands for name in child.names)
    words.extend(
        choice for positional in level.positionals for choice in positional.choices
    )
    return tuple(dict.fromkeys(word for word in words if _WORD_RE.match(word)))


def _level_choices(level: CommandSpec) -> dict[str, tuple[str, ...]]:
    """Map each flag at one level to the fixed values it accepts.

    A flag spelling can mean different things at different levels (for
    example, `--project` takes a value under `auth set` but not under
    `skills list`), so callers look flags up per level.

    Args:
        level: Command level to describe.

    Returns:
        A mapping from flag spelling to its accepted values.
    """
    mapping: dict[str, tuple[str, ...]] = {}
    for option in level.options:
        values = tuple(choice for choice in option.choices if _WORD_RE.match(choice))
        if not values or not option.takes_value:
            continue
        for flag in option.flags:
            mapping.setdefault(flag, values)
    return mapping


def _level_required(level: CommandSpec) -> tuple[str, ...]:
    """Return the flags at one level that always consume the following word.

    Args:
        level: Command level to describe.

    Returns:
        Flag spellings whose value is required.
    """
    return tuple(
        dict.fromkeys(
            flag
            for option in level.options
            if option.takes_value and not option.optional_value
            for flag in option.flags
        )
    )


def _sh_needs_value_function(root: CommandSpec) -> list[str]:
    """Emit `_dcode_needs_value`, shared by the bash and zsh scripts.

    The function succeeds when flag `$2` takes a required value at command
    path `$1`, so the word scan can skip that value.

    Args:
        root: Root command spec.

    Returns:
        Script lines for the function.
    """
    lines = ["_dcode_needs_value() {", '    case "$1" in']
    for level in _iter_levels(root):
        required = _level_required(level)
        if required:
            lines += [
                f'        "{level.path}")',
                f'            case "$2" in {_pattern(required)}) return 0 ;; esac',
                "            ;;",
            ]
    lines += ["    esac", "    return 1", "}", ""]
    return lines


def _bash_script(root: CommandSpec, programs: Sequence[str]) -> str:
    """Render a bash completion script.

    Args:
        root: Root command spec.
        programs: Command names to register.

    Returns:
        The bash script.
    """
    lines = [
        f"# bash completion for {'/'.join(programs)}",
        "# Generated by `dcode completion bash`; regenerate after CLI changes.",
        "",
        *_sh_needs_value_function(root),
        "_dcode_completion() {",
        "    local cur prev cmd w i",
        "    COMPREPLY=()",
        '    cur="${COMP_WORDS[COMP_CWORD]}"',
        '    prev="${COMP_WORDS[COMP_CWORD-1]}"',
        '    cmd=""',
        "    # Complete `--flag=value` like `--flag value`. Bash 4+ splits it",
        "    # into `--flag`, `=`, and `value`; bash 3.2 keeps one word. Either",
        "    # way readline replaces only the text after `=`.",
        '    if [[ "$cur" == "=" ]]; then',
        '        cur=""',
        '    elif [[ "$prev" == "=" ]]; then',
        '        prev="${COMP_WORDS[COMP_CWORD-2]}"',
        '    elif [[ "$cur" == -*=* ]]; then',
        '        prev="${cur%%=*}"',
        '        cur="${cur#*=}"',
        "    fi",
        "",
    ]
    lines += _bash_command_scan(root)
    lines.append("")
    lines += _value_case(root, _bash_value_arms)
    lines += _bash_candidate_case(root)
    lines += ["}", ""]
    lines += [
        f"complete -o bashdefault -o default -F _dcode_completion {program}"
        for program in programs
    ]
    return "\n".join(lines) + "\n"


def _bash_command_scan(root: CommandSpec) -> list[str]:
    """Emit the loop that walks typed words to find the subcommand path.

    Args:
        root: Root command spec.

    Returns:
        Script lines for the word-scanning loop.
    """
    lines = [
        "    # Find the deepest subcommand typed before the cursor.",
        "    for ((i = 1; i < COMP_CWORD; i++)); do",
        '        w="${COMP_WORDS[i]}"',
        '        case "$w" in',
        "            --) break ;;",
        "            # The word after a split `--flag=` is that flag's value.",
        "            =) i=$((i + 1)); continue ;;",
        "            -*)",
        '                if [[ "${COMP_WORDS[i+1]}" != "=" ]] &&',
        '                    _dcode_needs_value "$cmd" "$w"; then',
        "                    i=$((i + 1))",
        "                fi",
        "                continue",
        "                ;;",
        "        esac",
    ]
    lines += _transitions(root, _INDENT * 2)
    lines.append("    done")
    return lines


def _transitions(root: CommandSpec, indent: str) -> list[str]:
    """Emit a `case "$cmd"` block that advances on each subcommand name.

    Args:
        root: Root command spec.
        indent: Leading indentation for the emitted block.

    Returns:
        Script lines for the transition block.
    """
    groups = [level for level in _iter_levels(root) if level.subcommands]
    if not groups:
        return []
    lines = [f'{indent}case "$cmd" in']
    for level in groups:
        lines.extend([f'{indent}    "{level.path}")', f'{indent}        case "$w" in'])
        lines.extend(
            f'{indent}            {_pattern(child.names)}) cmd="{child.path}" ;;'
            for child in level.subcommands
        )
        lines.extend([f"{indent}        esac", f"{indent}        ;;"])
    lines.append(f"{indent}esac")
    return lines


def _value_case(
    root: CommandSpec,
    arms: Callable[[CommandSpec], list[str]],
) -> list[str]:
    """Emit option-value completion, looked up per command level.

    Args:
        root: Root command spec.
        arms: Shell-specific `case "$prev"` arms for one level.

    Returns:
        Script lines for the value branch.
    """
    lines: list[str] = []
    for level in _iter_levels(root):
        level_arms = arms(level)
        if level_arms:
            lines += [
                f'            "{level.path}")',
                '                case "$prev" in',
                *level_arms,
                "                esac",
                "                ;;",
            ]
    if not lines:
        return []
    return [
        '    if [[ "$cur" != -* ]]; then',
        '        case "$cmd" in',
        *lines,
        "        esac",
        "    fi",
    ]


def _bash_value_arms(level: CommandSpec) -> list[str]:
    """Emit bash `case "$prev"` arms for one level's option values.

    Free-form values return an empty reply, which `complete -o default` turns
    into file-name completion.

    Args:
        level: Command level to describe.

    Returns:
        Case arms, or an empty list when no option at this level takes a value.
    """
    choices = _level_choices(level)
    fallback = [flag for flag in _level_required(level) if flag not in choices]
    lines = [
        f'                    {flag}) COMPREPLY=( $(compgen -W "{" ".join(values)}"'
        ' -- "$cur") ); return 0 ;;'
        for flag, values in choices.items()
    ]
    if fallback:
        lines.append(f"                    {_pattern(fallback)}) return 0 ;;")
    return lines


def _bash_candidate_case(root: CommandSpec) -> list[str]:
    """Emit candidate words for every command level.

    Args:
        root: Root command spec.

    Returns:
        Script lines for the candidate branch.
    """
    lines = ['    case "$cmd" in']
    for level in _iter_levels(root):
        words = " ".join(_candidates(level))
        lines.extend(
            [
                f'        "{level.path}")',
                f'            COMPREPLY=( $(compgen -W "{words}" -- "$cur") )',
                "            ;;",
            ]
        )
    lines.append("    esac")
    return lines


def _zsh_script(root: CommandSpec, programs: Sequence[str]) -> str:
    """Render a zsh completion script.

    Args:
        root: Root command spec.
        programs: Command names to register.

    Returns:
        The zsh script.
    """
    lines = [
        f"#compdef {' '.join(programs)}",
        "# Generated by `dcode completion zsh`; regenerate after CLI changes.",
        "",
        *_sh_needs_value_function(root),
        "_dcode_completion() {",
        "    local cur prev cmd w i",
        "    local -a candidates",
        '    cur="${words[CURRENT]}"',
        '    prev="${words[CURRENT-1]}"',
        '    cmd=""',
        "",
    ]
    lines += _zsh_command_scan(root)
    lines.append("")
    lines += _value_case(root, _zsh_value_arms)
    lines += _zsh_candidate_case(root)
    lines += [
        "}",
        "",
        "if (( $+functions[compdef] )); then",
        f"    compdef _dcode_completion {' '.join(programs)}",
        "fi",
        "# When autoloaded from `fpath`, the file body runs as the function",
        "# named after the file, so a fixed function name cannot detect it.",
        "# Match the execution context instead: `loadautofunc` on the first",
        "# call, `shfunc` when a loaded copy is invoked directly later.",
        'if [[ "${zsh_eval_context[-1]}" == (loadautofunc|shfunc) ]]; then',
        '    _dcode_completion "$@"',
        "fi",
    ]
    return "\n".join(lines) + "\n"


def _zsh_command_scan(root: CommandSpec) -> list[str]:
    """Emit the zsh word walk mirroring `_bash_command_scan`.

    Args:
        root: Root command spec.

    Returns:
        Script lines for the word-scanning loop.
    """
    lines = [
        "    # Find the deepest subcommand typed before the cursor.",
        "    for ((i = 2; i < CURRENT; i++)); do",
        '        w="${words[i]}"',
        '        case "$w" in',
        "            --) break ;;",
        "            -*)",
        '                _dcode_needs_value "$cmd" "$w" && (( i += 1 ))',
        "                continue",
        "                ;;",
        "        esac",
    ]
    lines += _transitions(root, _INDENT * 2)
    lines.append("    done")
    return lines


def _zsh_value_arms(level: CommandSpec) -> list[str]:
    """Emit zsh `case "$prev"` arms for one level's option values.

    Args:
        level: Command level to describe.

    Returns:
        Case arms, or an empty list when no option at this level takes a value.
    """
    choices = _level_choices(level)
    fallback = [flag for flag in _level_required(level) if flag not in choices]
    lines = [
        f"                    {flag}) compadd -- {' '.join(values)}; return ;;"
        for flag, values in choices.items()
    ]
    if fallback:
        lines.append(f"                    {_pattern(fallback)}) _files; return ;;")
    return lines


def _zsh_candidate_case(root: CommandSpec) -> list[str]:
    """Emit candidate words for every command level.

    Args:
        root: Root command spec.

    Returns:
        Script lines for the candidate branch.
    """
    lines = ['    case "$cmd" in']
    for level in _iter_levels(root):
        words = " ".join(_candidates(level))
        lines.extend(
            [
                f'        "{level.path}")',
                f"            candidates=({words})",
                '            (( ${#candidates[@]} )) && compadd -- "${candidates[@]}"',
                "            ;;",
            ]
        )
    lines.append("    esac")
    return lines


def _fish_script(root: CommandSpec, programs: Sequence[str]) -> str:
    """Render a fish completion script.

    Args:
        root: Root command spec.
        programs: Command names to register.

    Returns:
        The fish script.
    """
    lines = [
        f"# fish completion for {'/'.join(programs)}",
        "# Generated by `dcode completion fish`; regenerate after CLI changes.",
        "",
    ]
    lines += _fish_path_function(root)
    for program in programs:
        for level in _iter_levels(root):
            lines += _fish_level_lines(level, program)
    return "\n".join(lines) + "\n"


def _fish_path_function(root: CommandSpec) -> list[str]:
    """Emit `__dcode_at`, which tests the command path typed so far.

    Fish's `__fish_seen_subcommand_from` matches a name anywhere on the line,
    so `mcp config` would also select top-level `config`. Walking the words
    the way the bash scan does tracks the full path instead.

    Args:
        root: Root command spec.

    Returns:
        Fish function lines.
    """
    lines = [
        "# Succeed when flag $argv[2] takes a required value at path $argv[1].",
        "function __dcode_needs_value",
        "    switch $argv[1]",
    ]
    for level in _iter_levels(root):
        required = " ".join(_fish_quote(flag) for flag in _level_required(level))
        if required:
            lines += [
                f"        case {_fish_quote(level.path)}",
                "            switch $argv[2]",
                f"                case {required}",
                "                    return 0",
                "            end",
            ]
    lines += ["    end", "    return 1", "end", ""]
    lines += [
        "# Succeed when the command path before the cursor equals $argv[1].",
        "function __dcode_at",
        "    set -l tokens (commandline -opc)",
        "    set -e tokens[1]",
        "    set -l cmd ''",
        "    set -l skip 0",
        "    for w in $tokens",
        "        if test $skip -eq 1",
        "            set skip 0",
        "            continue",
        "        end",
        "        switch $w",
        "            case '--'",
        "                break",
        "            case '-*'",
        '                __dcode_needs_value "$cmd" $w; and set skip 1',
        "                continue",
        "        end",
    ]
    lines += _fish_transitions(root)
    lines += ["    end", '    test "$cmd" = "$argv[1]"', "end", ""]
    return lines


def _fish_transitions(root: CommandSpec) -> list[str]:
    """Emit a fish `switch $cmd` block that advances on each subcommand name.

    Args:
        root: Root command spec.

    Returns:
        Fish lines for the transition block.
    """
    lines = ["        switch $cmd"]
    for level in _iter_levels(root):
        if not level.subcommands:
            continue
        lines += [
            f"            case {_fish_quote(level.path)}",
            "                switch $w",
        ]
        for child in level.subcommands:
            names = " ".join(_fish_quote(name) for name in child.names)
            lines += [
                f"                    case {names}",
                f"                        set cmd {_fish_quote(child.path)}",
            ]
        lines.append("                end")
    lines.append("        end")
    return lines


def _fish_level_lines(level: CommandSpec, program: str) -> list[str]:
    """Emit fish completions for one command level.

    Args:
        level: Command level to describe.
        program: Command name to register completions for.

    Returns:
        Fish completion lines.
    """
    condition = _fish_quote(f"__dcode_at {_fish_quote(level.path)}")
    lines: list[str] = []
    for option in level.options:
        # Fish reads a required value's candidates only from the flag's own
        # line, so the choices must be attached here.
        values = ""
        choices = _safe_words(option.choices)
        if option.takes_value and choices:
            values = f" -f -a {_fish_quote(' '.join(choices))}"
        for flag in option.flags:
            spec = _fish_flag(flag, option.takes_value and not option.optional_value)
            if spec is not None:
                lines.append(
                    f"complete -c {program} -n {condition} "
                    f"{spec}{values} -d {_fish_quote(option.help)}"
                )
    lines.extend(
        f"complete -c {program} -f -n {condition} "
        f"-a {_fish_quote(name)} -d {_fish_quote(child.help)}"
        for child in level.subcommands
        for name in _safe_words(child.names)
    )
    for positional in level.positionals:
        choices = _safe_words(positional.choices)
        if choices:
            values = _fish_quote(" ".join(choices))
            lines.append(f"complete -c {program} -f -n {condition} -a {values}")
    return lines


def _safe_words(words: Sequence[str]) -> tuple[str, ...]:
    """Keep only words that pass `_WORD_RE`.

    Fish expands `-a` arguments each time it completes, so quoting alone does
    not stop `$x` or `(cmd)` in a candidate from running.

    Args:
        words: Candidate words.

    Returns:
        The words that are safe to emit.
    """
    return tuple(word for word in words if _WORD_RE.match(word))


def _fish_flag(flag: str, requires_value: bool) -> str | None:
    """Return the fish `-s`/`-l` spec for a flag.

    Args:
        flag: Flag spelling, such as `-M` or `--model`.
        requires_value: Whether the flag always consumes a value.

    Returns:
        The fish flag spec, or `None` for flags it cannot express.
    """
    if flag.startswith("--"):
        spec = f"-l {_fish_quote(flag[2:])}"
    elif flag.startswith("-") and len(flag) == 2:  # noqa: PLR2004  # short option
        spec = f"-s {_fish_quote(flag[1:])}"
    else:
        return None
    if requires_value:
        spec += " -r"
    return spec


def _fish_quote(value: str) -> str:
    """Quote one fish word or description.

    Args:
        value: Text to quote.

    Returns:
        The text wrapped in fish single quotes.
    """
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"


_RENDERERS: dict[str, Callable[[CommandSpec, Sequence[str]], str]] = {
    "bash": _bash_script,
    "zsh": _zsh_script,
    "fish": _fish_script,
}
