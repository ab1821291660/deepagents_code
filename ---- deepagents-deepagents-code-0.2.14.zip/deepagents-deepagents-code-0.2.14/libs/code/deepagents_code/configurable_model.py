"""Middleware for runtime model selection via LangGraph runtime context.

Allows switching the model per invocation by passing a `CLIContext` via
`context=` on `agent.astream()` / `agent.invoke()` without recompiling
the graph.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from deepagents._models import (  # noqa: PLC2701
    get_model_identifier,
    model_matches_spec,
)
from langchain.agents.middleware.types import (
    AgentMiddleware,
    ExtendedModelResponse,
    ModelRequest,
    ModelResponse,
    TracePolicy,
    omit_payload,
)
from langchain_core.messages import AIMessage
from langgraph.types import Command

from deepagents_code._cli_context import CLIContextSchema
from deepagents_code.cold_cache import (
    CacheActivity,
    cache_identity_params,
    cache_request,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from langchain_core.language_models import BaseChatModel

    from deepagents_code.config import ModelResult


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class _ResolvedModelRequest:
    """Model request plus the checkpoint metadata it should persist."""

    request: ModelRequest
    """Request to pass to the downstream model handler."""

    model_spec: str | None
    """Resolved `provider:model` spec to persist for resume, when known."""

    model_params: dict[str, Any] | None = None
    """Invocation params to persist, or `None` to clear checkpointed params."""

    model_params_known: bool = False
    """Whether `model_params` is known and should be written to the checkpoint."""


def _cache_endpoint_identity(
    model_spec: str | None, model_params: Mapping[str, Any] | None = None
) -> str:
    """Resolve the endpoint identity used by a model request for checkpointing.

    Performs blocking filesystem reads: `ModelConfig.load()` is process-cached,
    but `get_base_url` falls through to the credential store for any provider
    with no `config.toml` `base_url` and no base-URL env var *set* -- the
    default for `anthropic` and `openai`, whose env vars are registered in
    `PROVIDER_BASE_URL_ENV` but normally unset -- and that store re-reads its
    file every call. Callers on the blockbuster-guarded server loop must
    therefore invoke this via `asyncio.to_thread` (see
    `ConfigurableModelMiddleware.awrap_model_call`).

    A spec with no `provider:` prefix cannot name an endpoint, so it resolves to
    the same identity as the provider default. That is preferable to returning
    nothing: `_last_cache_endpoint` is written unconditionally alongside the
    spec and timestamp it describes, and a skipped write would leave the
    previous turn's endpoint paired with this turn's spec.

    The provider is normalized exactly as the reader normalizes it
    (`app._cold_cache_warning_for`). `get_kwargs`/`get_base_url` are
    exact-key lookups, so a spec the user spelled `Anthropic:claude-opus-5`
    would resolve `default` here while the reader resolved the real endpoint --
    a disagreement that never self-heals, because both sides keep recomputing
    their own answer, and every send would report `identity_changed`.

    Never raises. Cache identity must not prevent a model request. A malformed
    (a non-string `base_url` from a `class_path` provider that ignores it, say)
    endpoint must not turn a diagnostic into a failed model call. Failing to
    the provider default is the same degradation an unreadable checkpointed
    endpoint already gets.

    Returns:
        The normalized endpoint identity, or the provider-default identity when
        it cannot be resolved.
    """
    from deepagents_code.cold_cache import endpoint_cache_identity

    if not model_spec or ":" not in model_spec:
        return endpoint_cache_identity(None)
    from deepagents_code.model_config import ModelConfig

    raw_provider, _, model_name = model_spec.partition(":")
    provider = raw_provider.strip().lower()
    try:
        config = ModelConfig.load()
        kwargs = config.get_effective_kwargs(
            provider,
            model_name=model_name,
            overrides=model_params,
        )
        base_url = (
            kwargs.get("base_url")
            if isinstance(kwargs, dict)
            else config.get_base_url(provider)
        )
    except Exception:
        logger.warning(
            "Could not resolve the cache endpoint for %r; recording the "
            "provider default, so an endpoint change may go undetected for "
            "this turn",
            provider,
            exc_info=True,
        )
        return endpoint_cache_identity(None)
    return endpoint_cache_identity(base_url if isinstance(base_url, str) else None)


def _get_ls_provider(model: object) -> str | None:
    """Return the LangSmith provider name reported by a chat model.

    Returns:
        The `ls_provider` string when the model reports one, otherwise `None`
            (including when `_get_ls_params` is missing, raises, or yields a
            non-string provider).
    """
    try:
        ls_params = model._get_ls_params()  # ty: ignore[unresolved-attribute]
    except AttributeError, TypeError, RuntimeError, NotImplementedError:
        logger.debug("_get_ls_params raised for %s", type(model).__name__)
        return None
    if isinstance(ls_params, dict):
        provider = ls_params.get("ls_provider")
        if isinstance(provider, str):
            return provider
    return None


def _is_anthropic_model(model: object) -> bool:
    """Check whether a resolved model reports `'anthropic'` as its provider.

    Uses `_get_ls_params` from `BaseChatModel` to read the provider name.

    Args:
        model: A model instance to inspect.

            Typed as `object` (rather than `BaseChatModel`) so the caller can
            pass any model without an import-time dependency on a specific
            provider package.

    Returns:
        `True` if the model's `ls_provider` is `'anthropic'`.
    """
    return _get_ls_provider(model) == "anthropic"


def _is_fireworks_model(model: object) -> bool:
    """Check whether a resolved model reports `'fireworks'` as its provider.

    Returns:
        `True` if the model's `ls_provider` is `'fireworks'`.
    """
    return _get_ls_provider(model) == "fireworks"


def _is_openai_model(model: object) -> bool:
    """Check whether a resolved model targets OpenAI's chat/responses API.

    `prompt_cache_key` is an optional, additive OpenAI request field, so it is
    attempted for every model whose LangSmith provider is `'openai'` regardless
    of base URL. `ChatOpenAI` reports `'openai'` for the official API, the
    LangSmith gateway, and other OpenAI-compatible endpoints alike; treating all
    of them as eligible is intentional so the cache-key optimization is not
    silently dropped behind a proxy. Endpoints that reject unknown request
    fields can opt out via the `models.openai_prompt_cache_key` config option.

    Returns:
        `True` if the model reports `'openai'` as its provider.
    """
    return _get_ls_provider(model) == "openai"


_ANTHROPIC_ONLY_SETTINGS: set[str] = {"cache_control"}
"""Keys injected by Anthropic-specific middleware (e.g.
`AnthropicPromptCachingMiddleware`) that are not accepted by other providers and
must be stripped on cross-provider swap."""

_OPENAI_PROMPT_CACHE_KEY_PREFIX = "dcode_v1"
"""Versioned namespace for the injected OpenAI `prompt_cache_key`.

Bump the version when a system-prompt overhaul should start new cache groups.
"""

_FIREWORKS_SESSION_AFFINITY_HEADER = "x-session-affinity"
"""Fireworks prompt-cache affinity header populated from the active thread ID."""


def _has_header(headers: Mapping[object, object], target: str) -> bool:
    """Return whether a headers mapping already includes `target`.

    Comparison is case-insensitive; `target` must be supplied in lowercase.

    Returns:
        `True` if a string key case-insensitively equal to `target` is present.
    """
    return any(isinstance(key, str) and key.lower() == target for key in headers)


def _with_fireworks_session_settings(
    model_settings: dict[str, Any], thread_id: str
) -> dict[str, Any] | None:
    """Return model settings with Fireworks session settings added if needed.

    Existing settings are preserved and never overwritten. Missing
    `x-session-affinity` headers are populated directly so Fireworks can route
    the conversation to the prompt-cache session for the active thread.

    Returns:
        A new `model_settings` dict with the missing session settings added, or
            `None` when nothing needed adding or `extra_headers` is present but
            not a mapping (leaving the request untouched).
    """
    raw_headers = model_settings.get("extra_headers")
    if raw_headers is None:
        headers: dict[object, object] = {}
    elif isinstance(raw_headers, Mapping):
        headers = dict(raw_headers)
    else:
        logger.warning(
            "Cannot inject Fireworks session settings because extra_headers is %s",
            type(raw_headers).__name__,
        )
        return None

    updated: dict[str, Any] = {}
    has_session_affinity = _has_header(headers, _FIREWORKS_SESSION_AFFINITY_HEADER)
    if "prompt_cache_key" not in model_settings and not has_session_affinity:
        updated["prompt_cache_key"] = thread_id

    if not has_session_affinity:
        headers[_FIREWORKS_SESSION_AFFINITY_HEADER] = thread_id
        updated["extra_headers"] = headers

    if not updated:
        return None
    return {**model_settings, **updated}


def _openai_prompt_cache_key() -> str:
    """Build the OpenAI `prompt_cache_key` shared by every thread of this install.

    OpenAI recommends one key per user that stays the same across that user's
    sessions, and a separate key per session or thread only when it needs its
    own cache accounting. Every dcode thread starts with the same system-prompt
    and tool prefix, so a per-thread key would split that shared prefix across
    keys and make each new thread pay for it again. The key is the versioned
    prefix plus the random, anonymous install ID (see `install_id`).

    Performs blocking file I/O the first time per process; async callers should
    offload.

    Returns:
        A key of the form `dcode_v1:<install id>`.
    """
    from deepagents_code.install_id import get_install_id

    return f"{_OPENAI_PROMPT_CACHE_KEY_PREFIX}:{get_install_id()}"


def _with_openai_prompt_cache_key(
    model: object, model_settings: dict[str, Any], cache_key: str
) -> dict[str, Any] | None:
    """Return model settings with an OpenAI `prompt_cache_key` added if needed.

    Adds `cache_key` as a top-level `prompt_cache_key` when the model and the
    current invocation settings do not already carry one. Callers decide
    eligibility (provider check + `models.openai_prompt_cache_key` opt-out)
    before invoking this helper.

    A user-supplied `prompt_cache_key` is always preserved, whether it was
    configured on the model (`model_kwargs`) or supplied for this invocation
    (`model_settings`).

    Returns:
        A new `model_settings` dict with `prompt_cache_key` added, or `None` when
            a key is already present on the model or in the settings (nothing to
            add).
    """
    model_kwargs = getattr(model, "model_kwargs", None)
    if model_kwargs is not None and not isinstance(model_kwargs, Mapping):
        # A non-mapping `model_kwargs` cannot carry a user-supplied key, so it is
        # treated as "no key present" and injection proceeds. Trace the anomaly
        # since a real `ChatOpenAI` always exposes a mapping here.
        logger.debug(
            "Ignoring non-mapping model_kwargs (%s) when checking for a "
            "user-supplied prompt_cache_key",
            type(model_kwargs).__name__,
        )
    if "prompt_cache_key" in model_settings or (
        isinstance(model_kwargs, Mapping) and "prompt_cache_key" in model_kwargs
    ):
        return None
    return {**model_settings, "prompt_cache_key": cache_key}


def _resolve_openai_prompt_cache_key_enabled() -> bool:
    """Resolve the `models.openai_prompt_cache_key` opt-out (default on).

    Called once when `ConfigurableModelMiddleware` is constructed. The read is
    kept off the blockbuster-guarded server loop by the caller: on the server
    path `create_cli_agent` runs inside `asyncio.to_thread` (see
    `server_graph._make_graphs`), so the synchronous `config.toml` read happens
    on a worker thread.

    On an unexpected failure this defaults to enabled: breaking agent
    construction over a config hiccup is worse than injecting the key, and the
    ordinary failure modes (a missing or corrupt `config.toml`) are already
    absorbed by `load_config_toml`. The trade-off is real, not cosmetic — a user
    who opted out *because their endpoint 400s on unknown request fields* would
    then see that per-request failure rather than a benign extra key — so the
    fallback logs at `warning` (not `debug`) to leave a breadcrumb.

    `BlockingError` is deliberately excluded from the fail-open: it signals a
    real blocking-I/O-on-the-event-loop regression (construction moved back onto
    the guarded loop), and swallowing it would mask that bug *and* silently
    defeat the opt-out. It is re-raised so the violation surfaces loudly. It is
    matched by class name because `blockbuster` is not a runtime dependency of
    this package (it is supplied by the langgraph runtime), so it cannot be
    imported here for an `isinstance` check.

    Returns:
        `True` when injection is enabled (the default), `False` when the opt-out
            is set.
    """
    try:
        from deepagents_code.config import is_openai_prompt_cache_key_enabled

        return is_openai_prompt_cache_key_enabled()
    except Exception as exc:
        if any(cls.__name__ == "BlockingError" for cls in type(exc).__mro__):
            raise
        logger.warning(
            "Could not resolve models.openai_prompt_cache_key; defaulting to ON "
            "(an opt-out you set may not take effect)",
            exc_info=True,
        )
        return True


def _get_context(request: ModelRequest) -> CLIContextSchema | None:
    """Return runtime context when it matches the CLI context shape."""
    runtime = request.runtime
    if runtime is None:
        return None

    return CLIContextSchema.from_payload(runtime.context)


def _model_spec_from_model(
    model: BaseChatModel, model_result: ModelResult | None = None
) -> str | None:
    """Return a resumable `provider:model` spec for a model object."""
    if model_result is not None:
        return f"{model_result.provider}:{model_result.model_name}"
    model_name = get_model_identifier(model)
    from deepagents_code.config import runtime_state

    settings_provider = runtime_state.model_provider or ""
    settings_model = runtime_state.model_name or ""
    if settings_provider and settings_model and model_name == settings_model:
        return f"{settings_provider}:{settings_model}"
    provider = _get_ls_provider(model)
    if provider and model_name:
        return f"{provider}:{model_name}"
    if settings_provider and settings_model:
        return f"{settings_provider}:{settings_model}"
    return None


def _model_spec_from_result(
    model_result: ModelResult | None, model: BaseChatModel
) -> str | None:
    """Return the resolved spec from `create_model`, falling back to model metadata."""
    if model_result is not None and model_result.provider and model_result.model_name:
        return f"{model_result.provider}:{model_result.model_name}"
    return _model_spec_from_model(model)


def _build_overrides(
    request: ModelRequest,
    ctx: CLIContextSchema,
    model_result: ModelResult | None,
    *,
    openai_prompt_cache_key: str | None,
) -> ModelRequest:
    """Build the overridden request from a (possibly resolved) model result.

    Holds the post-construction logic shared by the sync and async override
    paths: applying the model swap, merging `model_params`, stripping
    Anthropic-only settings on a cross-provider swap, and patching the
    `### Model Identity` system-prompt section. The only thing that differs
    between the two callers is how `model_result` is produced (a direct
    `create_model` call vs. an `asyncio.to_thread` offload).

    Args:
        request: The incoming model request from the middleware chain.
        ctx: Runtime CLI context carrying the requested overrides.
        model_result: The resolved model result from `create_model`, or `None`
            when no model swap was requested.
        openai_prompt_cache_key: The OpenAI `prompt_cache_key` to inject, or
            `None` when the `models.openai_prompt_cache_key` opt-out is set.

    Returns:
        The original request when no overrides apply, otherwise a new request
            with overrides applied via `request.override()`.
    """
    overrides: dict[str, Any] = {}

    new_model = model_result.model if model_result is not None else None
    if new_model is not None:
        overrides["model"] = new_model

    # Param merge
    model_params = ctx.model_params
    if model_params:
        overrides["model_settings"] = {**request.model_settings, **model_params}

    # Inject the provider's prompt-cache routing hint. Only one provider path
    # applies per call; both share the fetch/guard/log tail below.
    # `overrides.get` is side-effect-free, so resolving `settings` before the
    # provider check is equivalent to doing it inside each branch.
    effective_model = new_model if new_model is not None else request.model
    if ctx.thread_id:
        settings = overrides.get("model_settings", request.model_settings)
        if _is_fireworks_model(effective_model):
            # Fireworks has no opt-out gate. The classifier is provider-only
            # (like the OpenAI one), so this does not *verify* a fixed endpoint;
            # it rests on the assumption that `ChatFireworks` in practice targets
            # Fireworks' hosted API, where unknown-field rejection is not the
            # concern it is for the broadened, proxy-reachable OpenAI path below.
            updated_settings = _with_fireworks_session_settings(settings, ctx.thread_id)
            injected = "Fireworks session settings"
        elif _is_openai_model(effective_model):
            if openai_prompt_cache_key is not None:
                updated_settings = _with_openai_prompt_cache_key(
                    effective_model, settings, openai_prompt_cache_key
                )
                injected = "OpenAI prompt_cache_key"
            else:
                # Opt-out fired: leave the request untouched but log it so a user
                # verifying `models.openai_prompt_cache_key=false` sees a positive
                # signal rather than having to infer it from an absent log line.
                updated_settings = None
                injected = ""
                logger.debug("Skipped OpenAI prompt_cache_key (opt-out)")
        else:
            updated_settings = None
            injected = ""
        if updated_settings is not None:
            overrides["model_settings"] = updated_settings
            # Thread and install IDs are identifiers, so they are kept out of
            # the log line; the line firing at all confirms injection ran.
            logger.debug("Injected %s", injected)

    if not overrides:
        return request

    # When switching away from Anthropic, strip provider-specific settings
    # that would cause errors on other providers (e.g. cache_control passed
    # to the OpenAI SDK raises TypeError).
    if new_model is not None and not _is_anthropic_model(new_model):
        settings = overrides.get("model_settings", request.model_settings)
        dropped = settings.keys() & _ANTHROPIC_ONLY_SETTINGS
        if dropped:
            logger.debug(
                "Stripped Anthropic-only settings %s for non-Anthropic model",
                dropped,
            )
            overrides["model_settings"] = {
                k: v for k, v in settings.items() if k not in dropped
            }

    # Patch the Model Identity section in the system prompt so the new model
    # sees its own name/provider/context-limit, not the original's.
    # Read metadata from `model_result`, not the process-wide runtime state:
    # the middleware runs in the server subprocess, whose state is not updated
    # by `/model`.
    if model_result is not None and request.system_prompt:
        from deepagents_code.agent import (
            MODEL_IDENTITY_RE,
            build_model_identity_section,
        )

        prompt = request.system_prompt
        new_identity = build_model_identity_section(
            model_result.model_name,
            provider=model_result.provider,
            context_limit=model_result.context_limit,
            unsupported_modalities=model_result.unsupported_modalities,
        )
        patched = MODEL_IDENTITY_RE.sub(new_identity, prompt, count=1)
        if patched != prompt:
            overrides["system_prompt"] = patched
        elif "### Model Identity" in prompt:
            logger.warning(
                "System prompt contains '### Model Identity' but regex "
                "did not match; identity section was NOT updated for "
                "model '%s'. The regex may be out of sync with the "
                "prompt template.",
                model_result.model_name,
            )

    return request.override(**overrides)


def _model_creation_kwargs(
    ctx: CLIContextSchema, cli_max_retries: int | None
) -> dict[str, Any]:
    """Build constructor kwargs needed for a runtime model switch.

    Returns:
        Keyword arguments for `create_model`.
    """
    kwargs: dict[str, Any] = {}
    if cli_max_retries is not None:
        kwargs["cli_max_retries"] = cli_max_retries
    if ctx.profile_overrides:
        kwargs["profile_overrides"] = ctx.profile_overrides
    return kwargs


def _apply_overrides(
    request: ModelRequest,
    *,
    openai_prompt_cache_key: str | None,
    cli_max_retries: int | None,
    strict_model_resolution: bool = False,
    construction_model_result: ModelResult | None = None,
) -> _ResolvedModelRequest:
    """Apply model/param overrides and return checkpoint persistence metadata.

    Reads `'model'` and `'model_params'` from `runtime.context` and, when
    present, swaps the model and/or merges extra settings into the request.
    On a cross-provider swap away from Anthropic, Anthropic-only settings
    (e.g. `cache_control`) are stripped. The `### Model Identity` section
    in the system prompt is also patched to reflect the new model.

    Args:
        request: The incoming model request from the middleware chain.
        openai_prompt_cache_key: The OpenAI `prompt_cache_key` to inject, or
            `None` when opted out; threaded through to `_build_overrides`.
        cli_max_retries: Explicit CLI retry count retained across model switches.
        strict_model_resolution: Whether model construction failures should propagate.
        construction_model_result: Construction-time workspace model metadata.

    Returns:
        The request to send downstream plus the actual model spec and user-supplied
            model params that should be recorded for resume.

    Raises:
        ModelNotAllowedError: If runtime context requests a blocked model.
        ModelConfigError: If strict resolution is enabled and construction fails.
    """
    ctx = _get_context(request)
    if ctx is None:
        return _ResolvedModelRequest(
            request, _model_spec_from_model(request.model, construction_model_result)
        )

    model_result = None
    model = ctx.model
    if model and not model_matches_spec(request.model, model):
        from deepagents_code.config import create_model
        from deepagents_code.model_config import ModelConfigError, ModelNotAllowedError

        logger.debug("Overriding model to %s", model)
        model_kwargs = _model_creation_kwargs(ctx, cli_max_retries)
        try:
            model_result = create_model(model, **model_kwargs)
        except ModelNotAllowedError:
            # `ModelNotAllowedError` is a `ModelConfigError`; without this
            # clause the handler below would swallow a policy denial, log it,
            # and silently continue on the *current* model while the UI
            # reported a switch. Not redundant -- do not remove.
            raise
        except ModelConfigError:
            if strict_model_resolution:
                raise
            logger.exception(
                "Failed to resolve runtime model override '%s'; "
                "continuing with current model",
                model,
            )
            # `model_params_known=False` deliberately: the override never
            # reached `_build_overrides`, so which params are in effect is
            # exactly what this path does not know. Writing the default `None`
            # instead would clear the checkpoint's params while the app still
            # holds its override, and the cold-cache identity check would then
            # compare a populated map against `None` on every send -- a
            # permanent, false "the model changed".
            return _ResolvedModelRequest(
                request,
                _model_spec_from_model(request.model, construction_model_result),
                model_params_known=False,
            )

    updated = _build_overrides(
        request, ctx, model_result, openai_prompt_cache_key=openai_prompt_cache_key
    )
    params = dict(ctx.model_params) if ctx.model_params else None
    return _ResolvedModelRequest(
        updated,
        _model_spec_from_result(model_result, updated.model),
        params,
        model_params_known=True,
    )


async def _apply_overrides_async(
    request: ModelRequest,
    *,
    openai_prompt_cache_key: str | None,
    cli_max_retries: int | None,
    strict_model_resolution: bool = False,
    construction_model_result: ModelResult | None = None,
) -> _ResolvedModelRequest:
    """Async variant of `_apply_overrides` that offloads model construction.

    Args:
        request: The incoming model request from the middleware chain.
        openai_prompt_cache_key: The OpenAI `prompt_cache_key` to inject, or
            `None` when opted out; threaded through to `_build_overrides`.
        cli_max_retries: Explicit CLI retry count retained across model switches.
        strict_model_resolution: Whether model construction failures should propagate.
        construction_model_result: Construction-time workspace model metadata.

    Returns:
        The request to send downstream plus the actual model spec and user-supplied
            model params that should be recorded for resume.

    Raises:
        ModelNotAllowedError: If runtime context requests a blocked model.
        ModelConfigError: If strict resolution is enabled and construction fails.
    """
    ctx = _get_context(request)
    if ctx is None:
        return _ResolvedModelRequest(
            request, _model_spec_from_model(request.model, construction_model_result)
        )

    model_result = None
    model = ctx.model
    if model and not model_matches_spec(request.model, model):
        from deepagents_code.config import create_model
        from deepagents_code.model_config import ModelConfigError, ModelNotAllowedError

        logger.debug("Overriding model to %s", model)
        model_kwargs = _model_creation_kwargs(ctx, cli_max_retries)
        try:
            model_result = await asyncio.to_thread(
                create_model,
                model,
                **model_kwargs,
            )
        except ModelNotAllowedError:
            # `ModelNotAllowedError` is a `ModelConfigError`; without this
            # clause the handler below would swallow a policy denial, log it,
            # and silently continue on the *current* model while the UI
            # reported a switch. Not redundant -- do not remove.
            raise
        except ModelConfigError:
            if strict_model_resolution:
                raise
            logger.exception(
                "Failed to resolve runtime model override '%s'; "
                "continuing with current model",
                model,
            )
            # `model_params_known=False` deliberately: the override never
            # reached `_build_overrides`, so which params are in effect is
            # exactly what this path does not know. Writing the default `None`
            # instead would clear the checkpoint's params while the app still
            # holds its override, and the cold-cache identity check would then
            # compare a populated map against `None` on every send -- a
            # permanent, false "the model changed".
            return _ResolvedModelRequest(
                request,
                _model_spec_from_model(request.model, construction_model_result),
                model_params_known=False,
            )

    updated = _build_overrides(
        request, ctx, model_result, openai_prompt_cache_key=openai_prompt_cache_key
    )
    params = dict(ctx.model_params) if ctx.model_params else None
    return _ResolvedModelRequest(
        updated,
        _model_spec_from_result(model_result, updated.model),
        params,
        model_params_known=True,
    )


def _utc_now_iso() -> str:
    """Return the current UTC time in checkpoint-safe ISO format."""
    return datetime.now(UTC).isoformat()


def _effective_cache_params(
    model_spec: str | None, runtime_overrides: Mapping[str, Any] | None
) -> dict[str, Any] | None:
    """Resolve the cache-identity params a request actually runs with.

    Mirrors the app-side comparison: the cold-cache check reads configured
    provider/per-model `params` (via `ModelConfig.get_effective_kwargs`) plus
    runtime overrides. If the checkpoint stores only the runtime overrides, a
    user with a configured `prompt_cache_retention` and no session override
    records `None` here while the reader sees `{"prompt_cache_retention": ...}`,
    so the next turn compares unequal and reports a false `identity_changed`
    every turn. Persisting the effective params makes both sides match.

    The result is projected through `cache_identity_params` and recorded in the
    dedicated `_last_cache_params` channel rather than `_model_params`: the
    latter is read back on resume as per-session runtime overrides, so storing
    the merged config there would pin every configured knob (temperature,
    headers, ...) into old threads and silently override newer config.

    Performs blocking config reads; async callers should offload.

    Args:
        model_spec: `provider:model` spec for the call.
        runtime_overrides: Per-request params (the middleware's `model_params`).

    Returns:
        Cache-identity projection of the effective kwargs (without `base_url`),
        or `None` when no identity keys are present.
    """
    if not model_spec or ":" not in model_spec:
        overrides = dict(runtime_overrides) if runtime_overrides else None
        return cache_identity_params(overrides, model_spec=model_spec) or None
    from deepagents_code.config import _compose_openai_reasoning_effort
    from deepagents_code.model_config import ModelConfig

    _, _, model_name = model_spec.partition(":")
    provider = model_spec.split(":", 1)[0].strip().lower()
    try:
        config = ModelConfig.load()
        kwargs = config.get_effective_kwargs(
            provider,
            model_name=model_name,
            overrides=runtime_overrides,
        )
    except Exception:
        logger.warning(
            "Could not resolve effective cache params for %r; recording only "
            "runtime overrides, so a configured cache param may read as a "
            "spurious identity change until the next turn",
            model_spec,
            exc_info=True,
        )
        overrides = dict(runtime_overrides) if runtime_overrides else None
        return cache_identity_params(overrides, model_spec=model_spec) or None
    if not isinstance(kwargs, dict):
        overrides = dict(runtime_overrides) if runtime_overrides else None
        return cache_identity_params(overrides, model_spec=model_spec) or None
    # Match constructor precedence when config uses native nested reasoning.
    overrides = runtime_overrides or {}
    kwargs = _compose_openai_reasoning_effort(
        provider, kwargs, overrides.get("reasoning_effort"), overrides.get("reasoning")
    )
    # `base_url` is tracked separately as the endpoint identity; keeping it out
    # of the params avoids a double-counted identity change.
    result = cache_identity_params(
        {k: v for k, v in kwargs.items() if k != "base_url"}, model_spec=model_spec
    )
    return result or None


def _checkpoint_command(
    resolved: _ResolvedModelRequest,
    request_started_at: str,
    cache_endpoint: str,
    cache_params: dict[str, Any] | None = None,
    *,
    response: ModelResponse | None = None,
) -> Command[Any]:
    """Build the private resume-state update for a completed model call.

    Args:
        resolved: The request as actually sent, after override resolution.
        request_started_at: UTC ISO timestamp captured before the model call.
            It only reaches a checkpoint because this runs after `handler()`
            returned, which is what makes it a successful-call marker.
        cache_endpoint: Endpoint identity for `resolved.model_spec`, from
            `_cache_endpoint_identity`. Passed in rather than resolved here so
            the async caller can keep its blocking config/credential reads off
            the event loop.
        cache_params: Cache-identity projection of the effective params for
            this call, from `_effective_cache_params`. Passed in for the same
            offloading reason as `cache_endpoint`. When `None` and
            `resolved.model_params_known` is true, falls back to the identity
            projection of the runtime overrides.
        response: This request's response, used to attribute cache activity.

    Returns:
        Command carrying cache timing and effective model metadata.
    """
    update: dict[str, Any] = {}
    # Use the resolved spec, not `_apply_overrides`'s `ctx.model`: when an
    # override fails with `ModelConfigError`, `_apply_overrides` falls back to
    # the original model while `ctx.model` still names the rejected override.
    #
    # The timestamp is written only alongside a known spec. The three are one
    # fact -- when the cache was warmed, for which model, and against which
    # endpoint -- and a timestamp without an identity would read back as a
    # permanent "model changed", warning on every send with copy that names a
    # change that never happened. For the same reason the endpoint is written
    # unconditionally here: a skipped write would leave the *previous* turn's
    # endpoint describing this turn's spec and timestamp.
    if resolved.model_spec:
        update["_last_model_request_at"] = request_started_at
        update["_last_cache_model_spec"] = resolved.model_spec
        update["_last_cache_endpoint"] = cache_endpoint
        update["_model_spec"] = resolved.model_spec
    else:
        # The previous turn's timestamp stays in place, so the next cold-cache
        # age is computed against an older request than the one just made.
        logger.debug(
            "Not recording prompt-cache state: no model spec could be derived from %s",
            type(resolved.request.model).__name__,
        )
    if resolved.model_params_known:
        # `_model_params` stays the *runtime overrides only*: resume reads it
        # back as per-session overrides for `_switch_model`, so storing the
        # merged config there would pin provider defaults (temperature, max
        # retries, headers, ...) into old threads and silently override newer
        # config on resume.
        update["_model_params"] = resolved.model_params
        # The cold-cache identity projection goes to its own channel. It must
        # include configured provider params -- not just the session override
        # above -- or the reader's effective-params comparison reports a false
        # `identity_changed` on every turn for anyone with a configured cache
        # knob.
        update["_last_cache_params"] = (
            cache_params
            if cache_params is not None
            else (
                cache_identity_params(
                    resolved.model_params, model_spec=resolved.model_spec
                )
                or None
            )
        )
    if resolved.model_spec and response is not None:
        activity = CacheActivity(
            requested_at=request_started_at,
            model_spec=resolved.model_spec,
            endpoint=cache_endpoint,
            params=cache_params,
        )
        update.update(_cache_activity_update(response, activity))
    return Command(update=update)


def _cache_activity_update(
    response: ModelResponse, activity: CacheActivity
) -> dict[str, CacheActivity]:
    """Record only cache activity reported by this specific model call.

    Returns:
        Updates for the last cache write and/or use, when reported.
    """
    from deepagents_code.cost_tracking import cache_token_counts

    update: dict[str, CacheActivity] = {}
    for message in response.result:
        if not isinstance(message, AIMessage) or not message.usage_metadata:
            continue
        reads, writes = cache_token_counts(message.usage_metadata)
        if any(writes):
            update["_last_cache_write"] = activity
        if reads or any(writes):
            update["_last_cache_use"] = activity
    return update


class ConfigurableModelMiddleware(AgentMiddleware):
    """Swap the model or per-call settings from `runtime.context`.

    Reads two optional keys from the runtime context dict:

    - `'model'` — a `provider:model` spec (e.g. `"openai:gpt-5"`).
        When present and different from the current model, the request is
        re-routed to the new model.
    - `'model_params'` — a dict of extra model settings (e.g.
        `{"temperature": 0}`) that are shallow-merged into the
        request's `model_settings`.

    This middleware is typically the outermost layer so it intercepts every
    model call before provider-specific middleware (like
    `AnthropicPromptCachingMiddleware`) runs.
    """

    trace_policy = TracePolicy(process_inputs=omit_payload)
    """Omit hook inputs from traces by default; set a `TracePolicy` to override."""

    def __init__(
        self,
        *,
        persist_model_state: bool = True,
        openai_prompt_cache_key: bool | None = None,
        cli_max_retries: int | None = None,
        strict_model_resolution: bool = False,
        environ: Mapping[str, str] | None = None,
        model_result: ModelResult | None = None,
    ) -> None:
        """Initialize the middleware.

        Args:
            persist_model_state: Whether completed calls should write private
                resume metadata. Subagent instances disable this because they do
                not own the parent thread's resume state.
            openai_prompt_cache_key: Whether to inject the per-install OpenAI
                `prompt_cache_key` (see `_openai_prompt_cache_key`). Left as
                `None` (the default) it is resolved once here from
                `models.openai_prompt_cache_key` and cached, so no per-call read
                happens. When enabled, the key is also built once here. The
                one-time `config.toml` and install-ID reads assume current
                callers construct the middleware off the blockbuster-guarded
                server loop (the server path offloads `create_cli_agent` via
                `asyncio.to_thread`); if that assumption is ever broken the read
                would trip `BlockingError`, which is re-raised rather than
                masked. Pass an explicit bool to bypass the config read (mainly
                for tests).
            cli_max_retries: Explicit `--max-retries` value to retain across
                runtime model switches.
            strict_model_resolution: Whether invalid runtime model overrides should
                fail the call instead of falling back to the construction-time model.
            environ: Workspace environment retained for lazy model switches.
            model_result: Construction-time workspace model metadata.
        """
        self._persist_model_state = persist_model_state
        self._environ = environ
        self._model_result = model_result
        self._cli_max_retries = cli_max_retries
        self._strict_model_resolution = strict_model_resolution
        enabled = (
            _resolve_openai_prompt_cache_key_enabled()
            if openai_prompt_cache_key is None
            else openai_prompt_cache_key
        )
        self._openai_prompt_cache_key = _openai_prompt_cache_key() if enabled else None

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse | ExtendedModelResponse:
        """Apply runtime overrides and delegate to the next handler.

        Returns:
            The downstream response plus a private resume-state update when the
            completed call has model metadata to checkpoint.
        """
        from deepagents_code.config import use_environment

        with use_environment(self._environ):
            resolved = _apply_overrides(
                request,
                openai_prompt_cache_key=self._openai_prompt_cache_key,
                cli_max_retries=self._cli_max_retries,
                strict_model_resolution=self._strict_model_resolution,
                construction_model_result=self._model_result,
            )
            cache_endpoint = (
                _cache_endpoint_identity(resolved.model_spec, resolved.model_params)
                if resolved.model_params is not None
                else _cache_endpoint_identity(resolved.model_spec)
            )
            cache_params = _effective_cache_params(
                resolved.model_spec, resolved.model_params
            )
            activity = CacheActivity(
                requested_at=_utc_now_iso(),
                model_spec=resolved.model_spec or "",
                endpoint=cache_endpoint,
                params=cache_params,
            )
            token = cache_request.set(activity if self._persist_model_state else None)
            try:
                response = handler(resolved.request)
            finally:
                cache_request.reset(token)
            if not self._persist_model_state:
                return response
            request_started_at = activity["requested_at"]
        command = _checkpoint_command(
            resolved,
            request_started_at,
            cache_endpoint,
            cache_params,
            response=response,
        )
        return ExtendedModelResponse(model_response=response, command=command)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelResponse | ExtendedModelResponse:
        """Apply runtime overrides and delegate to the next async handler.

        Returns:
            The downstream response plus a private resume-state update when the
            completed call has model metadata to checkpoint.
        """
        from deepagents_code.config import use_environment

        with use_environment(self._environ):
            resolved = await _apply_overrides_async(
                request,
                openai_prompt_cache_key=self._openai_prompt_cache_key,
                cli_max_retries=self._cli_max_retries,
                strict_model_resolution=self._strict_model_resolution,
                construction_model_result=self._model_result,
            )
            cache_endpoint = (
                await asyncio.to_thread(
                    _cache_endpoint_identity,
                    resolved.model_spec,
                    resolved.model_params,
                )
                if resolved.model_params is not None
                else await asyncio.to_thread(
                    _cache_endpoint_identity, resolved.model_spec
                )
            )
            cache_params = await asyncio.to_thread(
                _effective_cache_params,
                resolved.model_spec,
                resolved.model_params,
            )
            activity = CacheActivity(
                requested_at=_utc_now_iso(),
                model_spec=resolved.model_spec or "",
                endpoint=cache_endpoint,
                params=cache_params,
            )
            token = cache_request.set(activity if self._persist_model_state else None)
            try:
                response = await handler(resolved.request)
            finally:
                cache_request.reset(token)
            if not self._persist_model_state:
                return response
            request_started_at = activity["requested_at"]
        command = _checkpoint_command(
            resolved,
            request_started_at,
            cache_endpoint,
            cache_params,
            response=response,
        )
        return ExtendedModelResponse(model_response=response, command=command)
