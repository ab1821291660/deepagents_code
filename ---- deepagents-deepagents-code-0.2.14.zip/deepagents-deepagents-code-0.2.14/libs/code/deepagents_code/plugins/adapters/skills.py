"""Adapter from discovered plugins to `SkillsMiddleware` sources."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from deepagents_code.plugins.models import BrokenPluginInstall, PluginInstance

logger = logging.getLogger(__name__)

# Documentation aliases: these name the role each `str` plays in the source
# tuples below, but they are plain aliases, not `NewType`s. Any `str` satisfies
# all three, so swapping a label for a namespace still type-checks.
type SkillPath = str
type SkillLabel = str
type SkillNamespace = str
type DirectorySkillSource = tuple[SkillPath, SkillLabel]
type PluginSkillSource = tuple[SkillPath, SkillLabel, SkillNamespace]
type CodeSkillSource = DirectorySkillSource | PluginSkillSource


def namespaced_skill_name(
    namespace: SkillNamespace,
    name: str,
    subfolders: tuple[str, ...] = (),
) -> str:
    """Qualify a skill name under its plugin namespace.

    Nested skill directories contribute intermediate `:`-joined segments
    between the plugin namespace and the skill name, matching the plugin skill
    naming convention (e.g. `plugin:sub:review`).

    Args:
        namespace: Plugin namespace (its `plugin_id`).
        name: Skill name from the skill's frontmatter.
        subfolders: Directory names between the plugin skills root and the
            skill directory, in path order.

    Returns:
        The qualified skill name.
    """
    return ":".join((namespace, *subfolders, name)).lower()


def plugin_skill_sources(
    plugins: tuple[PluginInstance, ...],
) -> list[PluginSkillSource]:
    """Return skill source tuples for plugin skills.

    Args:
        plugins: Plugin instances.

    Returns:
        Source tuples containing path, label, and plugin namespace.
    """
    sources: list[PluginSkillSource] = []
    for plugin in plugins:
        for path in plugin.inventory.skills:
            source_path = path.parent if path.name == "SKILL.md" else path
            try:
                if not source_path.exists():
                    continue
            except OSError:
                logger.warning("Could not inspect plugin skill path %s", source_path)
                continue
            sources.append(
                (
                    str(source_path),
                    f"Plugin: {plugin.plugin_id}",
                    plugin.plugin_id,
                )
            )
    return sources


def plugin_skill_roots(plugins: tuple[PluginInstance, ...]) -> list[Path]:
    """Return plugin skill roots for skill-content containment checks.

    Args:
        plugins: Discovered plugin instances.

    Returns:
        Skill root directories.
    """
    roots: list[Path] = []
    for plugin in plugins:
        roots.extend(
            path.parent if path.name == "SKILL.md" else path
            for path in plugin.inventory.skills
        )
    return roots


def discover_plugin_skill_state() -> tuple[
    tuple[tuple[Path, str], ...],
    tuple[Path, ...],
    frozenset[str],
    tuple[BrokenPluginInstall, ...],
]:
    """Discover plugin skill sources, containment roots, loaded ids, and repairs.

    Returns:
        Plugin skill sources, roots, ids, and enabled plugins whose installed
        files are missing, or empty values when discovery fails.
    """
    plugin_sources: tuple[tuple[Path, str], ...] = ()
    plugin_roots: tuple[Path, ...] = ()
    plugin_ids: frozenset[str] = frozenset()
    try:
        from deepagents_code.plugins import discover_plugins

        result = discover_plugins()
        plugins = result.plugins
        plugin_sources = tuple(
            (Path(path), namespace)
            for path, _label, namespace in plugin_skill_sources(plugins)
        )
        plugin_roots = tuple(plugin_skill_roots(plugins))
        plugin_ids = frozenset(plugin.plugin_id for plugin in plugins)
    except OSError, RuntimeError:
        logger.warning("Could not discover plugin skills", exc_info=True)
        return (), (), frozenset(), ()

    return plugin_sources, plugin_roots, plugin_ids, result.broken


def discover_plugin_skill_sources_and_roots() -> tuple[
    tuple[tuple[Path, str], ...], tuple[Path, ...]
]:
    """Discover plugin skill sources and containment roots.

    Returns:
        Plugin skill sources and roots, or empty tuples when discovery fails.
    """
    plugin_sources, plugin_roots, _plugin_ids, _broken = discover_plugin_skill_state()

    return plugin_sources, plugin_roots
