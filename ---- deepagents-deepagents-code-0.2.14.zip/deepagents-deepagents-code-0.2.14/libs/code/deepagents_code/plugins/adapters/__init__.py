"""Plugin subsystem adapters."""
